SNAPACK STEP90 — DEVELOPER / DIAGNOSTIC BUILD
==============================================

BASELINE
--------
Step90 is built directly from the physically accepted Step89H production baseline.
It does not intentionally change the proven ADS settled-read model, cell subtraction,
OTC current filtering/zeroing, DS2484 fixed-ROM temperature acquisition, authoritative
event ownership, event thresholds/editors, or the Step89H alert-screen behavior.

PURPOSE
-------
Step90 is the reserved Developer/Diagnostic revision.  The diagnostic instrumentation
that remains dormant in production builds is deliberately exposed here so an experienced
reviewer can inspect SNAPACK with or without the complete external hardware attached.

DEFAULT BUILD PERSONALITY
-------------------------
At the top of snapack.ino:

  SNAPACK_DEVELOPER_BUILD = 1
  SNAPACK_DIAG_ALL        = 1

This makes the shipped Step90 source an unmistakable FULL diagnostic build.
The Main carousel displays DEV FULL DIAG and Diagnostic/Tools identifies the firmware as
STEP90 DEV FULL DIAG.  Decorative ring animation is suppressed in FULL diagnostics;
authoritative event warning animation remains operational because it is semantic, not
decorative.  The future FUN area is explicitly disallowed while FULL diagnostics is active.

To make a focused diagnostic build, set SNAPACK_DIAG_ALL to 0 and enable only the desired
category flags immediately below it.  To recover production-style dormant instrumentation,
set ALL and every individual category flag to 0.

DIAGNOSTIC CATEGORIES
---------------------
SYSTEM, ADS, I2C, CELL, THERMAL, CURRENT, EVENT, SETTINGS, UI, WIFI.

Diagnostic sinks remain independently selectable:
  SNAPACK_DIAG_SERIAL_SINK
  SNAPACK_DIAG_RAMLOG_SINK
  SNAPACK_DIAG_EVENT_HISTORY_SINK

Repeated/intrusive producers remain OFF even in FULL mode unless deliberately enabled:
  SNAPACK_DIAG_I2C_PERIODIC_SCAN
  SNAPACK_DIAG_ADS_BULK_SWEEP

Serial is a diagnostic sink, not a boot dependency.  There is no Serial.flush() on the
startup path; Step90 must boot normally whether or not /dev/ttyACM0 has a reader attached.

WIFI / CREDENTIAL SAFETY
------------------------
No real Wi-Fi credentials are included in this package.

SNAPACK_LOCAL_ONLY_WIFI.example.h is provided.  A developer who wants Wi-Fi/NTP diagnostics
may copy/rename it to SNAPACK_LOCAL_ONLY_WIFI.h and enter local credentials there.
If the local header is absent, Step90 compiles with empty credentials and networking remains
nonblocking/unconfigured.

DEVELOPER EVENT SAFETY
----------------------
Step90 uses conservative compiled Current defaults:
  Enter = 100 A
  Clear = 50 A

In addition, SNAPACK_DEV_SAFE_BOOT_THRESHOLDS defaults ON.  If stale NVS from bench testing
contains a Current entry threshold below 50 A, Step90 temporarily starts at 100/50 A in RAM.
It does NOT erase or rewrite the stored threshold.  The operator may deliberately lower the
runtime threshold through Settings after boot to force an event test.

Cell and Thermal compiled defaults remain the accepted production-development values because
missing/unaccepted hardware frames do not enter their authoritative evaluators.

SYNTHETIC / PLACEHOLDER DATA
----------------------------
Step90 retains a UI-only Cell seed so a display without accepted ADS cell data is not blank.
The seed is neutral 3300 mV x 5 and is explicitly non-authoritative:

  SNAPACK_DEV_USE_SYNTHETIC_CELL_SEED = 1
  SNAPACK_DEV_SIMULATED_EVENTS        = 0

The seed updates presentation only.  It never calls the Cell event evaluator and therefore
cannot seize authoritative screen ownership.  As soon as a sane real ADS frame is accepted,
real values replace the seed.

Missing ADS/DS2484/temperature/current hardware is treated as unavailable diagnostic input;
it is not silently converted into a synthetic machine fault.

FULL-DIAGNOSTIC UI BEHAVIOR
---------------------------
- Main carousel carries DEV FULL DIAG.
- Diagnostic/Tools carries STEP90 DEV FULL DIAG.
- Live Diagnostic instrumentation identifies FULL DEV mode and event ownership.
- Ordinary decorative ring animation is suppressed.
- Authoritative Current/Cell/Thermal warning presentation and wigwag behavior remain active.
- Future FUN features are disabled by the existing diagnostic policy hook.

STEP89H REPAIRS CARRIED FORWARD
-------------------------------
- Current direction + / - physically verified.
- Current active event button -> SETTING -> Current Settings.
- Cell active event button -> SETTING -> Cell Settings; cleared notice -> ACK.
- Thermal / Thermal Differential active event button -> SETTING -> matching Settings;
  cleared notice -> ACK.
- Step89D Current authoritative red/white warning presentation retained.
- Step89A Serial.flush startup regression remains removed.

KNOWN NON-BLOCKING POLISH NOTES
-------------------------------
These are intentionally NOT changed in Step90:
- Active-event button text is SETTING singular; SETTINGS plural is preferred future polish.
- Left Clock colon is slightly too far left but currently acceptable unless a numeral clips it.
- Current HOT/temperature secondary line could move a few pixels right.
- Thermal HOT blink rhythm has one observational note for later review if it proves repeatable.

CORE-DUMP DEVELOPMENT NOTE
--------------------------
During the Step89G crash the ROM reported:
  esp_core_dump_flash: No core dump partition found!

Step90 does not alter the Arduino flash partition table.  Future diagnostic packaging should
review adding a small dedicated ESP32 core-dump partition (Espressif commonly documents 64 KB)
after confirming compatibility with SNAPACK's actual 16 MB Arduino partition scheme.

FIRST PHYSICAL TESTS
--------------------
1. Compile/export Step90.
2. Flash with the serial monitor closed so /dev/ttyACM0 is free.
3. Cold boot with NO serial reader attached.  Confirm normal startup and DEV FULL DIAG badge.
4. Repeat boot with the while-true serial reader attached.  Boot must remain independent of it.
5. Open Diagnostic/Tools and confirm STEP90 DEV FULL DIAG.
6. Confirm decorative rings remain suspended in FULL mode while controls/UI stay responsive.
7. Confirm Current boots at 100 A enter / 50 A clear if a stale low bench threshold existed.
8. Confirm no Wi-Fi attempt requiring credentials occurs unless the local header was supplied.
9. Confirm real attached hardware still replaces the synthetic Cell UI seed normally.
10. If desired, deliberately lower one event threshold and verify authoritative alerts still work.

PACKAGING
---------
The real SNAPACK_LOCAL_ONLY_WIFI.h is intentionally excluded.
Only the safe example header is included.
