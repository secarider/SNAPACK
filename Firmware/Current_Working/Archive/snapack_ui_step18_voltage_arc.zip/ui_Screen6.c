// SNAPACK TEMPERATURE SCREEN
//
// Five individual temperature probes plus one calculated average.
//
// This screen deliberately reuses the successful six-position grammar from
// the cell-voltage screen:
//     1   2   3
//     4   5   AVG
//
// The large arc is driven only by the average in this revision.  It is a
// presentation object, not a safety threshold yet.

#include "ui.h"
#include <stdio.h>

static lv_obj_t * snapTempTitle;
static lv_obj_t * snapTempHeading1;
static lv_obj_t * snapTempHeading2;
static lv_obj_t * snapTempHeading3;
static lv_obj_t * snapTempHeading4;
static lv_obj_t * snapTempHeading5;
static lv_obj_t * snapTempHeadingAvg;

static lv_obj_t * snap_temp_create_measurement(lv_obj_t * parent,
                                               const char * heading_text,
                                               int x,
                                               int y,
                                               lv_obj_t ** heading_out)
{
    lv_obj_t * heading = lv_label_create(parent);
    lv_obj_set_width(heading, LV_SIZE_CONTENT);
    lv_obj_set_height(heading, LV_SIZE_CONTENT);
    lv_obj_set_x(heading, x);
    lv_obj_set_y(heading, y - 37);
    lv_obj_set_align(heading, LV_ALIGN_CENTER);
    lv_label_set_text(heading, heading_text);
    lv_obj_set_style_text_color(heading, lv_color_hex(0xFFFFFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(heading, &lv_font_montserrat_20, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_t * value = lv_label_create(parent);
    lv_obj_set_width(value, LV_SIZE_CONTENT);
    lv_obj_set_height(value, LV_SIZE_CONTENT);
    lv_obj_set_x(value, x);
    lv_obj_set_y(value, y + 12);
    lv_obj_set_align(value, LV_ALIGN_CENTER);
    lv_label_set_text(value, "72°");
    lv_obj_set_style_text_color(value, lv_color_hex(0x33DCFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(value, &lv_font_montserrat_48, LV_PART_MAIN | LV_STATE_DEFAULT);

    if (heading_out) {
        *heading_out = heading;
    }

    return value;
}

static void snap_temp_set_label(lv_obj_t * label, int temp_dF)
{
    // Input uses tenths of a degree F; this first screen intentionally shows
    // whole degrees because the physical display does not need decimal
    // precision for a temperature status glance.
    char text[16];
    int rounded_F = (temp_dF >= 0) ? (temp_dF + 5) / 10 : (temp_dF - 5) / 10;
    snprintf(text, sizeof(text), "%d°", rounded_F);
    lv_label_set_text(label, text);
}

void ui_update_snapack_temperatures(int temp1_dF,
                                    int temp2_dF,
                                    int temp3_dF,
                                    int temp4_dF,
                                    int temp5_dF,
                                    int avg_dF)
{
    if (ui_SnapackTemp1Value) snap_temp_set_label(ui_SnapackTemp1Value, temp1_dF);
    if (ui_SnapackTemp2Value) snap_temp_set_label(ui_SnapackTemp2Value, temp2_dF);
    if (ui_SnapackTemp3Value) snap_temp_set_label(ui_SnapackTemp3Value, temp3_dF);
    if (ui_SnapackTemp4Value) snap_temp_set_label(ui_SnapackTemp4Value, temp4_dF);
    if (ui_SnapackTemp5Value) snap_temp_set_label(ui_SnapackTemp5Value, temp5_dF);
    if (ui_SnapackTempAvgValue) snap_temp_set_label(ui_SnapackTempAvgValue, avg_dF);

    if (ui_SnapackTempArc) {
        // Initial display-only scale: 32°F -> 0%, 120°F -> 100%.
        // Clamp before mapping so simulated or future sensor excursions do
        // not drive the arc outside its legal LVGL range.
        int avg_F = avg_dF / 10;
        if (avg_F < 32) avg_F = 32;
        if (avg_F > 120) avg_F = 120;

        int arc_value = ((avg_F - 32) * 100) / (120 - 32);
        lv_arc_set_value(ui_SnapackTempArc, arc_value);
    }
}

void ui_Screen6_screen_init(void)
{
    ui_Screen6 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen6,
                      LV_OBJ_FLAG_CLICKABLE |
                      LV_OBJ_FLAG_PRESS_LOCK |
                      LV_OBJ_FLAG_SCROLLABLE |
                      LV_OBJ_FLAG_SCROLL_ELASTIC |
                      LV_OBJ_FLAG_SCROLL_MOMENTUM |
                      LV_OBJ_FLAG_SCROLL_CHAIN);
    lv_obj_set_style_bg_color(ui_Screen6, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen6, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Large average-temperature arc.  It sits behind the six readings and
    // intentionally uses a subdued background track so text remains primary.
    ui_SnapackTempArc = lv_arc_create(ui_Screen6);
    lv_obj_set_width(ui_SnapackTempArc, 430);
    lv_obj_set_height(ui_SnapackTempArc, 430);
    lv_obj_set_align(ui_SnapackTempArc, LV_ALIGN_CENTER);
    lv_arc_set_rotation(ui_SnapackTempArc, 135);
    lv_arc_set_bg_angles(ui_SnapackTempArc, 0, 270);
    lv_arc_set_range(ui_SnapackTempArc, 0, 100);
    lv_arc_set_value(ui_SnapackTempArc, 45);
    lv_obj_remove_style(ui_SnapackTempArc, NULL, LV_PART_KNOB);
    lv_obj_clear_flag(ui_SnapackTempArc, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_style_arc_width(ui_SnapackTempArc, 10, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_arc_color(ui_SnapackTempArc, lv_color_hex(0x303030), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_arc_opa(ui_SnapackTempArc, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_arc_width(ui_SnapackTempArc, 12, LV_PART_INDICATOR | LV_STATE_DEFAULT);
    lv_obj_set_style_arc_color(ui_SnapackTempArc, lv_color_hex(0x33DCFF), LV_PART_INDICATOR | LV_STATE_DEFAULT);
    lv_obj_set_style_arc_opa(ui_SnapackTempArc, 255, LV_PART_INDICATOR | LV_STATE_DEFAULT);

    snapTempTitle = lv_label_create(ui_Screen6);
    lv_obj_set_width(snapTempTitle, LV_SIZE_CONTENT);
    lv_obj_set_height(snapTempTitle, LV_SIZE_CONTENT);
    lv_obj_set_x(snapTempTitle, 0);
    lv_obj_set_y(snapTempTitle, -176);
    lv_obj_set_align(snapTempTitle, LV_ALIGN_CENTER);
    lv_label_set_text(snapTempTitle, "Simulated Temperature");
    lv_obj_set_style_text_color(snapTempTitle, lv_color_hex(0xFFFFFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(snapTempTitle, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackTemp1Value = snap_temp_create_measurement(ui_Screen6, "1",   -132, -68, &snapTempHeading1);
    ui_SnapackTemp2Value = snap_temp_create_measurement(ui_Screen6, "2",      0, -68, &snapTempHeading2);
    ui_SnapackTemp3Value = snap_temp_create_measurement(ui_Screen6, "3",    132, -68, &snapTempHeading3);

    ui_SnapackTemp4Value = snap_temp_create_measurement(ui_Screen6, "4",   -132,  40, &snapTempHeading4);
    ui_SnapackTemp5Value = snap_temp_create_measurement(ui_Screen6, "5",      0,  40, &snapTempHeading5);
    ui_SnapackTempAvgValue = snap_temp_create_measurement(ui_Screen6, "AVG", 132,  40, &snapTempHeadingAvg);

    ui_SnapackTempReturnBt = lv_btn_create(ui_Screen6);
    lv_obj_set_width(ui_SnapackTempReturnBt, 168);
    lv_obj_set_height(ui_SnapackTempReturnBt, 54);
    lv_obj_set_x(ui_SnapackTempReturnBt, 0);
    lv_obj_set_y(ui_SnapackTempReturnBt, 164);
    lv_obj_set_align(ui_SnapackTempReturnBt, LV_ALIGN_CENTER);
    lv_obj_set_style_bg_color(ui_SnapackTempReturnBt, lv_color_hex(0x33DCFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_SnapackTempReturnBt, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(ui_SnapackTempReturnBt, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackTempReturnLabel = lv_label_create(ui_Screen6);
    lv_obj_set_width(ui_SnapackTempReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_SnapackTempReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_x(ui_SnapackTempReturnLabel, 0);
    lv_obj_set_y(ui_SnapackTempReturnLabel, 164);
    lv_obj_set_align(ui_SnapackTempReturnLabel, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SnapackTempReturnLabel, "Return");
    lv_obj_set_style_text_color(ui_SnapackTempReturnLabel, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_SnapackTempReturnLabel, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_add_event_cb(ui_SnapackTempReturnBt, ui_event_screen6ReturnBt, LV_EVENT_ALL, NULL);
}
