// SNAPACK CURRENT SCREEN — STEP 40 CENTER-ZERO CURRENT GAUGE
#include "ui.h"
#include <stdio.h>
#include <stdlib.h>

typedef enum {
    SNAP_CURRENT_THEME_NIGHT = 0,
    SNAP_CURRENT_THEME_DAY
} snap_current_theme_t;

static snap_current_theme_t snapCurrentTheme = SNAP_CURRENT_THEME_NIGHT;
static bool snapCurrentThemeLongPressConsumed = false;
static lv_obj_t * snapCurrentTitle = NULL;
static lv_obj_t * snapCurrentPeakLabel = NULL;
static lv_obj_t * snapCurrentChargeLabel = NULL;
static lv_obj_t * snapCurrentDischargeLabel = NULL;

#define SNAP_CURRENT_SEGMENT_COUNT 18
#define SNAP_CURRENT_HALF_SEGMENTS 9
#define SNAP_CURRENT_TEST_FULL_SCALE_A 50
static lv_obj_t * snapCurrentSegments[SNAP_CURRENT_SEGMENT_COUNT];
static int snapCurrentSignedA = 0;

static lv_color_t current_bg(void) {
    return snapCurrentTheme == SNAP_CURRENT_THEME_DAY ? lv_color_hex(0xFFFFFF) : lv_color_hex(0x000000);
}
static lv_color_t current_text(void) {
    return snapCurrentTheme == SNAP_CURRENT_THEME_DAY ? lv_color_hex(0x000000) : lv_color_hex(0xFFFFFF);
}
static lv_color_t current_value(void) {
    return snapCurrentTheme == SNAP_CURRENT_THEME_DAY ? lv_color_hex(0x000000) : lv_color_hex(0x33DCFF);
}
static lv_color_t current_button(void) {
    return snapCurrentTheme == SNAP_CURRENT_THEME_DAY ? lv_color_hex(0x000000) : lv_color_hex(0x33DCFF);
}
static lv_color_t current_button_text(void) {
    return snapCurrentTheme == SNAP_CURRENT_THEME_DAY ? lv_color_hex(0xFFFFFF) : lv_color_hex(0x000000);
}
static lv_color_t current_segment_off_color(void) {
    return snapCurrentTheme == SNAP_CURRENT_THEME_DAY ? lv_color_hex(0xD0D0D0) : lv_color_hex(0x303030);
}
static lv_color_t current_level_color(int magnitude_A) {
    // Deliberately low bench-test thresholds for the present 15-ish amp load.
    // These can be raised dramatically after real cranking-current tests.
    if (snapCurrentTheme == SNAP_CURRENT_THEME_DAY) {
        if (magnitude_A >= 30) return lv_color_hex(0xA00000);
        if (magnitude_A >= 15) return lv_color_hex(0x9A5A00);
        return lv_color_hex(0x000000);
    }
    if (magnitude_A >= 30) return lv_color_hex(0xFF4040);
    if (magnitude_A >= 15) return lv_color_hex(0xFFD040);
    return lv_color_hex(0x33DCFF);
}

static void snap_current_render_gauge(int signed_A)
{
    snapCurrentSignedA = signed_A;
    int magnitude = abs(signed_A);
    int lit = (magnitude * SNAP_CURRENT_HALF_SEGMENTS + SNAP_CURRENT_TEST_FULL_SCALE_A - 1)
              / SNAP_CURRENT_TEST_FULL_SCALE_A;
    if (lit > SNAP_CURRENT_HALF_SEGMENTS) lit = SNAP_CURRENT_HALF_SEGMENTS;
    if (magnitude == 0) lit = 0;

    const lv_color_t on = current_level_color(magnitude);
    const lv_color_t off = current_segment_off_color();

    // 0..8 = CHARGE side, outside -> center.
    // 9..17 = DISCHARGE side, center -> outside.
    for (int i=0; i<SNAP_CURRENT_SEGMENT_COUNT; i++) {
        bool active = false;
        if (signed_A < 0 && i < SNAP_CURRENT_HALF_SEGMENTS) {
            active = i >= (SNAP_CURRENT_HALF_SEGMENTS - lit);
        } else if (signed_A > 0 && i >= SNAP_CURRENT_HALF_SEGMENTS) {
            active = i < (SNAP_CURRENT_HALF_SEGMENTS + lit);
        }
        if (snapCurrentSegments[i]) {
            lv_obj_set_style_arc_color(snapCurrentSegments[i], active ? on : off,
                                       LV_PART_MAIN | LV_STATE_DEFAULT);
        }
    }
}

static void applySnapCurrentTheme(snap_current_theme_t theme)
{
    snapCurrentTheme = theme;
    if (!ui_Screen7) return;

    lv_obj_set_style_bg_color(ui_Screen7, current_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_t * text_objs[] = {snapCurrentTitle, snapCurrentPeakLabel,
                              snapCurrentChargeLabel, snapCurrentDischargeLabel,
                              ui_SnapackCurrentUnit};
    for (unsigned i=0;i<sizeof(text_objs)/sizeof(text_objs[0]);i++)
        if (text_objs[i]) lv_obj_set_style_text_color(text_objs[i], current_text(), LV_PART_MAIN | LV_STATE_DEFAULT);

    if (ui_SnapackCurrentValue)
        lv_obj_set_style_text_color(ui_SnapackCurrentValue, current_value(), LV_PART_MAIN | LV_STATE_DEFAULT);
    if (ui_SnapackCurrentReturnBt)
        lv_obj_set_style_bg_color(ui_SnapackCurrentReturnBt, current_button(), LV_PART_MAIN | LV_STATE_DEFAULT);
    if (ui_SnapackCurrentReturnLabel)
        lv_obj_set_style_text_color(ui_SnapackCurrentReturnLabel, current_button_text(), LV_PART_MAIN | LV_STATE_DEFAULT);

    snap_current_render_gauge(snapCurrentSignedA);
}

void ui_set_snapack_current_theme(bool day_mode)
{
    applySnapCurrentTheme(day_mode ? SNAP_CURRENT_THEME_DAY : SNAP_CURRENT_THEME_NIGHT);
}

bool snapack_current_consume_theme_long_press(void)
{
    if (snapCurrentThemeLongPressConsumed) {
        snapCurrentThemeLongPressConsumed = false;
        return true;
    }
    return false;
}

static void snap_current_theme_long_press_event(lv_event_t * e)
{
    if (lv_event_get_code(e) == LV_EVENT_LONG_PRESSED) {
        snapCurrentThemeLongPressConsumed = true;
        applySnapCurrentTheme(snapCurrentTheme == SNAP_CURRENT_THEME_NIGHT
                              ? SNAP_CURRENT_THEME_DAY : SNAP_CURRENT_THEME_NIGHT);
    }
}

void ui_update_snapack_current(int signed_current_A)
{
    snap_current_render_gauge(signed_current_A);
    if (!ui_SnapackCurrentValue) return;

    char text[16];
    snprintf(text, sizeof(text), "%d", abs(signed_current_A));
    lv_label_set_text(ui_SnapackCurrentValue, text);
}

void ui_update_snapack_current_peak(int peak_A)
{
    if (!snapCurrentPeakLabel) return;
    char text[32];
    snprintf(text, sizeof(text), "PEAK  %d A", peak_A);
    lv_label_set_text(snapCurrentPeakLabel, text);
}

void ui_Screen7_screen_init(void)
{
    ui_Screen7 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen7,
                      LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_PRESS_LOCK |
                      LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_SCROLL_ELASTIC |
                      LV_OBJ_FLAG_SCROLL_MOMENTUM | LV_OBJ_FLAG_SCROLL_CHAIN);
    lv_obj_set_style_bg_color(ui_Screen7, current_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen7, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // 270-degree perimeter gauge. Zero is at the top center:
    // left half grows toward CHARGE, right half grows toward DISCHARGE.
    const int segment_span = 10;
    const int segment_gap = 5;
    const int segment_step = segment_span + segment_gap;
    for (int i=0; i<SNAP_CURRENT_SEGMENT_COUNT; i++) {
        lv_obj_t * seg = lv_arc_create(ui_Screen7);
        snapCurrentSegments[i] = seg;
        lv_obj_set_width(seg, 430);
        lv_obj_set_height(seg, 430);
        lv_obj_set_align(seg, LV_ALIGN_CENTER);
        lv_arc_set_rotation(seg, 135 + (i * segment_step));
        lv_arc_set_bg_angles(seg, 0, segment_span);
        lv_arc_set_range(seg, 0, 100);
        lv_arc_set_value(seg, 100);
        lv_obj_remove_style(seg, NULL, LV_PART_KNOB);
        lv_obj_clear_flag(seg, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_set_style_arc_opa(seg, 0, LV_PART_INDICATOR | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_width(seg, 12, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_rounded(seg, false, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_color(seg, current_segment_off_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    }

    snapCurrentTitle = lv_label_create(ui_Screen7);
    lv_obj_set_align(snapCurrentTitle, LV_ALIGN_CENTER);
    lv_obj_set_y(snapCurrentTitle, -150);
    lv_label_set_text(snapCurrentTitle, "CURRENT");
    lv_obj_set_style_text_color(snapCurrentTitle, current_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(snapCurrentTitle, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);

    snapCurrentPeakLabel = lv_label_create(ui_Screen7);
    lv_obj_set_width(snapCurrentPeakLabel, LV_SIZE_CONTENT);
    lv_obj_set_height(snapCurrentPeakLabel, LV_SIZE_CONTENT);
    lv_obj_set_align(snapCurrentPeakLabel, LV_ALIGN_CENTER);
    lv_obj_set_y(snapCurrentPeakLabel, -112);
    lv_label_set_text(snapCurrentPeakLabel, "PEAK  0 A");
    lv_obj_set_style_text_color(snapCurrentPeakLabel, current_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(snapCurrentPeakLabel, &lv_font_montserrat_18, LV_PART_MAIN | LV_STATE_DEFAULT);
    // STEP 41: 307 ~= 120% (256 = 100%). Still far below the failed 2x test.
    lv_obj_set_style_transform_zoom(snapCurrentPeakLabel, 307, LV_PART_MAIN | LV_STATE_DEFAULT);

    snapCurrentChargeLabel = lv_label_create(ui_Screen7);
    lv_obj_set_align(snapCurrentChargeLabel, LV_ALIGN_CENTER);
    lv_obj_set_x(snapCurrentChargeLabel, -105);
    lv_obj_set_y(snapCurrentChargeLabel, -78);
    lv_label_set_text(snapCurrentChargeLabel, "CHARGE");
    lv_obj_set_style_text_font(snapCurrentChargeLabel, &lv_font_montserrat_12, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(snapCurrentChargeLabel, current_text(), LV_PART_MAIN | LV_STATE_DEFAULT);

    snapCurrentDischargeLabel = lv_label_create(ui_Screen7);
    lv_obj_set_align(snapCurrentDischargeLabel, LV_ALIGN_CENTER);
    lv_obj_set_x(snapCurrentDischargeLabel, 105);
    lv_obj_set_y(snapCurrentDischargeLabel, -78);
    lv_label_set_text(snapCurrentDischargeLabel, "DISCHARGE");
    lv_obj_set_style_text_font(snapCurrentDischargeLabel, &lv_font_montserrat_12, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(snapCurrentDischargeLabel, current_text(), LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackCurrentValue = lv_label_create(ui_Screen7);
    lv_obj_set_align(ui_SnapackCurrentValue, LV_ALIGN_CENTER);
    lv_obj_set_x(ui_SnapackCurrentValue, -28);
    lv_obj_set_y(ui_SnapackCurrentValue, -4);
    lv_label_set_text(ui_SnapackCurrentValue, "0");
    lv_obj_set_style_text_color(ui_SnapackCurrentValue, current_value(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_SnapackCurrentValue, &snapack_current_96, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackCurrentUnit = lv_label_create(ui_Screen7);
    lv_obj_set_align(ui_SnapackCurrentUnit, LV_ALIGN_CENTER);
    lv_obj_set_x(ui_SnapackCurrentUnit, 104);
    lv_obj_set_y(ui_SnapackCurrentUnit, 10);
    lv_label_set_text(ui_SnapackCurrentUnit, "A");
    lv_obj_set_style_text_color(ui_SnapackCurrentUnit, current_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_SnapackCurrentUnit, &lv_font_montserrat_48, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackCurrentReturnBt = lv_btn_create(ui_Screen7);
    lv_obj_set_width(ui_SnapackCurrentReturnBt, 168);
    lv_obj_set_height(ui_SnapackCurrentReturnBt, 54);
    lv_obj_set_align(ui_SnapackCurrentReturnBt, LV_ALIGN_CENTER);
    lv_obj_set_y(ui_SnapackCurrentReturnBt, 164);
    lv_obj_set_style_bg_color(ui_SnapackCurrentReturnBt, current_button(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_SnapackCurrentReturnBt, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(ui_SnapackCurrentReturnBt, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackCurrentReturnLabel = lv_label_create(ui_Screen7);
    lv_obj_set_align(ui_SnapackCurrentReturnLabel, LV_ALIGN_CENTER);
    lv_obj_set_y(ui_SnapackCurrentReturnLabel, 164);
    lv_label_set_text(ui_SnapackCurrentReturnLabel, "Return");
    lv_obj_set_style_text_color(ui_SnapackCurrentReturnLabel, current_button_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_SnapackCurrentReturnLabel, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_set_ext_click_area(ui_SnapackCurrentReturnBt, 36);
    lv_obj_add_event_cb(ui_SnapackCurrentReturnBt, ui_event_screen7ReturnBt, LV_EVENT_ALL, NULL);
    lv_obj_add_event_cb(ui_SnapackCurrentReturnBt, snap_current_theme_long_press_event, LV_EVENT_LONG_PRESSED, NULL);

    applySnapCurrentTheme(SNAP_CURRENT_THEME_NIGHT);
    snap_current_render_gauge(0);
}
