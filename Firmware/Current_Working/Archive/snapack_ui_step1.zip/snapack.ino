#include <lvgl.h>
#include <demos/lv_demos.h>
#include <Arduino_GFX_Library.h>
#include "WiFiMulti.h"
#include <WiFi.h>
#include <WiFiUdp.h>

#include <Adafruit_SSD1306.h>
#include <Adafruit_GFX.h>

// #include <CSE_CST328.h>
#include <Adafruit_CST8XX.h>
#include "ui.h"
#include "PCF8574.h" 

#define I2C_SDA_PIN 38
#define I2C_SCL_PIN 39
PCF8574 pcf8574(0x21);

String wifiId = "elecrow888";            //WiFi SSID to coonnect to
String wifiPwd = "elecrow2014";  //PASSWORD of the WiFi SSID to coonnect to

#define ENCODER_A_PIN 42     // Blue: counterclockwise, rises first
#define ENCODER_B_PIN 4      // Yellow: clockwise, rises first   B   A

volatile uint8_t lastA = 0;   
volatile uint8_t currentSW = 0; 

bool pressedFlag = false;      
volatile int pressCount = 0;  

const unsigned long debounceTime = 50;    
const unsigned long doubleClickTime = 300;  

volatile unsigned long singleClickTimeout = 0; 
volatile int8_t position_tmp = 2;      

#define SCREEN_BACKLIGHT_PIN 6
const int pwmFreq = 5000;
const int pwmChannel = 0;
const int pwmResolution = 8;

TaskHandle_t encTaskHandle = NULL;
TaskHandle_t swTaskHandle = NULL;

#define I2C_TOUCH_ADDR 0x15  // often but not always 0x15!
Adafruit_CST8XX tsPanel = Adafruit_CST8XX();
enum Events lastevent = NONE;

static const uint16_t screenWidth = 480;
static const uint16_t screenHeight = 480;

static lv_disp_draw_buf_t draw_buf;
static lv_color_t *buf1 = NULL;
static lv_color_t *buf2 = NULL;
static uint16_t *buf3 = NULL;
static uint16_t *buf4 = NULL;

lv_obj_t *current_screen = NULL;
// Carousel index:
//   0 = SNAPACK
//   1 = OEM Volume
//   2 = OEM Temp
//   3 = OEM Light
//
// Start on SNAPACK after the Elecrow splash.
int screen1_index = 0;

Arduino_ESP32RGBPanel *bus = new Arduino_ESP32RGBPanel(
  16 /* CS */, 2 /* SCK */, 1 /* SDA */,
  40 /* DE */, 7 /* VSYNC */, 15 /* HSYNC */, 41 /* PCLK */,
  46 /* R0 */, 3 /* R1 */, 8 /* R2 */, 18 /* R3 */, 17 /* R4 */,
  14 /* G0/P22 */, 13 /* G1/P23 */, 12 /* G2/P24 */, 11 /* G3/P25 */, 10 /* G4/P26 */, 9 /* G5 */,
  5 /* B0 */, 45 /* B1 */, 48 /* B2 */, 47 /* B3 */, 21 /* B4 */
);

Arduino_ST7701_RGBPanel *gfx = new Arduino_ST7701_RGBPanel(
  bus, GFX_NOT_DEFINED /* RST */, 0 /* rotation */,
  false /* IPS */, 480 /* width */, 480 /* height */,
  st7701_type5_init_operations, sizeof(st7701_type5_init_operations),
  true /* BGR */,
  10 /* hsync_front_porch(10) */, 4 /* hsync_pulse_width(8) */, 20 /* hsync_back_porch(50) */,
  10 /* vsync_front_porch(10) */, 4 /* vsync_pulse_width(8) */, 20 /* vsync_back_porch(20) */);

/* Display flushing */
void my_disp_flush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p) {
  uint32_t w = (area->x2 - area->x1 + 1);
  uint32_t h = (area->y2 - area->y1 + 1);
#if (LV_COLOR_16_SWAP != 0)
  gfx->draw16bitBeRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#else
  gfx->draw16bitRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#endif
  lv_disp_flush_ready(disp);
}

/*Read CST826 the touchpad*/
const int SWIPE_THRESHOLD = 100;  
const int TIME_THRESHOLD = 300;   
const int VERTICAL_LIMIT = 100;    
int startX = 0;
int startY = 0;
unsigned long startTime = 0;
bool trackingSwipe = false;
bool first_click = false;
void my_touchpad_read(lv_indev_drv_t *indev_driver, lv_indev_data_t *data) {
  if (tsPanel.touched()) {
    CST_TS_Point p = tsPanel.getPoint(0);
    data->point.x = p.x;
    data->point.y = p.y - 20;
    data->state = LV_INDEV_STATE_PR;

    lv_obj_t *current_screen = lv_scr_act();

    // SNAPACK CAROUSEL SWIPE HANDLING
    // Touch and rotary now share updateScreen() as one source of truth.
    // The original code duplicated the complete three-item layout inside
    // both swipe directions; that duplication is removed here before the
    // carousel grows to four items.
    if (current_screen == ui_Screen1) {
      if (first_click == false) {
        startX = p.x;
        startY = p.y;
        startTime = millis();
        trackingSwipe = true;
        first_click = true;
      }

      if (trackingSwipe && p.event == TOUCHING) {
        int deltaX = p.x - startX;
        int deltaY = abs(p.y - startY);
        unsigned long elapsed = millis() - startTime;

        if (elapsed < TIME_THRESHOLD && deltaY < VERTICAL_LIMIT) {
          if (deltaX > SWIPE_THRESHOLD) {
            first_click = false;
            trackingSwipe = false;
            if (screen1_index < 3) screen1_index++;
            updateScreen(screen1_index);
          }
          else if (deltaX < -SWIPE_THRESHOLD) {
            first_click = false;
            trackingSwipe = false;
            if (screen1_index > 0) screen1_index--;
            updateScreen(screen1_index);
          }
        }
      }
    }

    if (p.event != lastevent || p.event == TOUCHING) {
      Serial.printf("Touch ID #%d (%d, %d) Event: %s\n",
                    p.id, p.x, p.y, events_name[p.event]);
      lastevent = p.event;
    }
  }
  else {
    data->state = LV_INDEV_STATE_REL;
    first_click = false;
  }
}

// WiFi connection function
void connectWiFi() {
  Serial.println("Connecting to WiFi...");
  WiFi.begin(wifiId.c_str(), wifiPwd.c_str());
  
  // Wait for connection, up to 10 seconds
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi Connected!");
    Serial.print("SSID: ");
    Serial.println(WiFi.SSID());
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nFailed to connect to WiFi");
  }
}


void initBacklight() {
  ledcSetup(pwmChannel, pwmFreq, pwmResolution);
  ledcAttachPin(SCREEN_BACKLIGHT_PIN, pwmChannel);
  ledcWrite(pwmChannel, 204);
}

// Onboard rotary-display LED (pin 43) used for breathing effect
#define BREATH_LED_PIN 43
// Breathing-LED PWM channel (avoid conflict with backlight channel)
const int breathPwmChannel = 1;

// UDP communication variables
WiFiUDP udp;
const char* ADVANCE_IP = "192.168.50.160";  // Advance device IP address; modify as required
const int ADVANCE_PORT = 8888;             // Advance device UDP port
 
// Remote LED strip (Advance side) configuration (declared here for setup initialization)
const int REMOTE_NUM_LEDS = 15;      // Number of LEDs in the strip on Advance
int lastLedCountSent = -1;           // Record the last LED count sent to Advance

// Forward declarations: LVGL slider event callbacks
void volumeArcEventCb(lv_event_t *e);
// void volumeIconEventCb(lv_event_t *e);

void tempArcEventCb(lv_event_t *e);
// Set brightness directly through PWM only; no animation

// Initial UI values (applied when entering the screen)
int volumeValue = 50;  // 0-100
int tempValue = 0;     // 0-200
int lightValue = 50;   // 0-100

void setup() {
  Serial.begin(115200); /* prepare for possible serial debug */
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
  pcf8574.pinMode(P0, OUTPUT);        //tp RST
  pcf8574.pinMode(P2, OUTPUT);        //tp INT
  pcf8574.pinMode(P3, OUTPUT);        //lcd power
  pcf8574.pinMode(P4, OUTPUT);        //lcd reset
  pcf8574.pinMode(P5, INPUT_PULLUP);  //encoder SW

  Serial.print("Init pcf8574...\n");
  if (pcf8574.begin()) {
    Serial.println("pcf8574 OK");
  } else {
    Serial.println("pcf8574 KO");
  }

  pcf8574.digitalWrite(P3, HIGH);
  delay(100);

  /*lcd reset*/
  pcf8574.digitalWrite(P4, HIGH);
  delay(100);
  pcf8574.digitalWrite(P4, LOW);
  delay(120);
  pcf8574.digitalWrite(P4, HIGH);
  delay(120);
  /*end*/

  /*tp RST*/
  pcf8574.digitalWrite(P0, HIGH);
  delay(100);
  pcf8574.digitalWrite(P0, LOW);
  delay(120);
  pcf8574.digitalWrite(P0, HIGH);
  delay(120);
  /*tp INT*/
  pcf8574.digitalWrite(P2, HIGH);
  delay(120);

  gfx->begin();
  gfx->fillScreen(BLACK);
  gfx->setTextSize(2);
  gfx->setCursor(80, 100);

  if (!tsPanel.begin(&Wire, I2C_TOUCH_ADDR)) {
    Serial.println("No touchscreen found");
  } else {
    Serial.println("Touchscreen found");
  }

  pinMode(ENCODER_A_PIN, INPUT);
  pinMode(ENCODER_B_PIN, INPUT);
  lastA = digitalRead(ENCODER_A_PIN);

  lv_init();
  size_t buffer_size = sizeof(lv_color_t) * screenWidth * screenHeight;
  buf1 = (lv_color_t *)heap_caps_malloc(buffer_size, MALLOC_CAP_SPIRAM);
  buf2 = (lv_color_t *)heap_caps_malloc(buffer_size, MALLOC_CAP_SPIRAM);
  if (!buf1)
    Serial.println("Failed to allocate for LVGL---1---");
  if (!buf2)
    Serial.println("Failed to allocate for LVGL---2---");
  lv_disp_draw_buf_init(&draw_buf, buf1, buf2, screenWidth * screenHeight);

  /*Initialize the display*/
  static lv_disp_drv_t disp_drv;
  lv_disp_drv_init(&disp_drv);
  /*Change the following line to your display resolution*/
  disp_drv.hor_res = screenWidth;
  disp_drv.ver_res = screenHeight;
  disp_drv.flush_cb = my_disp_flush;
  disp_drv.draw_buf = &draw_buf;
  disp_drv.direct_mode = 0;
  disp_drv.full_refresh = 0; 
  disp_drv.sw_rotate = 0;
  disp_drv.screen_transp = 0;
  lv_disp_drv_register(&disp_drv);

  /*Initialize the (dummy) input device driver*/
  static lv_indev_drv_t indev_drv;
  lv_indev_drv_init(&indev_drv);
  indev_drv.type = LV_INDEV_TYPE_POINTER;
  indev_drv.read_cb = my_touchpad_read;
  lv_indev_drv_register(&indev_drv);

  /*Or try out a demo. Don't forget to enable the demos in lv_conf.h. E.g. LV_USE_DEMOS_WIDGETS*/
  // lv_demo_widgets();
  ui_init();

  // The temporary persistent SNAPACK marker is retired here.
  // The new carousel entry and Screen5 now identify our modified firmware.
  updateScreen(screen1_index);

  // Bind the volume slider value-change event
  lv_obj_add_event_cb(ui_VolumeArc, volumeArcEventCb, LV_EVENT_VALUE_CHANGED, NULL);
  // Bind the temperature slider value-change event
  lv_obj_add_event_cb(ui_TempArc, tempArcEventCb, LV_EVENT_VALUE_CHANGED, NULL);

  delay(200);
  initBacklight();
  pcf8574.digitalWrite(P3, LOW);

  // Initialize pin 43 as the LED PWM output
  ledcSetup(breathPwmChannel, pwmFreq, pwmResolution);
  ledcAttachPin(BREATH_LED_PIN, breathPwmChannel);
  // At startup, do not breathe; hold brightness corresponding to the current value
  ledcWrite(breathPwmChannel, (volumeValue * 255) / 100);

  xTaskCreatePinnedToCore(encTask, "ENC", 2048, NULL, 1, &encTaskHandle, 0);
  xTaskCreatePinnedToCore(swTask, "SWITCH", 2048, NULL, 1, &swTaskHandle, 0);

  // Initialize remote LED-strip control state
  Serial.println("Initializing remote LED-strip control...");
  lastLedCountSent = -1;
  Serial.println("Remote LED-strip control initialization complete");

  Serial.println("Settings completed, ready to connect to WiFi...");
  connectWiFi();

  // After WiFi connects, obtain the Advance device IP address
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("WiFi connected; preparing UDP communication...");
    Serial.print("Local IP address: ");
    Serial.println(WiFi.localIP());
  }
}

void loop() {
  lv_timer_handler();

  delay(5);
}

// Send the commanded number of illuminated LEDs to the Advance device
void sendLedStripCommand(int ledCount) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi not connected; cannot send LED-strip command");
    return;
  }

  ledCount = constrain(ledCount, 0, REMOTE_NUM_LEDS);
  String command = "LEDCOUNT:" + String(ledCount);
  udp.beginPacket(ADVANCE_IP, ADVANCE_PORT);
  udp.write((uint8_t*)command.c_str(), command.length());
  bool sent = udp.endPacket();
  if (sent) {
    Serial.printf("LED-strip command sent successfully: %s\n", command.c_str());
  } else {
    Serial.println("LED-strip command failed to send");
  }
}

// Map the temperature value and control the WS2812 LED strip on Advance
void updateLedStripByTemperature(int temp) {
  temp = constrain(temp, 0, 200);
  int ledCount = map(temp, 0, 200, 0, REMOTE_NUM_LEDS);
  if (ledCount == lastLedCountSent) return;
  lastLedCountSent = ledCount;
  sendLedStripCommand(ledCount);
  Serial.printf("Temperature: %d -> Illuminated LED count: %d\n", temp, ledCount);
}

// Volume-slider event: update the value and send it to Advance via UDP
void volumeArcEventCb(lv_event_t *e) {
  if (lv_event_get_code(e) != LV_EVENT_VALUE_CHANGED) return;
  lv_obj_t *arc = lv_event_get_target(e);
  int value = lv_arc_get_value(arc); // 0-100

  // Update UI text using the same format as the rotary-control logic
  char volText[8];
  if (value == 100) {
    snprintf(volText, sizeof(volText), "%d%%", value);
    lv_label_set_text(ui_VolNum, volText);
  } else {
    snprintf(volText, sizeof(volText), " %d%%", value);
    lv_label_set_text(ui_VolNum, volText);
  }
  // Set LED brightness directly to the corresponding duty cycle
  volumeValue = value;
  ledcWrite(breathPwmChannel, (volumeValue * 255) / 100);
}


// Temperature-slider event: update temperature text and control the servo
void tempArcEventCb(lv_event_t *e) {
  if (lv_event_get_code(e) != LV_EVENT_VALUE_CHANGED) return;
  lv_obj_t *arc = lv_event_get_target(e);
  int value = lv_arc_get_value(arc); // 0-200

  // Update temperature text (using the existing format)
  char tempText[8];
  if (value >= 100 && value <= 200) {
    snprintf(tempText, sizeof(tempText), " %d%°", value);
    lv_label_set_text(ui_TempNum, tempText);
  } else {
    snprintf(tempText, sizeof(tempText), "  %d%°", value);
    lv_label_set_text(ui_TempNum, tempText);
  }

  // Control the remote LED strip (map 0-200 to 0-15 LEDs)
  updateLedStripByTemperature(value);
}


int last_counter = 0;
int counter = 0;
int currentStateCLK;
int lastStateCLK;
String currentDir = "";
bool one_test = false;

void performClickAction() {
  current_screen = lv_scr_act();

  // Four carousel destinations now exist.  The OEM screens are retained
  // unchanged and shifted one index to make room for SNAPACK at index 0.
  if (current_screen == ui_Screen1) {
    if (screen1_index == 0) {
      _ui_screen_change(&ui_Screen5, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen5_screen_init);
    } else if (screen1_index == 1) {
      _ui_screen_change(&ui_Screen2, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen2_screen_init);
    } else if (screen1_index == 2) {
      _ui_screen_change(&ui_Screen3, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen3_screen_init);
    } else if (screen1_index == 3) {
      _ui_screen_change(&ui_Screen4, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen4_screen_init);
    }
  }
}

void performDoubleClickAction() {
  current_screen = lv_scr_act();

  // Extend the OEM double-click return path to the new SNAPACK screen.
  if (current_screen == ui_Screen5 ||
      current_screen == ui_Screen2 ||
      current_screen == ui_Screen3 ||
      current_screen == ui_Screen4) {
    _ui_screen_change(&ui_Screen1, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen1_screen_init);
  }
}

void processEncoder() {
  current_screen = lv_scr_act();

  if (current_screen == ui_Screen1) {
    // Four carousel positions now exist: 0 through 3.
    if (position_tmp == 1) {
      if (screen1_index < 3) screen1_index++;
    } else if (position_tmp == 0) {
      if (screen1_index > 0) screen1_index--;
    }

    Serial.printf("cur_index: %d\n", screen1_index);
    updateScreen(screen1_index);
    position_tmp = -1;
  }
}

void encTask(void *pvParameters) {
  while (1) {
    // Read the current state of CLK
    currentStateCLK = digitalRead(ENCODER_A_PIN);
    // If last and current state of CLK are different, then pulse occurred
    // React to only 1 state change to avoid double count
    if (currentStateCLK != lastStateCLK && currentStateCLK == 1) {
      current_screen = lv_scr_act();
      // If the DT state is different than the CLK state then
      // the encoder is rotating CCW so decrement
      if (digitalRead(ENCODER_B_PIN) != currentStateCLK) {
        if (abs(last_counter - counter) > 200) {
          continue;
        }

        if (current_screen == ui_Screen2) {
          int currentVol = lv_arc_get_value(ui_VolumeArc);
          Serial.printf(" -- currentVol = %d\n", currentVol);
          int newVol = (currentVol - 5) < 0 ? 0 : currentVol - 5;
          Serial.printf(" -- END currentVol = %d\n", newVol);
          lv_arc_set_value(ui_VolumeArc, newVol);

          volumeValue = newVol; // Synchronize global volume

          char volText[8];
          if (newVol == 100) {
            snprintf(volText, sizeof(volText), "%d%%", newVol);
            lv_label_set_text(ui_VolNum, volText);
          } else {
            snprintf(volText, sizeof(volText), " %d%%", newVol);
            lv_label_set_text(ui_VolNum, volText);
          }

          // Set LED brightness directly
          ledcWrite(breathPwmChannel, (volumeValue * 255) / 100);

        } else if (current_screen == ui_Screen3) {
          int currentTemp = lv_arc_get_value(ui_TempArc);
          Serial.printf(" -- currentVol = %d\n", currentTemp);
          int newTemp = (currentTemp - 5) < 0 ? 0 : currentTemp - 5;
          Serial.printf(" -- END currentVol = %d\n", newTemp);
          lv_arc_set_value(ui_TempArc, newTemp);
          char TempText[8];
          if (newTemp >= 100 && newTemp <= 200) {
            snprintf(TempText, sizeof(TempText), "%d%°C", newTemp);
            lv_label_set_text(ui_TempNum, TempText);
          } else {
            snprintf(TempText, sizeof(TempText), " %d%°C", newTemp);
            lv_label_set_text(ui_TempNum, TempText);
          }

          // Update the remote LED strip
          updateLedStripByTemperature(newTemp);

        } else if (current_screen == ui_Screen4) {
          int currentLight = lv_arc_get_value(ui_lightArc);
          Serial.printf(" -- currentLight = %d\n", currentLight);
          int newLight = (currentLight - 5) < 0 ? 0 : currentLight - 5;
          Serial.printf(" -- END currentLight = %d\n", newLight);
          lv_arc_set_value(ui_lightArc, newLight);

          lightValue = newLight; // Synchronize global brightness

          char LightText[8];
          if (newLight == 100) {
            snprintf(LightText, sizeof(LightText), "%d%%", newLight);
            lv_label_set_text(ui_LightNum, LightText);
          } else {
            snprintf(LightText, sizeof(LightText), " %d%%", newLight);
            lv_label_set_text(ui_LightNum, LightText);
          }
          int pwm_value = (newLight * 255) / 100;
          ledcSetup(pwmChannel, pwmFreq, pwmResolution);
          ledcAttachPin(SCREEN_BACKLIGHT_PIN, pwmChannel);
          ledcWrite(pwmChannel, pwm_value);
        }
        position_tmp = 0;

        counter++;
        currentDir = "CCW"; // Counterclockwise
      } else {
        if (one_test == false)  
        {
          one_test = true;
          continue;
        }
        if (current_screen == ui_Screen2) {
          int currentVol = lv_arc_get_value(ui_VolumeArc);
          Serial.printf(" ++ currentVol = %d\n", currentVol);
          int newVol = (currentVol + 5) > 100 ? 100 : currentVol + 5;
          Serial.printf(" ++ END currentVol = %d\n", newVol);
          lv_arc_set_value(ui_VolumeArc, newVol);

          volumeValue = newVol; // Synchronize global volume

          char volText[8];
          if (newVol == 100) {
            snprintf(volText, sizeof(volText), "%d%%", newVol);
            lv_label_set_text(ui_VolNum, volText);
          } else {
            snprintf(volText, sizeof(volText), " %d%%", newVol);
            lv_label_set_text(ui_VolNum, volText);
          }

          // Set LED brightness directly
          ledcWrite(breathPwmChannel, (volumeValue * 255) / 100);

        } else if (current_screen == ui_Screen3) {
          int currentTemp = lv_arc_get_value(ui_TempArc);
          Serial.printf(" ++ currentVol = %d\n", currentTemp);
          int newTemp = (currentTemp + 5) > 200 ? 200 : currentTemp + 5;
          Serial.printf(" ++ END currentVol = %d\n", newTemp);
          lv_arc_set_value(ui_TempArc, newTemp);

          char TempText[8];
          if (newTemp >= 100 && newTemp <= 200) {
            snprintf(TempText, sizeof(TempText), "%d%°C", newTemp);
            lv_label_set_text(ui_TempNum, TempText);
          } else {
            snprintf(TempText, sizeof(TempText), " %d%°C", newTemp);
            lv_label_set_text(ui_TempNum, TempText);
          }

          // Update the remote LED strip
          updateLedStripByTemperature(newTemp);

        } else if (current_screen == ui_Screen4) {
          int currentLight = lv_arc_get_value(ui_lightArc);
          Serial.printf(" ++ currentLight = %d\n", currentLight);
          int newLight = (currentLight + 5) > 100 ? 100 : currentLight + 5;
          Serial.printf(" ++ END currentLight = %d\n", newLight);
          lv_arc_set_value(ui_lightArc, newLight);

          lightValue = newLight; // Synchronize global brightness

          char LightText[8];
          if (newLight == 100) {
            snprintf(LightText, sizeof(LightText), "%d%%", newLight);
            lv_label_set_text(ui_LightNum, LightText);
          } else {
            snprintf(LightText, sizeof(LightText), " %d%%", newLight);
            lv_label_set_text(ui_LightNum, LightText);
          }
          
          int pwm_value = (newLight * 255) / 100;
          ledcSetup(pwmChannel, pwmFreq, pwmResolution);
          ledcAttachPin(SCREEN_BACKLIGHT_PIN, pwmChannel);
          ledcWrite(pwmChannel, pwm_value);
        }
        position_tmp = 1;
        counter--;
        currentDir = "CW";
      }

      Serial.print("Direction: ");
      Serial.print(currentDir);
      Serial.print(" | Counter: ");
      Serial.println(counter);
      last_counter = counter;
      processEncoder();
    }

    if (pressedFlag)
    {
      if (pressCount == 1 && millis() >= singleClickTimeout) {
        Serial.println("Single Click Detected");
        performClickAction();
        pressCount = 0;
        pressedFlag = false;

      }
      else if (pressCount >= 2) {
        Serial.println("Double Click Detected");
        performDoubleClickAction();
        pressCount = 0;
        pressedFlag = false;
      }
    }
    // Remember last CLK state
    lastStateCLK = currentStateCLK;
    vTaskDelay(pdMS_TO_TICKS(2));
  }
}

void updateScreen(int index) {
  // SINGLE SOURCE OF TRUTH FOR THE FOUR-ITEM CAROUSEL
  // Both rotary movement and touch swipes arrive here.
  // Selected item is centered/cyan; immediate neighbors are white at
  // +/-140 pixels; items farther away are hidden.

  if (index < 0) index = 0;
  if (index > 3) index = 3;
  screen1_index = index;

  // Hide every carousel object first.  Each case reveals only what it
  // needs, preventing stale objects from a previous position.
  lv_obj_add_flag(ui_snapackBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_snapackTextBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_snapackTextWhite, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_volumeBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_volumeWhite, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_volumeTextBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_volumeTextWhite, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_tempBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_tempWhite, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_tempTextBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_tempTextWhite, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_lightBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_lightWhite, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_lightTextBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_lightTextWhite, LV_OBJ_FLAG_HIDDEN);

  switch (index) {
    case 0:  // SNAPACK
      lv_obj_clear_flag(ui_snapackBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_snapackTextBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_snapackBlue, 0);
      lv_obj_set_x(ui_snapackTextBlue, 0);
      lv_obj_set_x(ui_snapackTextWhite, 0);

      lv_obj_clear_flag(ui_volumeWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_volumeTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_volumeBlue, 140);
      lv_obj_set_x(ui_volumeWhite, 140);
      lv_obj_set_x(ui_volumeTextBlue, 140);
      lv_obj_set_x(ui_volumeTextWhite, 140);
      break;

    case 1:  // OEM Volume
      lv_obj_clear_flag(ui_snapackTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_snapackBlue, -140);
      lv_obj_set_x(ui_snapackTextBlue, -140);
      lv_obj_set_x(ui_snapackTextWhite, -140);

      lv_obj_clear_flag(ui_volumeBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_volumeTextBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_volumeBlue, 0);
      lv_obj_set_x(ui_volumeWhite, 0);
      lv_obj_set_x(ui_volumeTextBlue, 0);
      lv_obj_set_x(ui_volumeTextWhite, 0);

      lv_obj_clear_flag(ui_tempWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_tempTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_tempBlue, 140);
      lv_obj_set_x(ui_tempWhite, 140);
      lv_obj_set_x(ui_tempTextBlue, 140);
      lv_obj_set_x(ui_tempTextWhite, 140);
      break;

    case 2:  // OEM Temp
      lv_obj_clear_flag(ui_volumeWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_volumeTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_volumeBlue, -140);
      lv_obj_set_x(ui_volumeWhite, -140);
      lv_obj_set_x(ui_volumeTextBlue, -140);
      lv_obj_set_x(ui_volumeTextWhite, -140);

      lv_obj_clear_flag(ui_tempBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_tempTextBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_tempBlue, 0);
      lv_obj_set_x(ui_tempWhite, 0);
      lv_obj_set_x(ui_tempTextBlue, 0);
      lv_obj_set_x(ui_tempTextWhite, 0);

      lv_obj_clear_flag(ui_lightWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_lightTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_lightBlue, 140);
      lv_obj_set_x(ui_lightWhite, 140);
      lv_obj_set_x(ui_lightTextBlue, 140);
      lv_obj_set_x(ui_lightTextWhite, 140);
      break;

    case 3:  // OEM Light
      lv_obj_clear_flag(ui_tempWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_tempTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_tempBlue, -140);
      lv_obj_set_x(ui_tempWhite, -140);
      lv_obj_set_x(ui_tempTextBlue, -140);
      lv_obj_set_x(ui_tempTextWhite, -140);

      lv_obj_clear_flag(ui_lightBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_lightTextBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_lightBlue, 0);
      lv_obj_set_x(ui_lightWhite, 0);
      lv_obj_set_x(ui_lightTextBlue, 0);
      lv_obj_set_x(ui_lightTextWhite, 0);
      break;
  }
}

void swTask(void *pvParameters) {
  while (1) {
    currentSW = pcf8574.digitalRead(P5, true);
    if (currentSW == LOW) {
      // Serial.printf("currentSW == LOW\n");
      static unsigned long lastInterruptTime = 0;
      unsigned long currentTime = millis();

      if (currentTime - lastInterruptTime > debounceTime) {
        pressCount++;
        pressedFlag = true;
        if (pressCount == 1) {
          singleClickTimeout = currentTime + doubleClickTime;
        }
      }
      lastInterruptTime = currentTime;
    }
    vTaskDelay(pdMS_TO_TICKS(5));
  }
}

