// SNAPACK SCREEN 5
//
// This is the first screen owned specifically by SNAPACK.
// It borrows the proven visual language of the OEM Volume screen, but
// contains no OEM volume behavior.
//
// IMPORTANT: 12.6 V is a STATIC PLACEHOLDER in this revision.
// It is not yet connected to an ADS1115 or any real measurement.

#include "ui.h"

void ui_Screen5_screen_init(void)
{
    ui_Screen5 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen5, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_PRESS_LOCK | LV_OBJ_FLAG_SCROLLABLE |
                      LV_OBJ_FLAG_SCROLL_ELASTIC | LV_OBJ_FLAG_SCROLL_MOMENTUM);
    lv_obj_set_style_bg_color(ui_Screen5, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen5, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_img_src(ui_Screen5, &ui_img_1761703117, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Reuse the OEM arc treatment as a visual scaffold only.
    ui_SnapackArc = lv_arc_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackArc, 355);
    lv_obj_set_height(ui_SnapackArc, 364);
    lv_obj_set_x(ui_SnapackArc, -1);
    lv_obj_set_y(ui_SnapackArc, 4);
    lv_obj_set_align(ui_SnapackArc, LV_ALIGN_CENTER);
    lv_arc_set_value(ui_SnapackArc, 63);
    lv_obj_clear_flag(ui_SnapackArc, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_style_arc_width(ui_SnapackArc, 25, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_arc_rounded(ui_SnapackArc, false, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_arc_img_src(ui_SnapackArc, &ui_img_175727810, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_arc_width(ui_SnapackArc, 25, LV_PART_INDICATOR | LV_STATE_DEFAULT);
    lv_obj_set_style_arc_rounded(ui_SnapackArc, false, LV_PART_INDICATOR | LV_STATE_DEFAULT);
    lv_obj_set_style_arc_img_src(ui_SnapackArc, &ui_img_1961151970, LV_PART_INDICATOR | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_SnapackArc, 0, LV_PART_KNOB | LV_STATE_DEFAULT);

    // This label is intentionally named as the future live-value target.
    ui_SnapackValue = lv_label_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackValue, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_SnapackValue, LV_SIZE_CONTENT);
    lv_obj_set_x(ui_SnapackValue, 0);
    lv_obj_set_y(ui_SnapackValue, -3);
    lv_obj_set_align(ui_SnapackValue, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SnapackValue, "12.6 V");
    lv_obj_set_style_text_color(ui_SnapackValue, lv_color_hex(0x33DCFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_SnapackValue, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_SnapackValue, &lv_font_montserrat_48, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackLabel = lv_label_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackLabel, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_SnapackLabel, LV_SIZE_CONTENT);
    lv_obj_set_x(ui_SnapackLabel, 0);
    lv_obj_set_y(ui_SnapackLabel, 67);
    lv_obj_set_align(ui_SnapackLabel, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SnapackLabel, "PACK VOLTAGE");
    lv_obj_set_style_text_color(ui_SnapackLabel, lv_color_hex(0xFFFFFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_SnapackLabel, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_SnapackLabel, &lv_font_montserrat_20, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Keep a familiar Return control while the new screen is being proven.
    ui_SnapackReturnBt = lv_btn_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackReturnBt, 120);
    lv_obj_set_height(ui_SnapackReturnBt, 40);
    lv_obj_set_x(ui_SnapackReturnBt, 2);
    lv_obj_set_y(ui_SnapackReturnBt, 142);
    lv_obj_set_align(ui_SnapackReturnBt, LV_ALIGN_CENTER);
    lv_obj_set_style_bg_color(ui_SnapackReturnBt, lv_color_hex(0x33DCFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_SnapackReturnBt, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(ui_SnapackReturnBt, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackReturnLabel = lv_label_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_SnapackReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_x(ui_SnapackReturnLabel, 2);
    lv_obj_set_y(ui_SnapackReturnLabel, 141);
    lv_obj_set_align(ui_SnapackReturnLabel, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SnapackReturnLabel, "Return");
    lv_obj_set_style_text_font(ui_SnapackReturnLabel, &lv_font_montserrat_22, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_add_event_cb(ui_SnapackReturnBt, ui_event_screen5ReturnBt, LV_EVENT_ALL, NULL);
}
