SNAPACK UI STEP 1
==================

Coordinated five-file revision.

Copy:
  snapack.ino -> /home/valued/Arduino/snapack/snapack.ino

Copy into /home/valued/Arduino/libraries/UI/:
  ui.c
  ui.h
  ui_Screen1.c
  ui_Screen5.c

Expected physical behavior:
  * Elecrow splash remains.
  * Carousel order becomes SNAPACK, Volume, Temp, Light.
  * SNAPACK is selected first after the splash.
  * Rotary and touch swipes navigate all four positions.
  * SNAPACK opens new Screen5.
  * Screen5 shows STATIC placeholder 12.6 V / PACK VOLTAGE.
  * Return button and double-click return to the carousel.
  * OEM Volume, Temp, and Light screens remain available.

12.6 V IS NOT A LIVE MEASUREMENT YET.

After copying:
  1. Reopen snapack.ino in Arduino IDE.
  2. Verify/compile once.
  3. Export Compiled Binary.
  4. Flash with the already-proven esptool --no-stub command.
