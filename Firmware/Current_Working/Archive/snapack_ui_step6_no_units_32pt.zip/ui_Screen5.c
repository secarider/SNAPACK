// SNAPACK SCREEN 5
//
// STEP 4 PURPOSE:
//   Improve physical readability and use more of the available round screen.
//
// Changes from the physically verified Step 3 layout:
//   - Keep five cell voltages plus PACK in a two-row / three-column grid.
//   - Remove the repeated word "CELL" from each measurement heading.
//   - Retain only identifiers 1, 2, 3, 4, 5, and PACK.
//   - Increase numeric readouts from Montserrat 24 to Montserrat 28.
//   - Enlarge the Return button and its label.
//   - Replace the top "CELL VOLTAGES" title with "SIMULATED" while the
//     displayed values are still development data.
//
// IMPORTANT:
//   No ADS1115 data is being read yet.
//
// FUTURE THEME NOTE:
//   Screen colors are deliberately centralized below.  That gives SNAPACK
//   one obvious place to implement a high-contrast DAY theme later:
//
//       NIGHT: black background / cyan values / white labels
//       DAY:   white background / black values / black labels
//
//   Theme selection can first be manual.  If a light sensor is later added,
//   the same theme-selection function can be driven automatically without
//   redesigning the measurement screen.

#include "ui.h"
#include <stdio.h>

// ---------------------------------------------------------------------
// SNAPACK SCREEN COLORS
// ---------------------------------------------------------------------
//
// Keep presentation colors in one place instead of scattering constants
// throughout the screen construction code.  This is the first small step
// toward future selectable DAY / NIGHT presentation.
#define SNAPACK_BG_COLOR    lv_color_hex(0x000000)
#define SNAPACK_TEXT_COLOR  lv_color_hex(0xFFFFFF)
#define SNAPACK_VALUE_COLOR lv_color_hex(0x33DCFF)

// Format integer millivolts as X.XXX V.
static void snapack_set_voltage_label(lv_obj_t * label, int millivolts)
{
    char text[16];

    int volts = millivolts / 1000;
    int remainder_mV = millivolts % 1000;

    if (remainder_mV < 0) {
        remainder_mV = -remainder_mV;
    }

    snprintf(text, sizeof(text), "%d.%03d", volts, remainder_mV);
    lv_label_set_text(label, text);
}

// Create one measurement heading and one independently updateable value.
//
// The heading is intentionally minimal.  Five cells are identified simply
// as 1 through 5.  PACK remains spelled out because it is a different type
// of value and should be recognizable instantly.
static lv_obj_t * snapack_create_measurement(lv_obj_t * parent,
                                              const char * heading_text,
                                              int x,
                                              int y)
{
    lv_obj_t * heading = lv_label_create(parent);
    lv_obj_set_width(heading, LV_SIZE_CONTENT);
    lv_obj_set_height(heading, LV_SIZE_CONTENT);
    lv_obj_set_x(heading, x);
    lv_obj_set_y(heading, y - 22);
    lv_obj_set_align(heading, LV_ALIGN_CENTER);
    lv_label_set_text(heading, heading_text);
    lv_obj_set_style_text_color(heading, SNAPACK_TEXT_COLOR, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(heading, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(heading, &lv_font_montserrat_20, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_t * value = lv_label_create(parent);
    lv_obj_set_width(value, LV_SIZE_CONTENT);
    lv_obj_set_height(value, LV_SIZE_CONTENT);
    lv_obj_set_x(value, x);
    lv_obj_set_y(value, y + 9);
    lv_obj_set_align(value, LV_ALIGN_CENTER);
    lv_label_set_text(value, "0.000");
    lv_obj_set_style_text_color(value, SNAPACK_VALUE_COLOR, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(value, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Step 4 used Montserrat 24.  Physical testing showed that the
    // measurements could still use more of the available screen area,
    // so Step 6 uses Montserrat 32.
    lv_obj_set_style_text_font(value, &lv_font_montserrat_32, LV_PART_MAIN | LV_STATE_DEFAULT);

    return value;
}

// ---------------------------------------------------------------------
// PUBLIC DATA-TO-UI BOUNDARY
// ---------------------------------------------------------------------
//
// This interface is unchanged from Step 3.  Presentation changes therefore
// do not require measurement/application changes.
void ui_update_snapack_cells(int cell1_mV,
                             int cell2_mV,
                             int cell3_mV,
                             int cell4_mV,
                             int cell5_mV,
                             int pack_mV)
{
    if (ui_SnapackCell1Value) snapack_set_voltage_label(ui_SnapackCell1Value, cell1_mV);
    if (ui_SnapackCell2Value) snapack_set_voltage_label(ui_SnapackCell2Value, cell2_mV);
    if (ui_SnapackCell3Value) snapack_set_voltage_label(ui_SnapackCell3Value, cell3_mV);
    if (ui_SnapackCell4Value) snapack_set_voltage_label(ui_SnapackCell4Value, cell4_mV);
    if (ui_SnapackCell5Value) snapack_set_voltage_label(ui_SnapackCell5Value, cell5_mV);
    if (ui_SnapackPackValue)  snapack_set_voltage_label(ui_SnapackPackValue, pack_mV);
}

void ui_Screen5_screen_init(void)
{
    ui_Screen5 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen5, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_PRESS_LOCK | LV_OBJ_FLAG_SCROLLABLE |
                      LV_OBJ_FLAG_SCROLL_ELASTIC | LV_OBJ_FLAG_SCROLL_MOMENTUM);

    lv_obj_set_style_bg_color(ui_Screen5, SNAPACK_BG_COLOR, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen5, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // -----------------------------------------------------------------
    // DEVELOPMENT-STATE TITLE
    // -----------------------------------------------------------------
    //
    // While these numbers are synthetic, use the most valuable title space
    // to state that fact clearly.  When ADS1115 measurements are connected,
    // this can become "CELL VOLTAGES" again or be removed entirely.
    lv_obj_t * title = lv_label_create(ui_Screen5);
    lv_obj_set_width(title, LV_SIZE_CONTENT);
    lv_obj_set_height(title, LV_SIZE_CONTENT);
    lv_obj_set_x(title, 0);
    lv_obj_set_y(title, -158);
    lv_obj_set_align(title, LV_ALIGN_CENTER);
    lv_label_set_text(title, "SIMULATED");
    lv_obj_set_style_text_color(title, SNAPACK_TEXT_COLOR, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(title, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(title, &lv_font_montserrat_20, LV_PART_MAIN | LV_STATE_DEFAULT);

    // -----------------------------------------------------------------
    // TWO ROWS OF THREE MEASUREMENTS
    // -----------------------------------------------------------------
    //
    // Removing the repeated word CELL lets the actual voltages occupy more
    // visual space.  The three-column geometry remains familiar and balanced.
    //
    // Top row: 1 / 2 / 3
    ui_SnapackCell1Value = snapack_create_measurement(ui_Screen5, "1",    -132, -68);
    ui_SnapackCell2Value = snapack_create_measurement(ui_Screen5, "2",       0, -68);
    ui_SnapackCell3Value = snapack_create_measurement(ui_Screen5, "3",     132, -68);

    // Bottom row: 4 / 5 / PACK
    ui_SnapackCell4Value = snapack_create_measurement(ui_Screen5, "4",    -132,  40);
    ui_SnapackCell5Value = snapack_create_measurement(ui_Screen5, "5",       0,  40);
    ui_SnapackPackValue  = snapack_create_measurement(ui_Screen5, "PACK",  132,  40);

    // -----------------------------------------------------------------
    // RETURN CONTROL
    // -----------------------------------------------------------------
    //
    // Physical testing showed that the existing Return control could afford
    // to be larger.  Increase both the touch target and the visible label.
    ui_SnapackReturnBt = lv_btn_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackReturnBt, 138);
    lv_obj_set_height(ui_SnapackReturnBt, 46);
    lv_obj_set_x(ui_SnapackReturnBt, 0);
    lv_obj_set_y(ui_SnapackReturnBt, 164);
    lv_obj_set_align(ui_SnapackReturnBt, LV_ALIGN_CENTER);
    lv_obj_set_style_bg_color(ui_SnapackReturnBt, SNAPACK_VALUE_COLOR, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_SnapackReturnBt, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(ui_SnapackReturnBt, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackReturnLabel = lv_label_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_SnapackReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_x(ui_SnapackReturnLabel, 0);
    lv_obj_set_y(ui_SnapackReturnLabel, 164);
    lv_obj_set_align(ui_SnapackReturnLabel, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SnapackReturnLabel, "Return");
    lv_obj_set_style_text_color(ui_SnapackReturnLabel, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_SnapackReturnLabel, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_SnapackReturnLabel, &lv_font_montserrat_20, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_add_event_cb(ui_SnapackReturnBt, ui_event_screen5ReturnBt, LV_EVENT_ALL, NULL);
}
