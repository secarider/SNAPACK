SNAPACK UI STEP 5 — FINAL READABILITY NUDGE
===========================================

Baseline:
  Physically verified Step 4 readability layout.

Purpose:
  Increase the primary measurement information one more time on the
  physical 2.1-inch display without changing the proven layout.

ONLY PRESENTATION CHANGES:
  * Cell/pack numeric values:
      Montserrat 24 -> Montserrat 28
  * Measurement identifiers 1,2,3,4,5,PACK:
      Montserrat 16 -> Montserrat 20

UNCHANGED:
  * SIMULATED title
  * Two-row / three-column positions
  * Five cells + PACK
  * Simulated values and five-cell pack calculation
  * Return button size and position
  * Colors
  * Carousel/navigation
  * OEM Volume / Temp / Light screens
  * Measurement-to-UI interface
  * No ADS1115 code yet

Expected data:
  1 = 4.180 V
  2 = 4.160 V
  3 = 4.170 V
  4 = 4.170 V
  5 = 4.180 V
  PACK = 20.860 V

Install:
  snapack.ino ->
    /home/valued/Arduino/snapack/snapack.ino

  ui.c, ui.h, ui_Screen1.c, ui_Screen5.c ->
    /home/valued/Arduino/libraries/UI/

Only ui_Screen5.c changed from the verified Step 4 checkpoint.
The complete current file set is included for archival consistency.

Test:
  1. Reopen snapack.ino in Arduino IDE.
  2. Verify/compile.
  3. Export Compiled Binary.
  4. Flash with the proven esptool --no-stub command.
  5. Check especially the outer 1/3/4/PACK values for round-screen edge clearance.
  6. Confirm all four carousel screens and Return behavior.

CORRECTION
----------
The first Step 5 archive accidentally inherited the pre-fix Step 4 color
declarations.  This corrected archive uses preprocessor macros:

  #define SNAPACK_BG_COLOR    lv_color_hex(0x000000)
  #define SNAPACK_TEXT_COLOR  lv_color_hex(0xFFFFFF)
  #define SNAPACK_VALUE_COLOR lv_color_hex(0x33DCFF)

This preserves the intended Step 5 font changes:
  values = Montserrat 28
  headings = Montserrat 20

STEP 6 — REMOVE REDUNDANT UNIT TEXT / INCREASE VALUE SIZE
---------------------------------------------------------
Physical testing showed additional perimeter space remained, but the
repeated trailing "V" limited horizontal room between the three columns.

Changes from corrected Step 5:
  * Cell and PACK values no longer include a trailing "V".
  * Numeric value font increases from Montserrat 28 to Montserrat 32.
  * Identifier font remains Montserrat 20.
  * Grid positions remain unchanged.
  * SIMULATED title remains unchanged for now.
  * Return button remains unchanged.
  * No measurement logic changes.
  * No ADS1115 code added.

Expected display values:
  1 = 4.180
  2 = 4.160
  3 = 4.170
  4 = 4.170
  5 = 4.180
  PACK = 20.860

Later, once live measurements are connected, the top title can return to:
  CELL VOLTAGES

The title then provides the unit context without repeating "V" after every
individual numeric value.
