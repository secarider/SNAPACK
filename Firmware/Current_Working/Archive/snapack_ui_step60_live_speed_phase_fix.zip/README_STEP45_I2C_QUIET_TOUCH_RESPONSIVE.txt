SNAPACK STEP 45 — I2C/ SERIAL QUIETNESS RESPONSIVENESS TEST

Built from Step 44.

This is deliberately an isolation pass aimed at the severe accumulated UI lag.

REMOVED FROM RECURRING OPERATION
- recurring I2C address scans
- recurring full ADS1115 diagnostic sweep / SNAPACK LIVE HARDWARE dump
- per-sample TOUCHING Serial messages
- routine carousel swipe Serial chatter
- routine encoder direction/counter chatter

I2C SCAN
- one address scan is performed once at boot after Wire.begin()
- no recurring bus scan

OPERATIONAL ADS SERVICES RETAINED
- OTC fast acquisition: 20 ms target (~50 Hz)
- CdS theme sample: 500 ms
- live cells: slowed from 250 ms to 500 ms
- native OneWire remains fully dormant pending DS2484

CURRENT UI / EVENT LOGIC RETAINED
- current/gauge redraw throttled to 100 ms
- event start/end Serial messages remain
- 12 A start, 3 qualifying samples, 1/4 EMA, <=5 A end hold
- RAM peak tracking retained

CAROUSEL ICON CLEANUP
- V / T / A / i placeholder icons now remain visible when their entries are
  left/right neighbors, not only when centered.
- Touch selection remains centralized in the lower half; the custom transparent
  buttons are not used as touch hit targets.

HARDWARE
- Leave the newly installed 100 nF OTC signal-to-SYS-GND capacitor in place.
