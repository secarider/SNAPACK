SNAPACK STEP 52 — BRIGHTER OPPOSING ACCENT + OEM ICON RECOLOR FIX

Built from corrected Step51.

Two visible fixes:

1. Selected accent brightness
- Keeps the complementary/opposing hue from Step51.
- Blends that complement 30% toward white.
- This makes selected labels and icons easier to read without enlarging them.

2. Original Elecrow selected icons
- Volume / Temp / Light selected icons are implemented as BACKGROUND IMAGES
  on transparent button objects, not lv_img objects.
- Step51 attempted lv_img recolor, which therefore did not affect them.
- Step52 uses LVGL bg_img recolor + full recolor opacity.
- Their selected icon color should now follow the same dynamic opposing accent
  as the selected labels.

Custom SNAPACK V/T/A/i behavior remains:
- off-center icon + label = white
- centered icon + label = brighter opposing accent

All Step51/50/48/47 current, I2C, glitch rejection, Diagnostic 4S row,
touch, carousel, and theme behavior is retained.
