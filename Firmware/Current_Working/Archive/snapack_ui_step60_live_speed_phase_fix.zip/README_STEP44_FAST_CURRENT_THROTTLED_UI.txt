SNAPACK STEP 44 — FAST CURRENT ACQUISITION / THROTTLED UI

OTC acquisition target: 20 ms (~50 samples/sec).

Fast path:
- 1/4 EMA smoothing
- current-event detection
- RAM event peak
- session peak

UI path:
- Current number / 25-segment gauge / PEAK: 100 ms (~10 Hz)
- Diagnostic changing values: 100 ms (~10 Hz)
- Event start/end force an immediate UI update.

The slow ~2-second Serial diagnostic OTC read no longer feeds the event
detector a second time.

Temperature:
- native GPIO OneWire fully dormant pending DS2484
- no startup discovery
- no recurring discovery
- no temperature conversion request

Current event settings retained:
- START >= 12 A
- 3 consecutive qualifying filtered samples
- END <= 5 A for 500 ms

Step43 touch behavior, themes, Current geometry, and Diagnostic animation
remain unchanged.

Perfboard companion experiment:
100 nF ceramic from OTC signal to SYS GND at/near the ADS1115 OTC input.
