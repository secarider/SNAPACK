SNAPACK STEP 19 — TEMP THEME + CURRENT SCREEN + FINAL-LOOK TITLES

Baseline:
  Physically accepted Step 18.

Changes completed in this package:

1. Remove development wording from SNAPACK titles:
     Screen5: "Simulated Voltage"     -> "Cell Voltage"
     Screen6: "Simulated Temperature" -> "Temperature"

2. Temperature Screen6 receives DAY/NIGHT behavior matching Screen5:
     short Return -> carousel
     long Return  -> toggle DAY/NIGHT and remain on Temperature

   Temperature arc also changes with the theme:
     NIGHT = dark track / cyan indicator
     DAY   = light track / black indicator

3. Add first-pass SNAPACK Current screen:
     title = Current
     one dominant current number
     separate A unit
     simulated source = 187 A for now
     DAY/NIGHT toggle on long Return
     short Return -> carousel

4. Carousel grows to six positions:
     0 = SNAPACK Cell Voltage
     1 = SNAPACK Temperature
     2 = SNAPACK Current
     3 = OEM Volume
     4 = OEM Temp
     5 = OEM Light

New file:
  ui_Screen7.c

Copy ui_Screen7.c into:
  /home/valued/Arduino/libraries/UI/

Current-screen note:
  This first pass intentionally uses proven built-in Montserrat 48 for the
  numeric value.  It establishes navigation, theme behavior, and data path.
  A purpose-built larger numeric font can be addressed later only if the
  final cranking display truly needs a much larger center number.

Still simulated internally:
  Voltage, temperature, and current data sources are still development data.
  The visible "Simulated" labels are removed so the screens can be judged
  against a more final-looking presentation.
