SNAPACK STEP 46 — OTC ZERO CAPTURE RECOVERY

Built directly from Step45.

Cause found:
Step45 intentionally disabled the recurring full ADS diagnostic sweep.
That sweep had also been the ONLY code path capturing the eight initial OTC
zero-current samples. The fast OTC service began with:
    if (!snapackOtcZeroReady) return;
so after Step45 it could never establish zero and therefore could never report
current. The screen stayed at 0 A and no current event could occur.

Fix:
The fast OTC service now owns its own startup zero capture:
  - reads Board3 / A3 at the existing 20 ms target cadence
  - averages 8 samples
  - establishes snapackOtcZero_mV
  - prints one concise line:
      OTC ZERO READY ####mV from 8 samples
  - then continues normal fast current/event processing

Step45 lag-isolation changes remain:
  - recurring full ADS diagnostics OFF
  - recurring I2C scans OFF
  - touch Serial flood OFF
  - native OneWire OFF
  - current acquisition 20 ms target
  - current UI redraw 100 ms
  - cells 500 ms
  - Step43 UI/themes/rings retained

Leave the 100 nF OTC input capacitor installed.
