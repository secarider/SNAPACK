SNAPACK STEP 29 — TEMPERATURE POLLING PAUSED

Purpose:
  Isolate whether repeated failed OneWire discovery is causing the 2–4 second
  UI/touch/carousel lag seen during diagnostics.

Only functional change:
  The recurring snapack_service_temperatures() call is disabled.

Everything else remains as Step 28:
  live cells, OTC current, 24V, CdS, I2C diagnostics/scanner, screens,
  themes and navigation.

If responsiveness improves substantially, repeated OneWire discovery was a
major contributor. If not, the heavy Serial diagnostics/full I2C scan become
the next suspects.

Temperature code is retained for later DS2484 integration.
