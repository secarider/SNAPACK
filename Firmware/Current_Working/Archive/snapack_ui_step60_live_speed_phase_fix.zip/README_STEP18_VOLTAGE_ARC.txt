SNAPACK STEP 18 — OUTER ARC ON CELL VOLTAGE SCREEN

Baseline:
  Step 17 temperature-screen build.

Change:
  Add a 430 x 430 outer LVGL arc to Screen5 (Cell Voltage), matching the
  general visual treatment introduced on the new temperature screen.

For this revision the voltage arc is PRESENTATION ONLY:
  * static development fill = 62%
  * it does NOT represent pack state-of-charge
  * it does NOT represent cell balance
  * it does NOT represent a warning threshold

Purpose:
  Establish the physical space and visual object now so later firmware can
  assign voltage-specific meaning and colors without redesigning Screen5.

DAY/NIGHT:
  NIGHT:
    track = dark gray
    indicator = cyan

  DAY:
    track = light gray
    indicator = black

Unchanged:
  * Cell values = two decimals
  * PACK = one decimal
  * Values = Montserrat 48
  * 1,2,3,4,5,PACK = Montserrat 20
  * Heading position = y - 37
  * Short Return -> carousel
  * Long Return -> DAY/NIGHT and remain on Screen5
  * Temperature Screen6 remains present
  * OEM screens remain present

Physical check:
  * confirm the arc does not crowd or visually interfere with the six values
  * confirm DAY/NIGHT arc colors look natural
  * confirm Return remains clear of the lower arc
