SNAPACK STEP 53 — INTERACTIVE / SYNCHRONIZED PERIMETER RINGS

Built from corrected Step52.

- Diagnostic carousel icon: lowercase i -> uppercase I.
- OEM Volume is now master animation-speed control for:
  * Carousel ultra-thin segmented perimeter ring
  * Cell Voltage cyan segmented ring
  * Temperature cyan segmented ring
  * Diagnostic rainbow segmented ring
- Lowest Volume gives a slow tick-by-tick animation; highest gives a fast animation.
- Carousel ring is 2 px idle:
  * swipe accelerates it temporarily
  * swipe direction reverses ring direction
  * swipe direction also advances/reverses palette cycling
  * after swipe, it returns to master speed and keeps the last reached color
  * valid lower-half selection gives a brief 5 px ring pulse before opening screen
- Cell Voltage and Temperature old static/fake arcs are replaced with animated cyan segmented rings.
- Sticky NVS settings:
  * Volume / ring speed
  * Temp / carousel solid background color
  * Light / display brightness
  Values restore after reboot.
- Existing Step52 opposing selected accents, Step50 solid carousel background,
  current gauge, diagnostics, I2C behavior, touch split, and glitch protection retained.
