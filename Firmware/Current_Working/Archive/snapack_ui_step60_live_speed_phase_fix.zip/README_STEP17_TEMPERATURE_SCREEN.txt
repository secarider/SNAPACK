SNAPACK STEP 17 — FIVE-SENSOR TEMPERATURE SCREEN

Baseline:
  Physically accepted Step 16 cell-voltage screen.

Adds:
  * New SNAPACK Temperature carousel item.
  * New Screen6.
  * Five simulated temperature sensors plus AVG.
  * Same 3-over-3 layout grammar used successfully for cell voltage.
  * Large circular average-temperature arc behind the readings.
  * OEM Volume / Temp / Light screens remain in the carousel.

Carousel order:
  0 = SNAPACK Cell Voltage
  1 = SNAPACK Temperature
  2 = OEM Volume
  3 = OEM Temp
  4 = OEM Light

Simulated temperature data:
  1 = 72.1 F -> displays 72°
  2 = 74.4 F -> displays 74°
  3 = 73.3 F -> displays 73°
  4 = 75.8 F -> displays 76°
  5 = 72.6 F -> displays 73°
  AVG calculated in snapack.ino -> displays whole degrees

Temperature arc:
  * display-only in this revision
  * driven by AVG
  * temporary visual scale: 32 F = 0%, 120 F = 100%
  * no warning thresholds or bad-sensor colors yet

Important:
  New file ui_Screen6.c MUST be copied into:
    /home/valued/Arduino/libraries/UI/

The package includes the complete modified set for archival consistency.

Not yet implemented:
  * real temperature sensor acquisition
  * named sensor labels
  * abnormal spread/outlier logic
  * warning colors
  * day/night theme on Screen6
