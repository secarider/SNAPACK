SNAPACK STEP 55 — SAME REVISION, DECLARATION-ORDER COMPILE FIX

Compiler error:
  performClickAction was not declared in this scope
  inside my_touchpad_read()

Cause:
The earlier forward declaration was still too low in snapack.ino.
my_touchpad_read() appears much earlier.

Fix:
Move:
  void performClickAction();

to the top-level declarations before my_touchpad_read().

Retained:
- curated contrast rings
- 30 ms physical rotary push debounce
- main loop queues one push
- encTask performs LVGL selection
- no 300 ms double-click wait
- no physical-knob long-press behavior

This remains Step55, not Step56.
