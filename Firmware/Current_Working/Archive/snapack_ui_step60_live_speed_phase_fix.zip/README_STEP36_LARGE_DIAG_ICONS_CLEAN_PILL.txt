SNAPACK STEP 36 — LARGE DIAGNOSTIC TEXT + LARGE PEAK + CLEAN CAROUSEL PILL

Baseline:
  Corrected Step 35. Momentum/flick behavior is intentionally unchanged.

Carousel:
  - Removes the factory up/down-arrow selection artwork.
  - Replaces it with a plain lightly shaded 140x400 rounded vertical pill.
  - Adds simple placeholder icons to SNAPACK entries:
      V = Cell Voltage
      T = Temperature
      A = Current
      i = Diagnostic
    These are deliberately simple, robust LVGL labels and can later be
    replaced by custom artwork without changing carousel behavior.

Diagnostic screen:
  - DIAGNOSTIC title changes from 24px to the proven 48px Montserrat font.
  - The five new diagnostic data rows are visually doubled using LVGL 2x
    transform zoom on the already-proven 18px font.
  - Wording is shortened to fit the round 480px display:
      24V
      LAST
      MAX
      PACK
      LOW
  - Return button remains exactly the same size.

Current screen:
  - PEAK readout is visually doubled using the same 2x transform method.
  - Large live-current readout remains unchanged.
  - Return button remains unchanged.

Unchanged:
  - 7-position circular carousel
  - 1/2/3-step flick experiment
  - top-third swipe-only zone
  - live current / RAM event peak logic
  - Diagnostic values
  - CdS automatic DAY/NIGHT
  - temperature polling paused
