// SNAPACK TEMPERATURE SCREEN
//
// Five individual temperature probes plus one calculated average.
//
// This screen deliberately reuses the successful six-position grammar from
// the cell-voltage screen:
//     1   2   3
//     4   5   AVG
//
// The large arc is driven only by the average in this revision.  It is a
// presentation object, not a safety threshold yet.

#include "ui.h"

#define SNAP_TEMP_RING_SEGMENTS 36
static lv_obj_t * snapTempRing[SNAP_TEMP_RING_SEGMENTS];
static unsigned long snapTempRingTick = 0;
static int snapTempRingPhase = 0;
static uint32_t snapTempSpeed_mrev = 150;
static uint32_t snapTempPhaseMilli = 0;
static bool snapTempRingDay = false;

void ui_set_snapack_temperature_ring_speed(int volume_value)
{
    if (volume_value < 0) volume_value = 0;
    if (volume_value > 100) volume_value = 100;
    uint32_t vv = (uint32_t)volume_value * (uint32_t)volume_value;
    snapTempSpeed_mrev = (uint16_t)(150 + (9850UL * vv) / 10000UL);
}

void ui_service_snapack_temperature_ring(void)
{
    if (!ui_Screen6 || lv_scr_act() != ui_Screen6) return;
    static unsigned long lastFrameMs = 0;
    unsigned long now = millis();
    if (lastFrameMs == 0) lastFrameMs = now;
    unsigned long dt = now - lastFrameMs;
    if (dt < 16) return;
    lastFrameMs = now;

    uint64_t deltaMilliSeg = (uint64_t)dt * snapTempSpeed_mrev * SNAP_TEMP_RING_SEGMENTS;
    deltaMilliSeg /= 1000ULL;
    snapTempPhaseMilli = (snapTempPhaseMilli + (uint32_t)deltaMilliSeg) % (SNAP_TEMP_RING_SEGMENTS * 1000UL);
    snapTempRingPhase = (int)(snapTempPhaseMilli / 1000UL);

    const int half = SNAP_TEMP_RING_SEGMENTS / 2;
    for (int i=0; i<SNAP_TEMP_RING_SEGMENTS; i++) {
        if (!snapTempRing[i]) continue;
        int rel = (i - snapTempRingPhase + SNAP_TEMP_RING_SEGMENTS) % SNAP_TEMP_RING_SEGMENTS;
        int distance = rel <= half ? rel : SNAP_TEMP_RING_SEGMENTS - rel;
        uint8_t wave = (uint8_t)(255 - (distance * 190 / half));
        lv_color_t color;
        uint8_t opa;
        if (snapTempRingDay) {
            color = (wave > 145) ? lv_color_hex(0x181818) : lv_color_hex(0xB8B8B8);
            opa = (wave > 145) ? wave : 245;
        } else {
            color = (wave > 145) ? lv_color_hex(0x33DCFF) : lv_color_hex(0x10204A);
            opa = (wave > 145) ? wave : 245;
        }
        lv_obj_set_style_arc_color(snapTempRing[i], color, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_opa(snapTempRing[i], opa, LV_PART_MAIN | LV_STATE_DEFAULT);
    }
}

#include <stdio.h>

static lv_obj_t * snapTempTitle;
static lv_obj_t * snapTempHeading1;
static lv_obj_t * snapTempHeading2;
static lv_obj_t * snapTempHeading3;
static lv_obj_t * snapTempHeading4;
static lv_obj_t * snapTempHeading5;
static lv_obj_t * snapTempHeadingAvg;

typedef enum {
    SNAP_TEMP_THEME_NIGHT = 0,
    SNAP_TEMP_THEME_DAY
} snap_temp_theme_t;

static snap_temp_theme_t snapTempCurrentTheme = SNAP_TEMP_THEME_NIGHT;

// Long-press Return temporarily selects the display theme.
// Suppress normal Return navigation for that same press cycle.
static bool snapTempThemeLongPressConsumed = false;

static lv_color_t snap_temp_bg_color(void)
{
    return (snapTempCurrentTheme == SNAP_TEMP_THEME_DAY)
        ? lv_color_hex(0xFFFFFF)
        : lv_color_hex(0x000000);
}

static lv_color_t snap_temp_text_color(void)
{
    return (snapTempCurrentTheme == SNAP_TEMP_THEME_DAY)
        ? lv_color_hex(0x000000)
        : lv_color_hex(0xFFFFFF);
}

static lv_color_t snap_temp_value_color(void)
{
    return (snapTempCurrentTheme == SNAP_TEMP_THEME_DAY)
        ? lv_color_hex(0x000000)
        : lv_color_hex(0x33DCFF);
}

static lv_color_t snap_temp_button_color(void)
{
    return (snapTempCurrentTheme == SNAP_TEMP_THEME_DAY)
        ? lv_color_hex(0x000000)
        : lv_color_hex(0x33DCFF);
}

static lv_color_t snap_temp_button_text_color(void)
{
    return (snapTempCurrentTheme == SNAP_TEMP_THEME_DAY)
        ? lv_color_hex(0xFFFFFF)
        : lv_color_hex(0x000000);
}

static lv_color_t snap_temp_arc_track_color(void)
{
    return (snapTempCurrentTheme == SNAP_TEMP_THEME_DAY)
        ? lv_color_hex(0xD0D0D0)
        : lv_color_hex(0x303030);
}

static lv_color_t snap_temp_arc_indicator_color(void)
{
    return (snapTempCurrentTheme == SNAP_TEMP_THEME_DAY)
        ? lv_color_hex(0x000000)
        : lv_color_hex(0x33DCFF);
}

static lv_obj_t * snap_temp_create_measurement(lv_obj_t * parent,
                                               const char * heading_text,
                                               int x,
                                               int y,
                                               lv_obj_t ** heading_out)
{
    lv_obj_t * heading = lv_label_create(parent);
    lv_obj_set_width(heading, LV_SIZE_CONTENT);
    lv_obj_set_height(heading, LV_SIZE_CONTENT);
    lv_obj_set_x(heading, x);
    lv_obj_set_y(heading, y - 37);
    lv_obj_set_align(heading, LV_ALIGN_CENTER);
    lv_label_set_text(heading, heading_text);
    lv_obj_set_style_text_color(heading, snap_temp_text_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(heading, &lv_font_montserrat_20, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_t * value = lv_label_create(parent);
    lv_obj_set_width(value, LV_SIZE_CONTENT);
    lv_obj_set_height(value, LV_SIZE_CONTENT);
    lv_obj_set_x(value, x);
    lv_obj_set_y(value, y + 12);
    lv_obj_set_align(value, LV_ALIGN_CENTER);
    lv_label_set_text(value, "72°");
    lv_obj_set_style_text_color(value, lv_color_hex(0x33DCFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(value, &lv_font_montserrat_48, LV_PART_MAIN | LV_STATE_DEFAULT);

    if (heading_out) {
        *heading_out = heading;
    }

    return value;
}

static void snap_temp_set_label(lv_obj_t * label, int temp_dF)
{
    // -32768 is the application-layer sentinel for an unavailable sensor.
    // Missing sensors are shown honestly instead of blocking the whole screen
    // or retaining simulated temperatures.
    if (temp_dF == -32768) {
        lv_label_set_text(label, "--");
        return;
    }

    // Input uses tenths of a degree F; display whole degrees for readability.
    char text[16];
    int rounded_F = (temp_dF >= 0) ? (temp_dF + 5) / 10 : (temp_dF - 5) / 10;
    snprintf(text, sizeof(text), "%d°", rounded_F);
    lv_label_set_text(label, text);
}

void ui_update_snapack_temperatures(int temp1_dF,
                                    int temp2_dF,
                                    int temp3_dF,
                                    int temp4_dF,
                                    int temp5_dF,
                                    int avg_dF)
{
    if (ui_SnapackTemp1Value) snap_temp_set_label(ui_SnapackTemp1Value, temp1_dF);
    if (ui_SnapackTemp2Value) snap_temp_set_label(ui_SnapackTemp2Value, temp2_dF);
    if (ui_SnapackTemp3Value) snap_temp_set_label(ui_SnapackTemp3Value, temp3_dF);
    if (ui_SnapackTemp4Value) snap_temp_set_label(ui_SnapackTemp4Value, temp4_dF);
    if (ui_SnapackTemp5Value) snap_temp_set_label(ui_SnapackTemp5Value, temp5_dF);
    if (ui_SnapackTempAvgValue) snap_temp_set_label(ui_SnapackTempAvgValue, avg_dF);

    if (ui_SnapackTempArc) {
        if (avg_dF == -32768) {
            lv_arc_set_value(ui_SnapackTempArc, 0);
        } else {
            // Initial display-only scale: 32°F -> 0%, 120°F -> 100%.
            int avg_F = avg_dF / 10;
            if (avg_F < 32) avg_F = 32;
            if (avg_F > 120) avg_F = 120;

            int arc_value = ((avg_F - 32) * 100) / (120 - 32);
            lv_arc_set_value(ui_SnapackTempArc, arc_value);
        }
    }
}


static void applySnapTempTheme(snap_temp_theme_t theme)
{
    snapTempCurrentTheme = theme;
    snapTempRingDay = (theme == SNAP_TEMP_THEME_DAY);

    if (!ui_Screen6) return;
    for (int i=0; i<SNAP_TEMP_RING_SEGMENTS; i++) {
        if (snapTempRing[i]) {
            lv_obj_set_style_arc_color(snapTempRing[i],
                                       snapTempRingDay ? lv_color_hex(0x808080) : lv_color_hex(0x33DCFF),
                                       LV_PART_MAIN | LV_STATE_DEFAULT);
        }
    }

    lv_obj_set_style_bg_color(ui_Screen6, snap_temp_bg_color(), LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_t * headings[] = {
        snapTempTitle,
        snapTempHeading1, snapTempHeading2, snapTempHeading3,
        snapTempHeading4, snapTempHeading5, snapTempHeadingAvg
    };

    for (unsigned int i = 0; i < sizeof(headings) / sizeof(headings[0]); i++) {
        if (headings[i]) {
            lv_obj_set_style_text_color(headings[i], snap_temp_text_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
        }
    }

    lv_obj_t * values[] = {
        ui_SnapackTemp1Value, ui_SnapackTemp2Value, ui_SnapackTemp3Value,
        ui_SnapackTemp4Value, ui_SnapackTemp5Value, ui_SnapackTempAvgValue
    };

    for (unsigned int i = 0; i < sizeof(values) / sizeof(values[0]); i++) {
        if (values[i]) {
            lv_obj_set_style_text_color(values[i], snap_temp_value_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
        }
    }

    if (ui_SnapackTempArc) {
        lv_obj_set_style_arc_color(ui_SnapackTempArc,
                                   snap_temp_arc_track_color(),
                                   LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_color(ui_SnapackTempArc,
                                   snap_temp_arc_indicator_color(),
                                   LV_PART_INDICATOR | LV_STATE_DEFAULT);
    }

    if (ui_SnapackTempReturnBt) {
        lv_obj_set_style_bg_color(ui_SnapackTempReturnBt,
                                  snap_temp_button_color(),
                                  LV_PART_MAIN | LV_STATE_DEFAULT);
    }

    if (ui_SnapackTempReturnLabel) {
        lv_obj_set_style_text_color(ui_SnapackTempReturnLabel,
                                    snap_temp_button_text_color(),
                                    LV_PART_MAIN | LV_STATE_DEFAULT);
    }
}

void ui_set_snapack_temp_theme(bool day_mode)
{
    applySnapTempTheme(day_mode ? SNAP_TEMP_THEME_DAY : SNAP_TEMP_THEME_NIGHT);
}



bool snapack_temp_consume_theme_long_press(void)
{
    if (snapTempThemeLongPressConsumed) {
        snapTempThemeLongPressConsumed = false;
        return true;
    }
    return false;
}

static void snap_temp_theme_long_press_event(lv_event_t * e)
{
    if (lv_event_get_code(e) == LV_EVENT_LONG_PRESSED) {
        snapTempThemeLongPressConsumed = true;
        applySnapTempTheme(snapTempCurrentTheme == SNAP_TEMP_THEME_NIGHT
                           ? SNAP_TEMP_THEME_DAY
                           : SNAP_TEMP_THEME_NIGHT);
    }
}

void ui_Screen6_screen_init(void)
{
    ui_Screen6 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen6,
                      LV_OBJ_FLAG_CLICKABLE |
                      LV_OBJ_FLAG_PRESS_LOCK |
                      LV_OBJ_FLAG_SCROLLABLE |
                      LV_OBJ_FLAG_SCROLL_ELASTIC |
                      LV_OBJ_FLAG_SCROLL_MOMENTUM |
                      LV_OBJ_FLAG_SCROLL_CHAIN);
    lv_obj_set_style_bg_color(ui_Screen6, snap_temp_bg_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen6, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // STEP 53: segmented cyan temperature ring is created below.
    for (int i=0; i<SNAP_TEMP_RING_SEGMENTS; i++) {
        lv_obj_t * seg = lv_arc_create(ui_Screen6);
        snapTempRing[i] = seg;
        lv_obj_set_size(seg, 430, 430);
        lv_obj_center(seg);
        lv_arc_set_bg_angles(seg, i * 10, i * 10 + 7);
        lv_arc_set_rotation(seg, 270);
        lv_obj_remove_style(seg, NULL, LV_PART_KNOB);
        lv_obj_clear_flag(seg, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_style_arc_width(seg, 9, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_color(seg, lv_color_hex(0x33DCFF), LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_opa(seg, i < 7 ? (255 - i * 10) : 170, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_opa(seg, 0, LV_PART_INDICATOR | LV_STATE_DEFAULT);
    }

    snapTempTitle = lv_label_create(ui_Screen6);
    lv_obj_set_width(snapTempTitle, LV_SIZE_CONTENT);
    lv_obj_set_height(snapTempTitle, LV_SIZE_CONTENT);
    lv_obj_set_x(snapTempTitle, 0);
    lv_obj_set_y(snapTempTitle, -176);
    lv_obj_set_align(snapTempTitle, LV_ALIGN_CENTER);
    lv_label_set_text(snapTempTitle, "Temperature");
    lv_obj_set_style_text_color(snapTempTitle, snap_temp_text_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(snapTempTitle, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackTemp1Value = snap_temp_create_measurement(ui_Screen6, "1",   -132, -68, &snapTempHeading1);
    ui_SnapackTemp2Value = snap_temp_create_measurement(ui_Screen6, "2",      0, -68, &snapTempHeading2);
    ui_SnapackTemp3Value = snap_temp_create_measurement(ui_Screen6, "3",    132, -68, &snapTempHeading3);

    ui_SnapackTemp4Value = snap_temp_create_measurement(ui_Screen6, "4",   -132,  40, &snapTempHeading4);
    ui_SnapackTemp5Value = snap_temp_create_measurement(ui_Screen6, "5",      0,  40, &snapTempHeading5);
    ui_SnapackTempAvgValue = snap_temp_create_measurement(ui_Screen6, "AVG", 132,  40, &snapTempHeadingAvg);

    ui_SnapackTempReturnBt = lv_btn_create(ui_Screen6);
    lv_obj_set_width(ui_SnapackTempReturnBt, 168);
    lv_obj_set_height(ui_SnapackTempReturnBt, 54);
    lv_obj_set_x(ui_SnapackTempReturnBt, 0);
    lv_obj_set_y(ui_SnapackTempReturnBt, 164);
    lv_obj_set_align(ui_SnapackTempReturnBt, LV_ALIGN_CENTER);
    lv_obj_set_style_bg_color(ui_SnapackTempReturnBt, snap_temp_button_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_SnapackTempReturnBt, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(ui_SnapackTempReturnBt, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackTempReturnLabel = lv_label_create(ui_Screen6);
    lv_obj_set_width(ui_SnapackTempReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_SnapackTempReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_x(ui_SnapackTempReturnLabel, 0);
    lv_obj_set_y(ui_SnapackTempReturnLabel, 164);
    lv_obj_set_align(ui_SnapackTempReturnLabel, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SnapackTempReturnLabel, "Return");
    lv_obj_set_style_text_color(ui_SnapackTempReturnLabel, snap_temp_button_text_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_SnapackTempReturnLabel, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_set_ext_click_area(ui_SnapackTempReturnBt, 36);
    lv_obj_add_event_cb(ui_SnapackTempReturnBt, ui_event_screen6ReturnBt, LV_EVENT_ALL, NULL);
    lv_obj_add_event_cb(ui_SnapackTempReturnBt, snap_temp_theme_long_press_event, LV_EVENT_LONG_PRESSED, NULL);

    applySnapTempTheme(SNAP_TEMP_THEME_NIGHT);
}
