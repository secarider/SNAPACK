SNAPACK STEP 20 — CURRENT UNIT + SEGMENTED ARC

Baseline:
  Physically accepted Step 19.

Changes:
  * Current unit A:
      Montserrat 24 -> Montserrat 48
      moved slightly right/down so it sits behind the dominant current value

  * Current screen outer ring:
      18 short arc segments across a 270-degree sweep
      visible gaps create a segmented-gauge appearance

  * Development fill:
      11 of 18 segments active
      visual only; no current meaning yet

Theme:
  NIGHT active = cyan / inactive = dark gray
  DAY active = black / inactive = light gray

Future:
  Active segment count can later be driven by current magnitude, peak current,
  or cranking-state rules without changing screen geometry.
