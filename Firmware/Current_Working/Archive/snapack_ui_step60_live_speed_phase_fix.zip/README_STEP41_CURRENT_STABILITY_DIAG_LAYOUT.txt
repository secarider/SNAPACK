SNAPACK STEP 41 — CURRENT STABILITY + GAUGE ROTATION + FIXED DIAGNOSTIC ROWS

Built from Step 40.

CURRENT EVENT STABILITY
- Event start threshold raised from 8 A to 12 A.
- Event start now requires 3 consecutive qualifying samples.
- Live current / gauge / event detector use a light 1/4 EMA smoothing filter.
- Event end threshold is 5 A, held for 500 ms.
- This is intended to reject the observed idle 1–5 A wandering and isolated
  ~11 A spikes without making the present ~15–21 A bench load unusable.

CURRENT SCREEN
- Peak-display initialization bug fixed:
  Screen7 is created first, then PEAK is restored, so screen creation cannot
  overwrite the event peak with "PEAK 0 A".
- PEAK text increased to ~120% of the base 18 px font.
- Gauge perimeter rotation moved 90 degrees left so the open gap should sit
  at the bottom around the Return-button area rather than on the right.
- Center-zero CHARGE/DISCHARGE logic remains.

DIAGNOSTIC
- Each information row now lives in a fixed 380 px parent container.
- Left label and right value are separate fixed-position children.
- Both columns increased to ~120% of the base 18 px font.
- DIAGNOSTIC heading remains unchanged.
- This layout is specifically intended to stop both the label and changing
  number from visibly shifting as values gain/lose digits.
- Step40 perimeter animation remains.

TOUCH / CAROUSEL
- Unchanged from Step38/39:
  swipe anywhere = one item
  lower-half tap = select centered item
  upper-half tap ignored

NO FLASH PEAK HISTORY YET.
