SNAPACK STEP 51 — OPPOSING SELECTED ACCENT

Built from Step50.

Carousel background:
- remains a solid manually controlled color from the factory Temperature control.
- no bitmap and no overlay.

Selected accent:
- each background color now produces its exact RGB complementary color.
- centered/selected carousel text uses that opposing color.
- original Elecrow selected Volume/Temp/Light image icons are fully recolored
  to the same opposing color.
- custom SNAPACK V/T/A/i icons are WHITE when left/right of center and change
  to the opposing accent only when centered.
- off-center labels remain white.

Examples:
  blue background  -> orange/peach selected accent
  green background -> magenta/pink selected accent
  red background   -> cyan selected accent

The translucent center selection pill and all navigation behavior remain
unchanged.

All Step50/48/47 current, I2C, glitch rejection, Diagnostic 4S row, touch,
theme, and carousel behavior is retained.

COMPILE CORRECTION
- Uses packed uint32_t return from lv_color_to32() for LVGL 8.3.x.
