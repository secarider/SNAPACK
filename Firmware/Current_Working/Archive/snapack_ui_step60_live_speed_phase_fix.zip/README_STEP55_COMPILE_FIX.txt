SNAPACK STEP 55 — SAME REVISION, COMPILE/RUNTIME FIX

This replaces the first Step55 archive; it is NOT Step56.

The first Step55 changed physical rotary push handling so the main loop called
performClickAction() directly.  That crossed the existing task ownership model:
encoder/LVGL navigation is handled by encTask.

Corrected behavior:
- main loop polls/debounces the PCF8574 physical switch at 30 ms
- one press edge queues exactly one selection
- encTask consumes that queued selection immediately
- NO 300 ms double-click wait
- NO physical-knob long-press behavior
- all Step55 curated contrast-ring changes are unchanged

Replace the original Step55 ZIP with this corrected Step55.
