SNAPACK STEP 26 — ADC SETTLE TEST

Changes only:
- All live ADS1115 channel reads now perform two complete reads and use the
  second. The first is discarded to reduce MUX/channel carryover during
  bring-up, especially for the OTC zero-current investigation.
- Existing working cell mapping remains unchanged.
- Dead 0x49 board remains ignored.
- 24V, CdS, B1 and OTC remain on Board3 A0/A1/A2/A3.
- Temperature remains tolerant of 0..5 sensors and prints ROM IDs.

Temperature mapping status:
The physical connection is the rear pad silk-screened TX. Historical SNAPACK
code used GPIO17 for that connection, but that internal DHE03921D TX->GPIO
mapping has not yet been independently verified. Step 26 leaves the probe on
GPIO17 but Serial now calls this an assumption. Do not change the physical
temperature wiring for this test.

Wanted observations:
- Several consecutive Board3 A3=OTC node readings at zero current.
- Cell Voltage screen remains live.
- Temperature discovery result.
