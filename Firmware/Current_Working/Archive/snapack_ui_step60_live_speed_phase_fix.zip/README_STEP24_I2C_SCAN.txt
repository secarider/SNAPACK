SNAPACK STEP 24 — SLOW ADS DIAGNOSTICS + I2C ADDRESS SCAN

Baseline:
  Step 23 ADS diagnostics.

Changes:

1. Diagnostic output slowed:
     500 ms -> 2000 ms

   This makes Serial Monitor readable enough to inspect and copy by eye.

2. Board 1 labels neutralized:
     BOARD1 0x48 | A0 ... | A1 ... | A2 ... | A3 ...

   We are deliberately NOT assuming the post-shuffle B1/B2/B3/B4 order yet.
   The four cumulative voltages themselves should reveal the order:
     roughly 3.x, 6.x, 9.x, 12-14.x V

3. I2C address scan added:
   Every 10 seconds firmware scans addresses 0x01 through 0x7E and prints
   every responding I2C device.

   This is specifically to determine whether the missing ADS1115 board is
   really at 0x49, 0x4B, or another address.

4. Board 3 remains active and visible:
     BOARD3 0x4A A0 = 24 V monitor
     BOARD3 0x4A A1 = CdS light sensor

   Keep both connected so they continue to serve as known-good witnesses.

Expected useful observations:

  * I2C scan should list the display/touch-related devices plus ADS addresses.
  * BOARD1 should show four different cumulative voltages.
  * BOARD2 0x49 may continue READ_FAIL if that is not its real address.
  * BOARD3 A0 should remain near the known 24 V rail.
  * BOARD3 A1 should move strongly when the CdS sensor is moved between shade
    and bright light.

No screen/UI behavior was intentionally changed by this step.
