SNAPACK STEP 11 — PACK 1 DECIMAL + LABEL SPACING

Baseline:
  Physically verified Step 10 runtime DAY/NIGHT theme.

Changes:
  * Cells 1-5 remain two decimal places.
  * PACK changes to one decimal place.
  * Cell values round to nearest 0.01 V.
  * PACK rounds to nearest 0.1 V.
  * Numeric font remains Montserrat 44.
  * Heading font remains Montserrat 20.
  * 1,2,3,4,5,PACK headings move slightly farther from the large
    numeric readouts for additional visual breathing room.
  * DAY/NIGHT runtime theme behavior remains unchanged.
  * Long-press Return still toggles DAY/NIGHT.
  * Normal Return still returns.
  * No ADS1115 or GL5528 acquisition code added.

Expected:
  1 = 4.18
  2 = 4.16
  3 = 4.17
  4 = 4.17
  5 = 4.18
  PACK = 20.9

The planned heavier/bold numeric font is deliberately NOT added yet.
First establish the final information density and spacing, then change
stroke weight from a stable layout.
