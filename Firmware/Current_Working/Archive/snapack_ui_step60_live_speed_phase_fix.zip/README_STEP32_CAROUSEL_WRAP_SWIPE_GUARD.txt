SNAPACK STEP 32 — CAROUSEL SWIPE GUARD + WRAPAROUND + LARGER TOUCH TARGETS

Baseline:
  Step 31.

Changes:

1. Swipe no longer selects:
   When horizontal movement crosses the swipe threshold, the touch cycle is
   marked as a swipe. Carousel click handlers ignore that same touch cycle.

2. Continuous circular carousel:
   Both swipe and rotary now wrap:
     0 -> 1 -> 2 -> 3 -> 4 -> 5 -> 0
   and reverse:
     0 -> 5 -> 4 -> 3 -> 2 -> 1 -> 0

3. Larger invisible touch targets:
   Carousel selected-item buttons:
     24 px extension -> 40 px extension

   Return buttons on Cell Voltage, Temperature and Current screens:
     +36 px invisible click area around the existing visible button

4. Unchanged:
   - CdS automatic DAY/NIGHT
   - temperature polling paused
   - live cells / OTC / 24V / CdS
   - visible UI geometry
   - push-to-select behavior
