SNAPACK STEP 10 — MANUAL DAY/NIGHT THEME TEST

Starts from physically accepted Step 9.

NIGHT: black background, white headings, cyan values.
DAY: white background, black headings, black values.

TEMPORARY TEST:
Long-press the Return button to toggle DAY/NIGHT.
Normal Return behavior remains present.

This deliberately adds NO GL5528/ADS1115 acquisition yet.
The future ambient-light code can call the same applySnapackTheme()
function, preferably with separate DAY and NIGHT thresholds (hysteresis).
