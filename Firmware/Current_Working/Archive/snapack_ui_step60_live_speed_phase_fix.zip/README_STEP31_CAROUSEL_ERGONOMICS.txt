SNAPACK STEP 31 — CAROUSEL ERGONOMICS

Baseline: fixed Step 30.

Changes only:
1. Reversed horizontal swipe interpretation so carousel movement follows the
   finger in the intuitive direction.
2. Enlarged the touch hit area of all six carousel selection buttons by
   24 pixels around each existing button. Visible graphics/layout are unchanged.

Retained:
- CdS automatic DAY/NIGHT theme
- temperature polling paused
- live cells, OTC, 24V and diagnostics
- rotary encoder/push selection behavior unchanged

This is intentionally a narrow UI ergonomics pass.
