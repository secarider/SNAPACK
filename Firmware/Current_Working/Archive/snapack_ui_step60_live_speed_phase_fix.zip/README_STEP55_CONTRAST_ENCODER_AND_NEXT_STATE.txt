SNAPACK STEP 55 — CONTRAST-PAIRED RINGS + ROTARY PUSH RESPONSIVENESS

Built from Step54.

IMPLEMENTED IN THIS REVISION
----------------------------
1. Ring contrast
- Carousel NIGHT ring now uses curated bright-moving / dark-residual color pairs.
- Pairing advances/reverses together with the existing swipe palette.
- This avoids muddy or low-contrast mathematical complement combinations.
- Cell Voltage and Temperature use bright cyan moving emphasis over deep navy residual ring.
- DAY remains monochrome: dark moving emphasis over light-gray residual ring.
- Existing full-ring visibility, 4 px thickness, 7 px selection pulse,
  dramatic swipe boost, direction reversal, full 360 geometry, and Volume
  master speed are retained.

2. Physical rotary PUSH
- Removed the 300 ms OEM double-click waiting behavior from normal selection.
- Physical push now has ONE meaning: select.
- Debounced at 30 ms and recognized once on the press edge.
- No physical-knob long-press behavior is assigned.
- Touch Return long-press theme behavior is separate and unchanged.

DESIGN RESERVED FOR FOLLOWING REVISION(S)
-----------------------------------------
Machine State screen:
- Separate operational-status screen, not a duplicate of Diagnostics.
- Intended for ADS1115 ALERT states, charge authorization, authoritative
  cutoff/inhibit, relay/control states, and reason/state reporting.
- Do not invent authoritative fields until the ALERT/control architecture is
  actually wired and defined.

Bidirectional current accounting:
- Track current IN versus current OUT.
- Integrate over time into Ah IN / Ah OUT for pack-capacity estimation.
- Before making remaining-capacity authoritative, define OTC sign convention,
  usable pack Ah capacity, full/reset synchronization, calibration, and
  nonvolatile persistence/write strategy.

These two items are intentionally documented but not fabricated into live UI
before their underlying control/accounting definitions exist.
