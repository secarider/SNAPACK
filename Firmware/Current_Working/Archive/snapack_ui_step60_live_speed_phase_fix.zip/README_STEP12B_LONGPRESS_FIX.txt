SNAPACK STEP 12B — LONG-PRESS RELEASE FIX

Baseline:
  Physically tested Step 12 CLEAN.

Observed behavior:
  Long-press changed the theme, but releasing Return still navigated back
  to the carousel.

Cause:
  ui_event_screen5ReturnBt() is registered for LV_EVENT_ALL.
  Step 12 checked the consume flag on every event.
  The LONG_PRESSED event itself therefore consumed/reset the flag before
  the later LV_EVENT_RELEASED arrived.

Fix:
  Check snapack_consume_theme_long_press() ONLY inside LV_EVENT_RELEASED.

Expected:
  short Return press -> carousel
  long Return press  -> DAY/NIGHT toggle, stay on Screen5 after release

All Step 12 visual changes remain:
  * 1,2,3,4,5,PACK at y - 32
  * cells two decimals
  * PACK one decimal
  * values Montserrat 44
  * headings Montserrat 20
  * existing DAY/NIGHT colors
