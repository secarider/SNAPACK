SNAPACK STEP 30 — CDS AUTOMATIC DAY/NIGHT THEME

Baseline:
  Step 29 (temperature polling already paused).

Purpose:
  Use the now-proven Board3 A1 CdS sensor to choose DAY/NIGHT automatically,
  while retaining all working live hardware paths.

Bench-derived light ranges from the latest test:
  shadow/deep shade: tens of mV
  transition: hundreds of mV
  bright: ~1.8V to >3.1V

Initial thresholds:
  <= 500mV  -> NIGHT candidate
  >= 1500mV -> DAY candidate
  500–1500mV -> keep current theme

Debounce/hysteresis:
  CdS is sampled every 500ms.
  Three consecutive samples on one side are required before switching,
  giving ~1.5 seconds of persistence.

Theme application:
  Cell Voltage, Temperature, and Current screens all switch together.

Manual long-press theme controls remain present. Because automatic mode is
active, ambient-light logic may later change the manually selected theme when
a confirmed DAY/NIGHT threshold is crossed.

Also retained from Step29:
  - recurring temperature discovery remains PAUSED
  - live cell voltage
  - OTC current
  - 24V monitor diagnostics
  - I2C diagnostics/scanner
  - existing screens/navigation

No low-cell blinking is added in Step30; this build intentionally isolates
the automatic-theme behavior first.
