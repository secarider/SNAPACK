SNAPACK STEP 33 — TOUCH EVENT FIX

Baseline:
  Step 32.

What Step 32 exposed:
  The swipe-suppression flag could remain active after a gesture. Temperature
  and Current carousel touch handlers checked that persistent flag, while the
  Cell Voltage handler did not. This produced the observed inconsistent
  behavior:
    - Cell Voltage selectable by touch
    - Temperature / Current not reliably selectable by touch
    - Current Return could be blocked

Step 33 correction:
  1. Replace persistent swipe-consumed state with a 250 ms timed suppression
     window triggered only when a real swipe is recognized.
  2. Apply exactly one swipe-release guard to all six carousel selection
     handlers consistently.
  3. Remove swipe guards entirely from Return-button handlers.
  4. Keep continuous carousel wraparound and enlarged touch areas from Step32.

Expected:
  - swipe moves carousel but does not enter a screen
  - separate tap selects Cell Voltage, Temperature, Current, or OEM item
  - Return works normally on Cell Voltage, Temperature and Current
  - long-press Return theme behavior remains intact
  - rotary/push and double-push behavior remain available
