SNAPACK STEP 35 — DIAGNOSTIC SCREEN + CURRENT EVENT PEAK + FLICK MOMENTUM

Built directly from corrected Step 34.

NEW DIAGNOSTIC CAROUSEL ITEM
  Carousel is now 7 positions:
    Cell Voltage
    Temperature
    Current
    Diagnostic
    OEM Volume
    OEM Temp
    OEM Light

  Diagnostic screen currently shows:
    24V rail
    last completed current-event peak
    session maximum current
    pack voltage
    lowest cell voltage

CURRENT EVENT PEAK
  Current screen gains a small PEAK value above the large live-current number.

  Fast OTC sampling:
    ~40 ms target cadence (~25 samples/sec), independent of the slow Serial
    diagnostic block.

  Provisional event detector for bench development:
    event starts at >= 8 A
    peak rises whenever a larger current sample arrives
    event ends after current stays <= 3 A for 500 ms
    completed event peak freezes on the Current screen until the next event

  This is intentionally RAM-only in Step 35. NO flash history is written yet.
  Persistent 50-event history should wait until the real high-current test
  proves that event start/end detection is behaving correctly.

FLICK / MOMENTUM EXPERIMENT
  Swipe-to-threshold time determines how many carousel positions advance:
    < 110 ms  -> 3 positions
    < 190 ms  -> 2 positions
    otherwise -> 1 position

  Carousel remains circular and visually seamless.

TOUCH ERGONOMICS RETAINED
  Top one-third remains swipe-only.
  Selection remains active in the lower two-thirds.
  Step33 timed swipe-release suppression remains.

OTHER RETAINED FUNCTIONS
  CdS automatic DAY/NIGHT
  live cells
  24V monitor
  OTC zero capture and Serial diagnostics
  temperature polling paused pending DS2484 hardware
  rotary/push selection and double-push return
