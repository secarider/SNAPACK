SNAPACK STEP 57 — FULL-RING MOTION + FASTER SPEED RANGE

Built from Step56.

- Carousel, Cell Voltage and SNAPACK Temperature: entire circumference now
  participates in one wrapped brightness wave. There is no inert dark track.
- Brightness changes continuously around the whole ring and meets itself at
  the opposite end.
- Volume speed range is dramatically faster: reference range 180 ms at 0%
  down to 18 ms at 100%. Carousel timing is normalized for 48 segments versus
  the 36-segment rings.
- Diagnostic receives the same faster Volume range while retaining its
  rainbow/night and grayscale/day behavior.
- Carousel swipe palette cycling, swipe acceleration and direction reversal
  are retained.
- Step56 Fahrenheit fix and Step55 rotary-push responsiveness are retained.
- Machine State and bidirectional Ah accounting remain future architecture.
