SNAPACK STEP 40 — AUTO CURRENT EVENT + CENTER-ZERO GAUGE + DIAGNOSTIC RING

Built from Step 39. Step 38/39 touch behavior is unchanged.

CURRENT EVENT:
  Bench-test thresholds deliberately remain low:
    START >= 8 A
    END <= 3 A continuously for 500 ms
  On START, the display automatically changes to the Current screen.
  It does NOT automatically leave Current when the event ends.
  PEAK remains magnitude-based and freezes after the event.

CURRENT DIRECTION:
  The OTC signed value is now preserved into the Current UI.
  The large numeric display remains absolute magnitude.
  Gauge direction carries polarity:
    negative = CHARGE / left
    positive = DISCHARGE / right
  If installed clamp polarity proves backwards later, invert one software sign.

CENTER-ZERO PERIMETER GAUGE:
  18 segments total, 9 each side of zero.
  Temporary bench full-scale = 50 A so the present ~15–21 A test load produces
  clearly visible movement.
  Temporary color thresholds:
    under 15 A
    15–29 A
    30 A and above
  These are DEVELOPMENT values, not final cranking thresholds.

DIAGNOSTIC:
  Adds a non-blocking rotating multicolor perimeter/status ring.
  Diagnostic text/layout from Step 39 is retained.
  Ring updates only while Diagnostic is the active screen.

UNCHANGED:
  full lower-half tap-to-select
  swipe anywhere, one swipe = one carousel item
  seven-item circular carousel
  rotary/push behavior
  CdS automatic DAY/NIGHT
  Return buttons
  temperature polling paused
  no persistent flash peak history yet
