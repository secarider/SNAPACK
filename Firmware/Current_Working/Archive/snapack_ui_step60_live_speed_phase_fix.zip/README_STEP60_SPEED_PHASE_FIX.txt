SNAPACK STEP 60 — LIVE SPEED PHASE FIX

Built from Step59 after hardware test showed:
- Volume 0 and Volume 100 produced essentially the same ~6 second revolution.
- Swipe pulse/color/direction still worked, proving the ring service itself ran.

Step60 replaces the Q16 segment accumulator with a simpler milli-segment
accumulator. Requested revolutions/sec now maps directly to visible ring phase:
- 0% ~= 0.15 rev/s (~6.7 sec/rev)
- 100% = 10 rev/s (0.1 sec/rev)
- swipe burst = 18 rev/s

The redraw remains capped around 60 fps; high speeds skip intermediate segment
positions rather than demanding hundreds of renders/sec.

A lightweight serial line is emitted only when Volume changes:
  RING SPEED volume=NN%
This provides direct proof that the Volume callback is reaching the speed
control without re-enabling continuous diagnostic serial traffic.

All Step59 behavior is retained, including double-click escape, immediate
Carousel select, swipe direction/color/thickness, themes, sticky Volume, and
future Machine State/Ah plans.
