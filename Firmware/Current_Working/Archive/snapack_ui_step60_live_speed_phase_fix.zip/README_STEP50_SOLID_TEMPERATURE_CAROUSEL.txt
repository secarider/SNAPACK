SNAPACK STEP 50 — SOLID TEMPERATURE-CONTROLLED CAROUSEL BACKGROUND

Built directly from archived Step 48.
Step 49 remains a valid archived experiment and is not treated as an error.

Changes:
- Elecrow carousel bitmap ui_img_1871529928 is no longer displayed on Screen1.
- No translucent overlay is used.
- Screen1 itself is a solid LVGL background color.
- The existing factory Temperature control (0..200) changes that solid color.
- Both touch adjustment and rotary adjustment are supported.
- Startup seeds the carousel color from the current factory Temp arc value.

Gradient:
    0   cold blue
   40   cyan/teal
   80   green
  120   amber
  160   orange
  200   hot red

Intermediate values blend continuously.

The colors are intentionally darker/saturated so white carousel text remains
readable and the carousel does not become a bright white daytime-theme screen.

Later, when DS2484 temperature acquisition is active, real pack temperature can
feed ui_set_snapack_carousel_temp_color() directly.

All Step48/Step47 diagnostic, current, I2C, touch, carousel, theme, and glitch
protection behavior is otherwise retained.
