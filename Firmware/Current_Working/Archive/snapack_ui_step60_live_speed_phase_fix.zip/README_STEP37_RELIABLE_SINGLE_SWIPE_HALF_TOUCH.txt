SNAPACK STEP 37 — RELIABLE SINGLE-SWIPE + BOTTOM-HALF TAP + SIZE ROLLBACK

Baseline:
  Step 36.

Reliability changes:

1. Carousel swipe always moves exactly ONE item.
   The Step35/36 1/2/3-position flick experiment is removed.
   No velocity/momentum calculation remains.

2. Touch zoning is now stricter:
     top half (Y 0..239)     = swipe-only
     bottom half (Y 240..479)= tap selection allowed

   This is a deliberate custom ergonomic choice for this particular SNAPACK
   display and the user's preferred swipe motion.

3. The oversized Step36 display experiment is rolled back:
   - Diagnostic title returns to 24 px.
   - Diagnostic data rows return to their prior proven size.
   - Diagnostic wording/spacing returns to Step35.
   - Current PEAK readout returns to its prior proven size/position.
   - Return buttons remain unchanged.

Retained from Step36:
   - clean plain vertical carousel pill (factory arrow artwork removed)
   - placeholder SNAPACK carousel icons V / T / A / i

Retained from Step35:
   - 7-position circular carousel
   - Diagnostic screen
   - fast OTC current sampling
   - RAM-only event peak capture
   - CdS automatic DAY/NIGHT
   - temperature polling paused
