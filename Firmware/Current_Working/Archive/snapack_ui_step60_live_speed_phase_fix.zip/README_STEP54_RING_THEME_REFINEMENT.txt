SNAPACK STEP 54 — FULL-RING ANIMATION + THEME REFINEMENT

Built from Step53.

Carousel ring:
- Idle width increased from 2 px to 4 px.
- Selection pulse briefly increases to 7 px.
- Entire segmented circumference stays visibly lit.
- A moving brighter emphasis rotates through the full ring.
- Swipe boost is dramatically faster (12 ms animation interval).
- Swipe direction still reverses motion and palette progression.
- Full 360-degree segment geometry eliminates the Step53 dead gap near 11 o'clock.

Cell Voltage / Temperature rings:
- Entire cyan segmented rings stay visibly lit.
- Moving brighter emphasis rotates through the full ring.
- Shared OEM Volume master speed retained.

Theme paradigm locked:
- NIGHT owns color.
  * saved manual carousel background color
  * carousel palette color
  * cyan Cell Voltage / Temperature rings
  * Diagnostic rainbow
- DAY is black / white / gray only.
  * carousel background becomes white
  * carousel labels/icons become black/dark gray
  * animated rings retain motion/speed/direction but render in grayscale
  * Diagnostic retains its existing grayscale animation
- Entering DAY does NOT overwrite the saved NIGHT carousel color.
  Returning to NIGHT restores the previous manual color.
- Carousel is now included in automatic CDS day/night switching.

Retained:
- sticky Volume / Temp-background / Light settings
- uppercase Diagnostic I
- selection pulse
- current screen and glitch rejection
- Diagnostic 4S pack row
- existing touch/navigation behavior
