SNAPACK STEP 15 — MORE VALUE SCALE / HEADING RESET

Baseline:
  Step 14 plain-font build.

Changes:
  * 1,2,3,4,5,PACK:
      Montserrat 24 -> Montserrat 20
  * Headings lifted another exact 5 pixels:
      y - 32 -> y - 37

  * Voltage values remain Montserrat 48 because 48 is LVGL's largest
    built-in Montserrat size.
  * Values receive a modest 10% LVGL transform zoom:
      256 = 100%
      282 = about 110%

This gives one more visible size increase without bringing custom font
source files back into the project.

Unchanged:
  * cells = two decimals
  * PACK = one decimal
  * DAY/NIGHT colors
  * short Return -> carousel
  * long Return -> theme toggle and remain on Screen5
  * grid positions otherwise unchanged
  * no custom bold font files
  * no ADS1115/GL5528 acquisition yet

Physical check:
  * Check PACK 20.9 and outer values for edge clearance.
  * Check whether the 10% zoom remains crisp.
  * Confirm 20px headings at y - 37 have good breathing room.
