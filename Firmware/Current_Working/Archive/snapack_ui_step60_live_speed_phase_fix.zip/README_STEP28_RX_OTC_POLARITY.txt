SNAPACK STEP 28 — TEMPERATURE RX + OTC POLARITY

Baseline:
  Step 27.

Changes:

1. Temperature OneWire input:
     rear TX / GPIO43 -> rear RX / GPIO44

   Hardware:
     - one 4.7k pull-up from DATA to regulated 3.3V
     - sensor VCC directly to 3.3V
     - sensor GND to system ground

2. OTC polarity reversed in software:
     previous delta = OTC_node - zero
     Step 28 delta  = zero - OTC_node

   This makes the user's present test-current direction read positive
   without physically reversing the OTC conductor/clamp.

Unchanged:
  - provisional 1 mV/A relationship remains under test
  - first 8 valid OTC samples establish temporary zero
  - Current screen shows magnitude; Serial retains signed delta/current
  - live Cell Voltage path unchanged
  - Board3 A0=24V, A1=CdS, A2=B1, A3=OTC
  - dead 0x49 ignored
  - UI layouts/themes/navigation unchanged

Physical rework before test:
  Move the temperature DATA conductor from rear TX to rear RX.
