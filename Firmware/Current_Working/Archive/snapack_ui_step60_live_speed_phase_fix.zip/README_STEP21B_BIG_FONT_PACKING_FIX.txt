SNAPACK STEP 21B — 96 PX CURRENT FONT PACKING FIX

Baseline:
  Step 20 known-good Current screen.

Observed in Step 21:
  * overall size was good
  * digits appeared diagonally warped
  * digits overlapped / appeared partially repeated

Cause:
  The first hand-generated 4-bpp bitmap padded each glyph row to a whole
  byte. LVGL's normal font bitmap stream is not row-byte-aligned unless
  byte alignment is explicitly requested.

  With odd-width glyphs, the extra half-byte changed where LVGL believed
  each following row started. That creates exactly the progressive diagonal
  shift seen on the display.

Fix:
  * regenerate the same 96 px numeric font
  * pack all glyph pixels as one continuous 4-bpp nibble stream
  * no per-row padding

Unchanged:
  * current value target size = 96 px
  * simulated current = 187 A
  * A = stock Montserrat 48
  * segmented ring
  * DAY/NIGHT
  * Return behavior
  * all other screens

NEW FILE:
  snapack_current_96.c

Copy it into:
  /home/valued/Arduino/libraries/UI/

This replaces the broken Step 21 font source.
