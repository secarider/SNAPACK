SNAPACK STEP 38 — FULL BOTTOM-HALF SELECT ZONE

Top half (Y 0..239): swipe/navigation only.
Bottom half (Y 240..479): tap anywhere to select the currently centered carousel item.

The individual carousel button hitboxes are no longer used for touch selection.
A recognized swipe cancels selection for that touch cycle, so swipe and select
cannot occur together.

Retained: one swipe = one item, seven-item circular carousel, rotary/push,
Return behavior, Diagnostic screen, RAM peak capture, clean pill/icons,
CdS auto theme, and paused temperature polling.
