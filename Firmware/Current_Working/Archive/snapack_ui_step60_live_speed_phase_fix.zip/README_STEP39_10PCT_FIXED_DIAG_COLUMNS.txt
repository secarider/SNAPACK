SNAPACK STEP 39 — MODEST 10% TEXT INCREASE + FIXED DIAGNOSTIC COLUMNS

Baseline:
  Step 38.

Current screen:
  PEAK readout is increased by only about 10%.
  LVGL zoom 282 is used (256 = 100%).
  The large live-current number and Return button are unchanged.

Diagnostic screen:
  DIAGNOSTIC heading remains exactly the same size.
  All five information rows are increased by only about 10%.

  Labels and values are now separate LVGL objects:
    left column  = fixed labels
    right column = changing values

  This prevents label text from shifting when a value changes from one,
  two, or three digits. It also prepares the screen for later independent
  color treatment of labels versus values.

  Current layout:
    24V RAIL        <value>
    LAST PEAK       <value>
    SESSION MAX     <value>
    PACK            <value>
    LOWEST CELL     <value>

  Return button remains unchanged.

Everything else remains Step 38:
  full bottom-half touch selection, top-half swipe-only,
  one swipe = one carousel item, Diagnostic logic, RAM peak capture,
  CdS auto theme, clean pill/icons, and paused temperature polling.
