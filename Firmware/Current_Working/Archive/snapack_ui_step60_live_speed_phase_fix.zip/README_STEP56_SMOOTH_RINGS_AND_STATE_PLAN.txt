SNAPACK STEP 56 — SMOOTHER SYNCHRONIZED RINGS + FACTORY TEMP CONSISTENCY

Implemented:
- Carousel 48-segment timing is normalized against the 36-segment rings so
  Volume controls apparent angular velocity, not merely milliseconds/step.
- Diagnostic uses the same angular-speed formula (36-segment reference).
- Carousel, Cell Voltage, and SNAPACK Temperature moving emphasis is broadened
  to a symmetric head/tail: center plus six segments on each side.
- Leading/trailing segments fade progressively.
- Residual/base ring is substantially more visible.
- Carousel retains curated contrast-pair colors, swipe palette cycling,
  dramatic swipe acceleration, and swipe-direction reversal.
- Day mode remains grayscale.
- Factory Elecrow Temperature screen is initialized in Fahrenheit and both
  touch and physical rotary adjustment now keep the Fahrenheit label consistent.
- Step55 physical rotary push responsiveness fix is retained.

Reserved / intentionally NOT fabricated yet:
MACHINE STATE carousel screen:
- ADS1115 ALERT states
- charge authorization/inhibit
- authoritative cutoff
- relay/control states
- 12V/16V state
- state/reason indication
Fields wait until the control architecture is actually defined.

CURRENT IN / CURRENT OUT CAPACITY ACCOUNTING:
- future Ah IN / Ah OUT integration and remaining-capacity estimate
- requires sign convention, usable Ah baseline, full/reset synchronization,
  calibration and persistence strategy before becoming authoritative.

Theme paradigm remains:
NIGHT = color.
DAY = black / white / gray.
Day mode does not overwrite saved nighttime carousel color.
