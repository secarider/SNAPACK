SNAPACK STEP 23 — INDEPENDENT ADS1115 DIAGNOSTICS

Baseline:
  Step 22.

IMPORTANT CHANNEL-MAP CORRECTION

Step 22 used an older mapping interpretation.  The current authoritative
hardware manifest says:

  Board 1 — 0x48
    A0 = B1
    A1 = B2
    A2 = B3
    A3 = B4

  Board 2 — 0x49
    A0 = B5
    A1 = Final Output +
    A2 = OTC Current
    A3 = Final Output -

  Board 3 — 0x4A
    A0 = 24 V rail monitor
    A1 = CdS / ambient light
    A2 = spare
    A3 = spare

Step 23 corrects the live cell path to that map.

DIAGNOSTIC BEHAVIOR

Every 500 ms all twelve ADS channels are attempted independently.
A bad cell channel no longer prevents Board 2 or Board 3 diagnostics.

Board 3:
  A0 prints raw count, ADS-node millivolts, and reconstructed 24 V rail.
  A1 prints raw count and direct CdS-node millivolts.

Expected CdS behavior from the connected hardware:
  shade  ~500 mV
  light  >2000 mV

The Cell Voltage screen still updates only from a complete plausible five-cell
frame.  That does NOT block these Serial diagnostics.

This remains a bring-up build: ADS comparator output is disabled during these
single-shot diagnostic reads.  ALERT/lockout integration comes later.
