SNAPACK STEP 14 — RETURN TO PLAIN FONT / LARGER SIZE

Baseline:
  Physically accepted Step 12B.

Decision:
  Abandon the custom-bold font experiment.  It compiled and flashed, but the
  physical display showed no worthwhile visual improvement.

Changes:
  * Large cell/PACK values:
      Montserrat 44 -> Montserrat 48
  * 1,2,3,4,5,PACK headings:
      Montserrat 20 -> Montserrat 24

Why 48/24 instead of exact +5:
  LVGL's built-in Montserrat fonts are available in discrete compiled sizes.
  48 and 24 are the next practical built-in steps from 44 and 20.

Removed:
  * No snapack_bold_20.c
  * No snapack_bold_44.c
  * No custom font declarations
  * No overdraw trick

Unchanged:
  * cells = two decimals
  * PACK = one decimal
  * heading position = y - 32
  * DAY/NIGHT colors
  * short Return -> carousel
  * long Return -> theme toggle and remain on Screen5
  * accepted grid geometry
  * no ADS1115/GL5528 acquisition yet

Physical check:
  Pay attention to:
    * PACK = 20.9 clearance on lower-right
    * outer values 1/3/4/PACK against round perimeter
    * whether 24-point headings still leave comfortable vertical spacing

If 48 is too large, Step 12B remains the clean rollback.
