SNAPACK STEP 27 — REAL TEMPERATURE + OTC 10A DEVELOPMENT TEST

Baseline:
  Step 26.

TEMPERATURE

Physical connection:
  Rear display TX -> GPIO43

Hardware requirement:
  One 4.7k pull-up from common DATA to regulated 3.3V.
  One pull-up serves the entire 0..5 sensor OneWire bus.

Behavior:
  * Simulated temperature startup feed removed.
  * 0..5 sensors tolerated.
  * Full 64-bit ROM ID printed for every discovered sensor.
  * Real valid sensors fill positions 1..5 in discovery order for bring-up.
  * Missing positions display "--".
  * AVG uses only valid sensors.
  * With one sensor, position 1 is real and AVG equals that sensor.

Permanent physical-location naming by ROM ID comes later.

OTC CURRENT

Board3 / 0x4A / A3 remains the OTC analog input.

Step27 automatically captures the first 8 valid OTC node readings after boot
as a temporary zero-current baseline. Keep the clamp at zero current until:
  ZERO_CAPTURE=8/8
and a ZERO=xxxxmV value appears.

After zero capture:
  Serial prints node mV, zero mV, signed delta mV, and provisional signed amps.

Development sensitivity under test:
  1 mV = 1 A

Therefore a known ~10 A load should produce approximately a 10 mV delta from
the captured zero baseline.

The existing Current screen is now fed the magnitude of that provisional
current after zero capture. The Serial output retains direction/sign.

IMPORTANT:
  This is still calibration/test behavior. The 1 mV/A relationship is being
  verified on the actual hardware before becoming a final calibration rule.

UNCHANGED:
  * Real live Cell Voltage screen and temporary cell mapping.
  * Board3 A0 24V diagnostic.
  * Board3 A1 CdS diagnostic.
  * Board3 A2 B1.
  * Dead 0x49 ignored.
  * I2C scanner.
  * Existing UI layouts/themes.
