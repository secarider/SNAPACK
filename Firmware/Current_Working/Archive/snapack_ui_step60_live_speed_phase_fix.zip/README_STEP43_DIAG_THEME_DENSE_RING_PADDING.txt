SNAPACK STEP 43 — DIAGNOSTIC THEME RESTORE + DENSER RING + INWARD COLUMNS

Built from Step 42.

DIAGNOSTIC THEME
- Restores long-press Return theme toggling on Diagnostic.
- The release after a long-press is consumed, so changing theme does not also
  leave the Diagnostic screen.
- NIGHT ring remains animated rainbow.
- DAY ring uses the same animation timing/phase but only black/gray/white.

DIAGNOSTIC RING
- Increased from 18 to 36 segments.
- This is still a modest LVGL object count for the ESP32-S3/PSRAM platform.
- Animation cadence remains 90 ms.
- More segments should make the rotation look smoother.

DIAGNOSTIC TEXT
- Keeps the reliable real Montserrat 24 px font.
- No LVGL transform zoom is reintroduced.
- Fixed row width reduced from 400 px to 350 px.
- Label/value columns are pulled inward with extra padding so neither side
  should overlap the perimeter ring.
- DIAGNOSTIC heading remains unchanged.

CURRENT GAUGE
- Keeps the same 25 segments in both DAY and NIGHT themes. Theme switching
  changes colors only; it does not create a second geometry/count.
- Entire current gauge receives a small 4-degree counter-clockwise correction,
  about one-third of one 11-degree segment, to place the center segment more
  precisely at 12 o'clock.

CURRENT FILTER / EVENT LOGIC
- Unchanged from Step41/42.
