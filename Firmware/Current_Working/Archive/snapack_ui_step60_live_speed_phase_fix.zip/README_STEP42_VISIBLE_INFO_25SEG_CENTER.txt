SNAPACK STEP 42 — RESTORE VISIBLE INFO + TRUE CENTER CURRENT SEGMENT

Built from the corrected Step 41 package, so Step41 current filtering/event
stability changes remain included.

WHY INFORMATION DISAPPEARED
The Diagnostic rows and Current PEAK were using LVGL transform-zoom on labels.
On this display/LVGL build that approach has proven unreliable and can clip or
make label content disappear.

STEP 42 FONT STRATEGY
No transform zoom is used for these information labels.

Current PEAK:
  actual built-in Montserrat 24 px

Diagnostic labels and values:
  actual built-in Montserrat 24 px
  fixed 400 px row container
  205 px left label column
  180 px right value column
  44 px row height

The DIAGNOSTIC title remains 24 px and is otherwise unchanged.
Labels and values remain separate objects, so later independent colors remain
possible and changing digit counts cannot reposition the opposite column.

CURRENT GAUGE
The current gauge changes from 18 segments to 25 segments:
  12 CHARGE segments
   1 true ZERO / center segment
  12 DISCHARGE segments

The odd segment count creates an actual segment at 12 o'clock rather than a
gap between two segments. The bottom opening remains centered around Return.

The center zero segment is always visible.

STEP41 BEHAVIOR RETAINED
  current event START >= 12 A
  3 consecutive qualifying samples required
  1/4 EMA smoothing
  event END <= 5 A for 500 ms
  screen auto-jump on a confirmed current event
  PEAK restored after Screen7 initialization
  Diagnostic perimeter animation
  Step38/39 touch navigation
