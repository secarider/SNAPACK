SNAPACK STEP 58 — VISUAL POP + FAST SPEED + STICKY VOLUME DISPLAY

Built from Step57.

Observed Step57 problems addressed:
- Same-color brightness wave looked like shading rather than obvious rotation.
- Ring looked too thin.
- 100% Volume remained far too slow / barely distinguishable.
- Factory Volume screen visually returned to its OEM 50% placeholder on entry.

Changes:
1. NIGHT rings now have a clearly contrasting dark base color and bright moving
   color. DAY uses light-gray base and dark moving wave.
2. Carousel idle width increased to 5 px; selection pulse 9 px.
3. During active carousel swipe the ring expands to 15 px (~3x idle) in BOTH
   night and day themes, then returns to 5 px.
4. Cell Voltage and SNAPACK Temperature ring width increased to 9 px.
5. Speed range is intentionally aggressive:
      0% reference = 120 ms/step
    100% reference =   4 ms/step
   Carousel compensates for 48 segments and can reach ~3 ms/step.
   Swipe boost is also 3 ms.
6. Diagnostic receives the same faster master speed range.
7. Sticky Volume:
   Preferences storage already existed. The OEM Screen2 initializer was
   visually resetting the control to its 50% placeholder whenever entered.
   Step58 re-applies the saved/current volume arc and label immediately after
   entering Screen2 so the displayed setting matches the persisted setting.

Retained:
- swipe color cycling and direction reversal
- daytime grayscale interaction behavior
- Fahrenheit consistency
- Step55 responsive physical rotary push
- Machine State / Ah IN-OUT remain future architecture.
