SNAPACK STEP 12 — CLEAN REBUILD

Baseline:
  Physically accepted Step 11.

Changes:
  * 1,2,3,4,5,PACK lifted another exact 5 pixels:
      Step 10: y - 22
      Step 11: y - 27
      Step 12: y - 32

  * Return/theme behavior:
      short Return press -> carousel
      long Return press  -> toggle DAY/NIGHT and remain on Screen5

Validation performed before packaging:
  * ui.c contains one prototype for ui_event_screen5ReturnBt().
  * ui.c contains EXACTLY ONE function definition for ui_event_screen5ReturnBt().
  * The long-press consume check occurs exactly once inside that definition.
  * No second callback function was created.

Unchanged:
  * Cells = two decimals
  * PACK = one decimal
  * Measurement font = Montserrat 44
  * Heading font = Montserrat 20
  * DAY/NIGHT colors and geometry
  * Return size
  * No ADS1115/GL5528 acquisition yet

Next planned step:
  Heavier font for both measurements and 1,2,3,4,5,PACK.
