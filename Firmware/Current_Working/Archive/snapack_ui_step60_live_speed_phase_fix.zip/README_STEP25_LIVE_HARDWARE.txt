SNAPACK STEP 25 — LIVE HARDWARE DEVELOPMENT-STAND BUILD

Temporary development mapping:
  Board1 0x48: A0=B5, A1=B4, A2=B3, A3=B2
  Board3 0x4A: A0=24V, A1=CdS, A2=B1, A3=OTC
  Board2 0x49: dead/nonresponsive; deliberately ignored

The Board1 order is based on the observed live staircase:
  ~16.37, ~13.01, ~9.78, ~6.51 V.
Board3 A2 is therefore expected to be the remaining low cumulative tap (~3.x V).

If all five cumulative values produce plausible 1.5–4.5 V individual cells,
the existing Cell Voltage screen is fed real pack data.

OTC:
  Board3 A3 prints raw count and ADS-node millivolts.
  No remembered zero-current voltage is assumed; capture the actual resting
  voltage during this test.

Temperature:
  GPIO17 / rear-display TX-designated connection.
  Supports 0 through 5 OneWire/DallasTemperature sensors.
  Missing sensors never stop SNAPACK.
  Full 64-bit ROM address is printed for every discovered sensor.
  Average uses only valid sensors.
  During bring-up, discovery repeats every 2 seconds.

Known-good Board3 24V and CdS diagnostics remain active.
I2C scan remains active every 10 seconds.

Required Arduino libraries:
  OneWire
  DallasTemperature
