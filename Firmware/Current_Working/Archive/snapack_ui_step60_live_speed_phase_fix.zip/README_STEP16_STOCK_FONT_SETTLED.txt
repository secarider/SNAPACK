SNAPACK STEP 16 — STOCK FONT SETTLED

Baseline:
  Step 15.

Observed:
  The 10% LVGL transform zoom caused all voltage values to disappear on the
  physical display, while headings still rendered normally.

Fix:
  Remove the transform zoom completely.

Settled presentation:
  * Voltage values = built-in Montserrat 48
  * Headings 1,2,3,4,5,PACK = built-in Montserrat 20
  * Heading position = y - 37
  * No custom bold font files
  * No overdraw
  * No transform zoom

Unchanged:
  * cells = two decimals
  * PACK = one decimal
  * DAY/NIGHT runtime theme
  * short Return -> carousel
  * long Return -> theme toggle and remain on Screen5
  * accepted grid geometry
  * no ADS1115/GL5528 acquisition yet

This step intentionally ends the font experiments and returns Screen5 to a
simple built-in-font implementation.
