SNAPACK STEP 48 — ADD 4S PACK VOLTAGE TO DIAGNOSTIC SCREEN

Built from Step47.

Diagnostic screen now shows six live information rows:
  24V RAIL
  LAST PEAK
  SESSION MAX
  FULL PACK
  4S PACK
  LOWEST CELL

4S PACK source:
  B4 cumulative tap from Board1, the nominal 12V / four-cell section.
  On the present bench pack this is expected around 12.8 V.

The existing FULL PACK remains B5 cumulative voltage.

Layout:
  Existing real Montserrat 24 px font retained.
  Six rows use slightly tighter vertical spacing so no font-size rollback is
  required and the perimeter ring remains clear.

All Step47 current stability, I2C serialization, glitch rejection, touch,
theme, and carousel behavior remain unchanged.
