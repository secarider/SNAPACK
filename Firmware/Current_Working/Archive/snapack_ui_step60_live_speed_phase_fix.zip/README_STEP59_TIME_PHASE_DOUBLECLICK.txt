SNAPACK STEP 59 — TIME-BASED HIGH-SPEED RINGS + DOUBLE-CLICK ESCAPE

Built from Step58.

RING ENGINE
-----------
The old engine advanced exactly one segment per timer event.  That inherently
limited visible speed.

Step59 uses elapsed-time phase:
- UI redraw remains capped near 60 fps.
- Ring position is calculated from elapsed time.
- Intermediate segment positions are skipped when necessary.
- Fast motion therefore no longer requires hundreds of redraws per second.

Volume speed curve:
- 0%  ~= 0.15 revolution/second
- 100% = 10 revolutions/second
- quadratic curve for finer low-speed control
- all Carousel / Cell Voltage / Temperature / Diagnostic rings use rev/sec,
  so different segment counts no longer change apparent angular velocity.

Carousel swipe:
- temporary 18 rev/sec burst
- direction follows swipe
- palette continues cycling with swipe direction
- 15 px (~3x idle) thickness while swiping in NIGHT and DAY
- returns to 5 px idle afterward
- selection pulse remains separate.

PHYSICAL ROTARY PUSH
--------------------
The Step55 removal of all double-click behavior also removed the convenient
double-click escape from sub-screens.

Step59 restores context-specific behavior:
- On Carousel: one physical push selects immediately.
- Inside any screen: two physical pushes within 260 ms return to Carousel.
- A lone physical push inside a screen has no action.
- No physical-knob long-press behavior.
- Debounce reduced from 30 ms to 20 ms for a crisper ordinary press.

Touch Return and its touch long-press theme behavior remain completely separate.

Retained from Step58:
- contrasting base/moving ring colors
- thick swipe visual pop
- sticky Volume screen display correction
- Fahrenheit consistency
- day/night theme paradigm
- future Machine State and Ah IN/OUT plans.
