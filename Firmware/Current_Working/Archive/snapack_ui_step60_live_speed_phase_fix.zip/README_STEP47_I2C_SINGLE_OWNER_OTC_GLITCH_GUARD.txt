SNAPACK STEP 47 — SINGLE-OWNER I2C + OTC GLITCH GUARD

Cause indicated by the 508 A false event:
  CURRENT EVENT START signed=-1A filtered=508A

That combination means an earlier enormous one-sample value entered the EMA.
By the time the event actually triggered, the raw signal had already returned
to -1 A, but the filter was still decaying from the bad sample.

A second concurrency issue was also present:
  swTask() polled the PCF8574 every 5 ms on Core 0 using the SAME Wire/I2C bus
  used by the touch controller and ADS1115 services in the main loop.
This allows genuine cross-core I2C contention.

STEP 47 CHANGES

1. PCF8574 switch polling no longer runs as a separate FreeRTOS task.
   It is serviced cooperatively from loop() every 10 ms.
   Touch, PCF8574, and ADS1115 I2C transactions are therefore serialized
   through the main loop instead of competing across cores.

2. OTC raw-spike guard before the EMA:
   If the system is near idle and a >100 A jump appears, that large step must
   appear in two consecutive, similar samples before being accepted.
   A genuine high-current crank is delayed only about one extra 20 ms sample.
   A single corrupt sample is discarded before it can charge the EMA.

3. Step46/45 lag fixes remain:
   quiet Serial, no recurring I2C scans, no recurring full ADS dump,
   OneWire disabled, 20 ms OTC acquisition, 100 ms Current redraw,
   500 ms cells, and 100 nF OTC capacitor retained.
