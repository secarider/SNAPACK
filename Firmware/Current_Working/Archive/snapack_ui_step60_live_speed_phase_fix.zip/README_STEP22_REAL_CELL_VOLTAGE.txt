SNAPACK STEP 22 — FIRST REAL HARDWARE DATA: CELL VOLTAGE

Baseline:
  Physically accepted Step 21B.

This is the first transition from simulated UI data to live pack data.

No new Arduino library is required.  The existing Wire bus talks directly
to the ADS1115 registers.

Authoritative mapping used from hardware_manifest_revised.txt:

  Board 1 — address 0x48
    A0 = B2 cumulative
    A1 = B3 cumulative
    A2 = B4 cumulative
    A3 = B5 cumulative / pack positive

  Board 2 — address 0x49
    A0 = B1 cumulative

  B0 = system ground

Derived:
  Cell 1 = B1
  Cell 2 = B2 - B1
  Cell 3 = B3 - B2
  Cell 4 = B4 - B3
  Cell 5 = B5 - B4
  PACK   = B5

Divider:
  47k upper / 18k lower

ADS1115 range:
  +/-6.144 V

Combined conversion:
  tap_mV = raw_counts * 65 / 96

Behavior:
  * The screen still starts with its known-good development values.
  * Every 250 ms firmware attempts one full live five-cell frame.
  * Live values replace the seed only when both ADS boards answer, cumulative
    taps are monotonic, and every derived cell is 1.5 V to 4.5 V.
  * Serial prints all cumulative taps and derived cells for bring-up.
  * A failed/implausible read leaves the last valid display intact.

Development boundary:
  This step leaves the ADS comparator disabled during these single-shot reads.
  Board-1 ALERT / lockout policy is deliberately NOT integrated yet.  Prove
  the measurement path first, then combine acquisition with the required
  ALERT behavior rather than mixing both changes into one bring-up step.
