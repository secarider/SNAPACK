SNAPACK STEP 34 — TOP-THIRD SWIPE ZONE + SEAMLESS CAROUSEL WRAP

Baseline:
  Step 33.

Changes:

1. Top third of the 480x480 display is now swipe-only on the carousel.
   Carousel tap-selection ignores touches with Y < 160.
   Raw swipe detection still uses the whole screen, so the user's preferred
   top-third swipe motion continues to work.

2. Visual carousel seam is closed.
   Previously logical wraparound worked, but index 0 had no left neighbor and
   index 5 had no right neighbor, producing an empty panel at the seam.
   Step 34 now renders:
      index 5 (Light) to the left of index 0 (Cell Voltage)
      index 0 (Cell Voltage) to the right of index 5 (Light)

   The carousel therefore looks continuous as well as behaving continuously.

3. Retained:
   - Step33 timed swipe-release guard
   - larger touch targets below the swipe-only zone
   - continuous rotary/swipe wraparound
   - CdS automatic DAY/NIGHT
   - live cells / OTC / 24V / CdS
   - temperature polling paused
