// SNAPACK SCREEN 5
//
// STEP 4 PURPOSE:
//   Improve physical readability and use more of the available round screen.
//
// Changes from the physically verified Step 3 layout:
//   - Keep five cell voltages plus PACK in a two-row / three-column grid.
//   - Remove the repeated word "CELL" from each measurement heading.
//   - Retain only identifiers 1, 2, 3, 4, 5, and PACK.
//   - Increase numeric readouts from Montserrat 24 to Montserrat 28.
//   - Enlarge the Return button and its label.
//   - Replace the top "CELL VOLTAGES" title with "SIMULATED" while the
//     displayed values are still development data.
//
// IMPORTANT:
//   No ADS1115 data is being read yet.
//
// FUTURE THEME NOTE:
//   Screen colors are deliberately centralized below.  That gives SNAPACK
//   one obvious place to implement a high-contrast DAY theme later:
//
//       NIGHT: black background / cyan values / white labels
//       DAY:   white background / black values / black labels
//
//   Theme selection can first be manual.  If a light sensor is later added,
//   the same theme-selection function can be driven automatically without
//   redesigning the measurement screen.

#include "ui.h"
#include <stdio.h>

// ---------------------------------------------------------------------
// SNAPACK DAY / NIGHT THEME
//
// One firmware image owns both appearances.
// The planned GL5528 -> ADS1115 Board 3 / A1 path can later select between
// these same two modes automatically.
typedef enum {
    SNAPACK_THEME_NIGHT = 0,
    SNAPACK_THEME_DAY
} snapack_theme_t;

static snapack_theme_t snapackCurrentTheme = SNAPACK_THEME_NIGHT;

static lv_obj_t * snapackTitle;
static lv_obj_t * snapackHeading1;
static lv_obj_t * snapackHeading2;
static lv_obj_t * snapackHeading3;
static lv_obj_t * snapackHeading4;
static lv_obj_t * snapackHeading5;
static lv_obj_t * snapackHeadingPack;

static lv_color_t snapack_bg_color(void) {
    return snapackCurrentTheme == SNAPACK_THEME_DAY ? lv_color_hex(0xFFFFFF) : lv_color_hex(0x000000);
}
static lv_color_t snapack_text_color(void) {
    return snapackCurrentTheme == SNAPACK_THEME_DAY ? lv_color_hex(0x000000) : lv_color_hex(0xFFFFFF);
}
static lv_color_t snapack_value_color(void) {
    return snapackCurrentTheme == SNAPACK_THEME_DAY ? lv_color_hex(0x000000) : lv_color_hex(0x33DCFF);
}
static lv_color_t snapack_button_color(void) {
    return snapackCurrentTheme == SNAPACK_THEME_DAY ? lv_color_hex(0x000000) : lv_color_hex(0x33DCFF);
}
static lv_color_t snapack_button_text_color(void) {
    return snapackCurrentTheme == SNAPACK_THEME_DAY ? lv_color_hex(0xFFFFFF) : lv_color_hex(0x000000);
}

// Format integer millivolts as X.XXX V.
static void snapack_set_voltage_label(lv_obj_t * label, int millivolts)
{
    char text[16];

    // Round the display to the nearest 10 mV so the readout carries
    // two decimal places instead of implying unnecessary 1 mV precision.
    int centivolts = (millivolts + 5) / 10;
    int volts = centivolts / 100;
    int hundredths = centivolts % 100;

    snprintf(text, sizeof(text), "%d.%02d", volts, hundredths);
    lv_label_set_text(label, text);
}

// Create one measurement heading and one independently updateable value.
//
// The heading is intentionally minimal.  Five cells are identified simply
// as 1 through 5.  PACK remains spelled out because it is a different type
// of value and should be recognizable instantly.
static lv_obj_t * snapack_create_measurement(lv_obj_t * parent,
                                              const char * heading_text,
                                              int x,
                                              int y,
                                              lv_obj_t ** heading_out)
{
    lv_obj_t * heading = lv_label_create(parent);
    lv_obj_set_width(heading, LV_SIZE_CONTENT);
    lv_obj_set_height(heading, LV_SIZE_CONTENT);
    lv_obj_set_x(heading, x);
    lv_obj_set_y(heading, y - 22);
    lv_obj_set_align(heading, LV_ALIGN_CENTER);
    lv_label_set_text(heading, heading_text);
    lv_obj_set_style_text_color(heading, snapack_text_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(heading, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(heading, &lv_font_montserrat_20, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_t * value = lv_label_create(parent);
    lv_obj_set_width(value, LV_SIZE_CONTENT);
    lv_obj_set_height(value, LV_SIZE_CONTENT);
    lv_obj_set_x(value, x);
    lv_obj_set_y(value, y + 9);
    lv_obj_set_align(value, LV_ALIGN_CENTER);
    lv_label_set_text(value, "0.00");
    lv_obj_set_style_text_color(value, snapack_value_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(value, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Step 4 used Montserrat 24.  Physical testing showed that the
    // measurements could still use more of the available screen area,
    // so Step 8 uses Montserrat 44.
    lv_obj_set_style_text_font(value, &lv_font_montserrat_44, LV_PART_MAIN | LV_STATE_DEFAULT);

    if (heading_out) *heading_out = heading;

    return value;
}

// Apply a theme to the already-created Screen5 objects.
//
// Later the ambient-light logic only needs to choose DAY or NIGHT here;
// it will not need to know anything about fonts, coordinates, or labels.
static void applySnapackTheme(snapack_theme_t theme)
{
    snapackCurrentTheme = theme;

    if (!ui_Screen5) return;

    lv_obj_set_style_bg_color(ui_Screen5, snapack_bg_color(), LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_t * headings[] = {
        snapackTitle, snapackHeading1, snapackHeading2, snapackHeading3,
        snapackHeading4, snapackHeading5, snapackHeadingPack
    };
    for (unsigned int i = 0; i < sizeof(headings) / sizeof(headings[0]); i++) {
        if (headings[i]) {
            lv_obj_set_style_text_color(headings[i], snapack_text_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
        }
    }

    lv_obj_t * values[] = {
        ui_SnapackCell1Value, ui_SnapackCell2Value, ui_SnapackCell3Value,
        ui_SnapackCell4Value, ui_SnapackCell5Value, ui_SnapackPackValue
    };
    for (unsigned int i = 0; i < sizeof(values) / sizeof(values[0]); i++) {
        if (values[i]) {
            lv_obj_set_style_text_color(values[i], snapack_value_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
        }
    }

    if (ui_SnapackReturnBt) {
        lv_obj_set_style_bg_color(ui_SnapackReturnBt, snapack_button_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    }
    if (ui_SnapackReturnLabel) {
        lv_obj_set_style_text_color(ui_SnapackReturnLabel, snapack_button_text_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    }
}

static void snapack_toggle_theme(void)
{
    applySnapackTheme(snapackCurrentTheme == SNAPACK_THEME_NIGHT
                      ? SNAPACK_THEME_DAY
                      : SNAPACK_THEME_NIGHT);
}

// ---------------------------------------------------------------------
// PUBLIC DATA-TO-UI BOUNDARY
// ---------------------------------------------------------------------
//
// This interface is unchanged from Step 3.  Presentation changes therefore
// do not require measurement/application changes.
void ui_update_snapack_cells(int cell1_mV,
                             int cell2_mV,
                             int cell3_mV,
                             int cell4_mV,
                             int cell5_mV,
                             int pack_mV)
{
    if (ui_SnapackCell1Value) snapack_set_voltage_label(ui_SnapackCell1Value, cell1_mV);
    if (ui_SnapackCell2Value) snapack_set_voltage_label(ui_SnapackCell2Value, cell2_mV);
    if (ui_SnapackCell3Value) snapack_set_voltage_label(ui_SnapackCell3Value, cell3_mV);
    if (ui_SnapackCell4Value) snapack_set_voltage_label(ui_SnapackCell4Value, cell4_mV);
    if (ui_SnapackCell5Value) snapack_set_voltage_label(ui_SnapackCell5Value, cell5_mV);
    if (ui_SnapackPackValue)  snapack_set_voltage_label(ui_SnapackPackValue, pack_mV);
}

// Temporary development control:
// long-press Return toggles DAY/NIGHT; ordinary click still returns.
static void snapack_theme_long_press_event(lv_event_t * e)
{
    if (lv_event_get_code(e) == LV_EVENT_LONG_PRESSED) {
        snapack_toggle_theme();
    }
}

void ui_Screen5_screen_init(void)
{
    ui_Screen5 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen5, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_PRESS_LOCK | LV_OBJ_FLAG_SCROLLABLE |
                      LV_OBJ_FLAG_SCROLL_ELASTIC | LV_OBJ_FLAG_SCROLL_MOMENTUM);

    lv_obj_set_style_bg_color(ui_Screen5, snapack_bg_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen5, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // -----------------------------------------------------------------
    // DEVELOPMENT-STATE TITLE
    // -----------------------------------------------------------------
    //
    // While these numbers are synthetic, use the most valuable title space
    // to state that fact clearly.  When ADS1115 measurements are connected,
    // this can become "CELL VOLTAGES" again or be removed entirely.
    snapackTitle = lv_label_create(ui_Screen5);
    lv_obj_set_width(snapackTitle, LV_SIZE_CONTENT);
    lv_obj_set_height(snapackTitle, LV_SIZE_CONTENT);
    lv_obj_set_x(snapackTitle, 0);
    lv_obj_set_y(snapackTitle, -158);
    lv_obj_set_align(snapackTitle, LV_ALIGN_CENTER);
    lv_label_set_text(snapackTitle, "Simulated Voltage");
    lv_obj_set_style_text_color(snapackTitle, snapack_text_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(snapackTitle, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(snapackTitle, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);

    // -----------------------------------------------------------------
    // TWO ROWS OF THREE MEASUREMENTS
    // -----------------------------------------------------------------
    //
    // Removing the repeated word CELL lets the actual voltages occupy more
    // visual space.  The three-column geometry remains familiar and balanced.
    //
    // Top row: 1 / 2 / 3
    ui_SnapackCell1Value = snapack_create_measurement(ui_Screen5, "1",    -132, -68, &snapackHeading1);
    ui_SnapackCell2Value = snapack_create_measurement(ui_Screen5, "2",       0, -68, &snapackHeading2);
    ui_SnapackCell3Value = snapack_create_measurement(ui_Screen5, "3",     132, -68, &snapackHeading3);

    // Bottom row: 4 / 5 / PACK
    ui_SnapackCell4Value = snapack_create_measurement(ui_Screen5, "4",    -132,  40, &snapackHeading4);
    ui_SnapackCell5Value = snapack_create_measurement(ui_Screen5, "5",       0,  40, &snapackHeading5);
    ui_SnapackPackValue  = snapack_create_measurement(ui_Screen5, "PACK",  132,  40, &snapackHeadingPack);

    // -----------------------------------------------------------------
    // RETURN CONTROL
    // -----------------------------------------------------------------
    //
    // Physical testing showed that the existing Return control could afford
    // to be larger.  Increase both the touch target and the visible label.
    ui_SnapackReturnBt = lv_btn_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackReturnBt, 168);
    lv_obj_set_height(ui_SnapackReturnBt, 54);
    lv_obj_set_x(ui_SnapackReturnBt, 0);
    lv_obj_set_y(ui_SnapackReturnBt, 164);
    lv_obj_set_align(ui_SnapackReturnBt, LV_ALIGN_CENTER);
    lv_obj_set_style_bg_color(ui_SnapackReturnBt, snapack_value_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_SnapackReturnBt, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(ui_SnapackReturnBt, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackReturnLabel = lv_label_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_SnapackReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_x(ui_SnapackReturnLabel, 0);
    lv_obj_set_y(ui_SnapackReturnLabel, 164);
    lv_obj_set_align(ui_SnapackReturnLabel, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SnapackReturnLabel, "Return");
    lv_obj_set_style_text_color(ui_SnapackReturnLabel, snapack_button_text_color(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_SnapackReturnLabel, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_SnapackReturnLabel, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_add_event_cb(ui_SnapackReturnBt, ui_event_screen5ReturnBt, LV_EVENT_ALL, NULL);
    lv_obj_add_event_cb(ui_SnapackReturnBt, snapack_theme_long_press_event, LV_EVENT_LONG_PRESSED, NULL);

    // Preserve the current appearance as the power-up default.
    applySnapackTheme(SNAPACK_THEME_NIGHT);
}
