SNAPACK STEP 49 — FACTORY TEMP CONTROL DRIVES CAROUSEL HUE

Built from Step48.

What the blue carousel background actually is:
  The Elecrow carousel uses a background IMAGE:
    ui_img_1871529928
  over a black Screen1 base color.

Step49 leaves that artwork intact and adds a translucent full-screen LVGL
color layer above the artwork but below all carousel objects.

The existing factory Temperature control (0..200) now drives that tint:

    0    blue
   40    cyan
   80    green
  120    yellow
  160    orange
  200    red

Intermediate values are smoothly interpolated.

Both ways of changing the factory Temperature control drive the hue:
  - touch adjustment on the factory Temp screen
  - rotary adjustment on the factory Temp screen

This is a UI proof-of-concept only. Later, when DS2484 temperature acquisition
is active, the same ui_set_snapack_carousel_temp_hue() entry point can be fed
from real measured pack temperature instead of the factory manual control.

All Step47/48 I2C stability, OTC glitch protection, Diagnostic 4S pack row,
touch behavior, themes, and current-event behavior remain unchanged.
