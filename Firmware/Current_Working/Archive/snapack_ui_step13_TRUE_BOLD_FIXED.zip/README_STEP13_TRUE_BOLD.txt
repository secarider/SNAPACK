SNAPACK STEP 13 — TRUE HEAVIER FONT TEST

Baseline:
  Physically accepted Step 12B.

Purpose:
  Replace the visually ineffective 1-pixel overdraw experiment with actual
  heavier glyphs while preserving the accepted Screen5 geometry.

Font resources:
  * snapack_bold_44.c
      true bold 44 px glyphs for voltage values
      subset: digits 0-9 and decimal point

  * snapack_bold_20.c
      true bold 20 px glyphs for headings
      subset: digits 0-9 plus A,C,K,P for PACK

The rasterized glyphs were generated from Liberation Sans Bold.
No TTF/font file is included in the archive.

UNCHANGED FROM STEP 12B:
  * five-cell + PACK grid
  * cell values = two decimals
  * PACK = one decimal
  * 1,2,3,4,5,PACK position = y - 32
  * DAY/NIGHT colors
  * short Return -> carousel
  * long Return -> DAY/NIGHT toggle and remain on Screen5
  * Return size
  * no ADS1115/GL5528 acquisition yet

INSTALL:
  Copy the complete UI file set into:
    /home/valued/Arduino/libraries/UI/

  The two new .c files MUST be copied with the other UI files or the link
  will fail because Screen5 references snapack_bold_20 and snapack_bold_44.

PHYSICAL TEST:
  Compare stroke weight on both DAY and NIGHT themes.
  Pay special attention to:
    * black numerals on the bright white DAY background
    * PACK heading and 20.9 width
    * whether the heavier glyph family still looks balanced in the accepted grid

If the family/weight does not look right, Step 12B remains the clean rollback.
