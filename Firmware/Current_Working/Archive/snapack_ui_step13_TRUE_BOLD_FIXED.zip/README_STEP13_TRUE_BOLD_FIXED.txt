SNAPACK STEP 13 — TRUE BOLD / FONT SOURCE FIX

Baseline:
  Step 13 TRUE BOLD package.

Repair:
  The generated snapack_bold_20.c and snapack_bold_44.c files contained
  malformed glyph-comment text, which caused the C compiler to stop before
  the glyph descriptor arrays were parsed.

  This package fixes only those generated comment blocks.

Unchanged:
  * true heavier 44 px voltage font
  * true heavier 20 px 1,2,3,4,5,PACK font
  * Step 12B geometry and spacing
  * cells = two decimals
  * PACK = one decimal
  * DAY/NIGHT behavior
  * short Return -> carousel
  * long Return -> theme toggle and remain on Screen5

Install:
  Replace the Step 13 files in /home/valued/Arduino/libraries/UI/ with
  the files from this package, including:
    snapack_bold_20.c
    snapack_bold_44.c

Then reopen snapack.ino and Verify again.
