// SNAPACK DIAGNOSTIC SCREEN
#include "ui.h"

static bool snapDiagDay = false;
static bool snapDiagThemeLongPressConsumed = false;
static lv_obj_t * snapDiagTitle = NULL;
#define SNAP_DIAG_RING_SEGMENTS 36
static lv_obj_t * snapDiagRing[SNAP_DIAG_RING_SEGMENTS];
static unsigned long snapDiagAnimTick = 0;
static int snapDiagAnimPhase = 0;
static uint32_t snapDiagSpeed_mrev = 150;
static uint32_t snapDiagPhaseMilli = 0;

static lv_obj_t * snapDiagNameRail = NULL;
static lv_obj_t * snapDiagNameLastPeak = NULL;
static lv_obj_t * snapDiagNameSessionPeak = NULL;
static lv_obj_t * snapDiagNamePack = NULL;
static lv_obj_t * snapDiagName4SPack = NULL;
static lv_obj_t * snapDiagNameLowCell = NULL;

static lv_obj_t * snapDiagValueRail = NULL;
static lv_obj_t * snapDiagValueLastPeak = NULL;
static lv_obj_t * snapDiagValueSessionPeak = NULL;
static lv_obj_t * snapDiagValuePack = NULL;
static lv_obj_t * snapDiagValue4SPack = NULL;
static lv_obj_t * snapDiagValueLowCell = NULL;

static lv_color_t diag_bg(void)   { return snapDiagDay ? lv_color_hex(0xFFFFFF) : lv_color_hex(0x000000); }
static lv_color_t diag_text(void) { return snapDiagDay ? lv_color_hex(0x000000) : lv_color_hex(0xFFFFFF); }
static lv_color_t diag_accent(void){ return snapDiagDay ? lv_color_hex(0x000000) : lv_color_hex(0x33DCFF); }

static void diag_apply_text_color(void)
{
    lv_obj_t * all[] = {
        snapDiagNameRail, snapDiagNameLastPeak, snapDiagNameSessionPeak,
        snapDiagNamePack, snapDiagName4SPack, snapDiagNameLowCell,
        snapDiagValueRail, snapDiagValueLastPeak, snapDiagValueSessionPeak,
        snapDiagValuePack, snapDiagValue4SPack, snapDiagValueLowCell
    };

    for (unsigned i = 0; i < sizeof(all)/sizeof(all[0]); i++) {
        if (all[i]) lv_obj_set_style_text_color(all[i], diag_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    }
}

static lv_color_t diag_ring_color(int slot)
{
    // NIGHT: rotating rainbow.
    // DAY: same animation timing/phase, rendered strictly black/gray/white.
    static const uint32_t night_colors[] = {
        0x33DCFF, 0x4C8DFF, 0x7C5CFF, 0xD45CFF,
        0xFF5CA8, 0xFF6A55, 0xFFD24A, 0x7FE05A
    };
    static const uint32_t day_colors[] = {
        0x000000, 0x202020, 0x505050, 0x808080,
        0xB0B0B0, 0xE0E0E0, 0xB0B0B0, 0x505050
    };
    return lv_color_hex(snapDiagDay ? day_colors[slot % 8]
                                    : night_colors[slot % 8]);
}

void ui_set_snapack_diag_ring_speed(int volume_value)
{
    if (volume_value < 0) volume_value = 0;
    if (volume_value > 100) volume_value = 100;
    uint32_t vv = (uint32_t)volume_value * (uint32_t)volume_value;
    snapDiagSpeed_mrev = (uint16_t)(150 + (3850UL * vv) / 10000UL);
}

void ui_service_snapack_diag_animation(void)
{
    if (!ui_Screen8 || lv_scr_act() != ui_Screen8) return;
    static unsigned long lastFrameMs = 0;
    unsigned long now = millis();
    if (lastFrameMs == 0) lastFrameMs = now;
    unsigned long dt = now - lastFrameMs;
    if (dt < 16) return;
    lastFrameMs = now;

    uint64_t deltaMilliSeg = (uint64_t)dt * snapDiagSpeed_mrev * SNAP_DIAG_RING_SEGMENTS;
    deltaMilliSeg /= 1000ULL;
    snapDiagPhaseMilli = (snapDiagPhaseMilli + (uint32_t)deltaMilliSeg) % (SNAP_DIAG_RING_SEGMENTS * 1000UL);
    snapDiagAnimPhase = (int)(snapDiagPhaseMilli / 1000UL);

    for (int i=0; i<SNAP_DIAG_RING_SEGMENTS; i++) {
        int relative = (i - snapDiagAnimPhase + SNAP_DIAG_RING_SEGMENTS) % SNAP_DIAG_RING_SEGMENTS;
        lv_obj_set_style_arc_color(snapDiagRing[i], diag_ring_color(relative),
                                   LV_PART_MAIN | LV_STATE_DEFAULT);
    }
}

bool snapack_diag_consume_theme_long_press(void)
{
    if (snapDiagThemeLongPressConsumed) {
        snapDiagThemeLongPressConsumed = false;
        return true;
    }
    return false;
}

static void snap_diag_theme_long_press_event(lv_event_t * e)
{
    if (lv_event_get_code(e) == LV_EVENT_LONG_PRESSED) {
        snapDiagThemeLongPressConsumed = true;
        ui_set_snapack_diag_theme(!snapDiagDay);
    }
}

void ui_set_snapack_diag_theme(bool day_mode)
{
    snapDiagDay = day_mode;
    if (!ui_Screen8) return;

    lv_obj_set_style_bg_color(ui_Screen8, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
    if (snapDiagTitle)
        lv_obj_set_style_text_color(snapDiagTitle, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);

    diag_apply_text_color();

    for (int i = 0; i < SNAP_DIAG_RING_SEGMENTS; i++) {
        if (snapDiagRing[i]) {
            int relative = (i - snapDiagAnimPhase + SNAP_DIAG_RING_SEGMENTS) % SNAP_DIAG_RING_SEGMENTS;
            lv_obj_set_style_arc_color(snapDiagRing[i], diag_ring_color(relative),
                                       LV_PART_MAIN | LV_STATE_DEFAULT);
        }
    }

    if (ui_SnapackDiagReturnBt)
        lv_obj_set_style_bg_color(ui_SnapackDiagReturnBt, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);
    if (ui_SnapackDiagReturnLabel)
        lv_obj_set_style_text_color(ui_SnapackDiagReturnLabel, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
}

void ui_update_snapack_diagnostics(int rail_mV, int last_peak_A, int session_peak_A,
                                   int pack_mV, int pack4s_mV, int low_cell_mV)
{
    char b[32];

    if (snapDiagValueRail) {
        snprintf(b, sizeof(b), "%d.%02d V", rail_mV / 1000, abs((rail_mV % 1000) / 10));
        lv_label_set_text(snapDiagValueRail, b);
    }

    if (snapDiagValueLastPeak) {
        snprintf(b, sizeof(b), "%d A", last_peak_A);
        lv_label_set_text(snapDiagValueLastPeak, b);
    }

    if (snapDiagValueSessionPeak) {
        snprintf(b, sizeof(b), "%d A", session_peak_A);
        lv_label_set_text(snapDiagValueSessionPeak, b);
    }

    if (snapDiagValuePack) {
        snprintf(b, sizeof(b), "%d.%03d V", pack_mV / 1000, abs(pack_mV % 1000));
        lv_label_set_text(snapDiagValuePack, b);
    }

    if (snapDiagValue4SPack) {
        snprintf(b, sizeof(b), "%d.%03d V", pack4s_mV / 1000, abs(pack4s_mV % 1000));
        lv_label_set_text(snapDiagValue4SPack, b);
    }

    if (snapDiagValueLowCell) {
        snprintf(b, sizeof(b), "%d.%03d V", low_cell_mV / 1000, abs(low_cell_mV % 1000));
        lv_label_set_text(snapDiagValueLowCell, b);
    }
}

static void diag_make_row(lv_obj_t **name_obj,
                          lv_obj_t **value_obj,
                          const char *name_text,
                          const char *value_text,
                          int y)
{
    // Fixed 380 px row container. Labels and values are independent children,
    // so changing digit width cannot recenter or shove the other column.
    lv_obj_t * row = lv_obj_create(ui_Screen8);
    lv_obj_set_width(row, 350);
    lv_obj_set_height(row, 44);
    lv_obj_set_align(row, LV_ALIGN_CENTER);
    lv_obj_set_y(row, y);
    lv_obj_set_style_bg_opa(row, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_border_opa(row, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_all(row, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_clear_flag(row, LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_CLICKABLE);

    *name_obj = lv_label_create(row);
    lv_obj_set_width(*name_obj, 175);
    lv_obj_set_height(*name_obj, LV_SIZE_CONTENT);
    lv_obj_align(*name_obj, LV_ALIGN_LEFT_MID, 8, 0);
    lv_label_set_text(*name_obj, name_text);
    lv_obj_set_style_text_align(*name_obj, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(*name_obj, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(*name_obj, diag_text(), LV_PART_MAIN | LV_STATE_DEFAULT);

    *value_obj = lv_label_create(row);
    lv_obj_set_width(*value_obj, 155);
    lv_obj_set_height(*value_obj, LV_SIZE_CONTENT);
    lv_obj_align(*value_obj, LV_ALIGN_RIGHT_MID, -8, 0);
    lv_label_set_text(*value_obj, value_text);
    lv_obj_set_style_text_align(*value_obj, LV_TEXT_ALIGN_RIGHT, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(*value_obj, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(*value_obj, diag_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
}

void ui_Screen8_screen_init(void)
{
    ui_Screen8 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen8, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(ui_Screen8, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen8, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // STEP 40: decorative/status perimeter animation for Diagnostic.
    const int diag_segment_span = 6;
    const int diag_segment_step = 10;
    for (int i=0; i<SNAP_DIAG_RING_SEGMENTS; i++) {
        lv_obj_t * seg = lv_arc_create(ui_Screen8);
        snapDiagRing[i] = seg;
        lv_obj_set_width(seg, 430);
        lv_obj_set_height(seg, 430);
        lv_obj_set_align(seg, LV_ALIGN_CENTER);
        lv_arc_set_rotation(seg, 135 + i * diag_segment_step);
        lv_arc_set_bg_angles(seg, 0, diag_segment_span);
        lv_arc_set_range(seg, 0, 100);
        lv_arc_set_value(seg, 100);
        lv_obj_remove_style(seg, NULL, LV_PART_KNOB);
        lv_obj_clear_flag(seg, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_set_style_arc_opa(seg, 0, LV_PART_INDICATOR | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_width(seg, 10, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_rounded(seg, false, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_color(seg, diag_ring_color(i), LV_PART_MAIN | LV_STATE_DEFAULT);
    }

    snapDiagTitle = lv_label_create(ui_Screen8);
    lv_label_set_text(snapDiagTitle, "DIAGNOSTIC");
    lv_obj_set_align(snapDiagTitle, LV_ALIGN_CENTER);
    lv_obj_set_y(snapDiagTitle, -150);
    lv_obj_set_style_text_font(snapDiagTitle, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(snapDiagTitle, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);

    const int ys[] = {-102, -68, -34, 0, 34, 68};

    diag_make_row(&snapDiagNameRail,        &snapDiagValueRail,
                  "24V RAIL",    "0.00 V",  ys[0]);
    diag_make_row(&snapDiagNameLastPeak,    &snapDiagValueLastPeak,
                  "LAST PEAK",   "0 A",     ys[1]);
    diag_make_row(&snapDiagNameSessionPeak, &snapDiagValueSessionPeak,
                  "SESSION MAX", "0 A",     ys[2]);
    diag_make_row(&snapDiagNamePack,        &snapDiagValuePack,
                  "FULL PACK",   "0.000 V", ys[3]);
    diag_make_row(&snapDiagName4SPack,      &snapDiagValue4SPack,
                  "4S PACK",     "0.000 V", ys[4]);
    diag_make_row(&snapDiagNameLowCell,     &snapDiagValueLowCell,
                  "LOWEST CELL", "0.000 V", ys[5]);

    ui_SnapackDiagReturnBt = lv_btn_create(ui_Screen8);
    lv_obj_set_width(ui_SnapackDiagReturnBt, 168);
    lv_obj_set_height(ui_SnapackDiagReturnBt, 54);
    lv_obj_set_align(ui_SnapackDiagReturnBt, LV_ALIGN_CENTER);
    lv_obj_set_y(ui_SnapackDiagReturnBt, 164);
    lv_obj_set_style_bg_color(ui_SnapackDiagReturnBt, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(ui_SnapackDiagReturnBt, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_ext_click_area(ui_SnapackDiagReturnBt, 36);

    ui_SnapackDiagReturnLabel = lv_label_create(ui_Screen8);
    lv_label_set_text(ui_SnapackDiagReturnLabel, "Return");
    lv_obj_set_align(ui_SnapackDiagReturnLabel, LV_ALIGN_CENTER);
    lv_obj_set_y(ui_SnapackDiagReturnLabel, 164);
    lv_obj_set_style_text_font(ui_SnapackDiagReturnLabel, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui_SnapackDiagReturnLabel, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_add_event_cb(ui_SnapackDiagReturnBt, ui_event_screen8ReturnBt, LV_EVENT_ALL, NULL);
    lv_obj_add_event_cb(ui_SnapackDiagReturnBt, snap_diag_theme_long_press_event, LV_EVENT_LONG_PRESSED, NULL);
}
