SNAPACK STEP 61

- Maximum Volume speed reduced from 10 rev/s to 4 rev/s.
- Quadratic low-speed control retained.
- Carousel, Cell Voltage and Temperature use four equally spaced moving heads,
  each with a fading tail, to preserve visible directional motion at high speed.
- Carousel swipe burst reduced from 18 rev/s to 7 rev/s.
- Swipe thickness/color/direction behavior remains in day and night themes.
- Physical double-click escape is reimplemented synchronously in the main-loop
  switch service. Carousel single-push remains immediate. On every sub-screen,
  two physical pushes within 420 ms return to Carousel; one push does nothing.
- OEM touch/Return behavior is unchanged.
