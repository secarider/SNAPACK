SNAPACK STEP 21 — PURPOSE-BUILT BIG CURRENT FONT

Baseline:
  Step 20 segmented-current-ring build.

Change:
  Main Current value:
      built-in Montserrat 48 -> purpose-built numeric 96 px font

The custom font contains only:
  0 1 2 3 4 5 6 7 8 9

Reason:
  The Current screen is the first SNAPACK screen whose entire visual purpose
  is one dominant number.  This is where a custom large font earns its cost.

Unchanged:
  * A remains stock Montserrat 48
  * segmented Current ring remains
  * 11/18 ring fill remains development-only
  * DAY/NIGHT behavior remains
  * short Return remains
  * Cell Voltage and Temperature remain unchanged
  * carousel remains unchanged

NEW FILE — IMPORTANT:
  snapack_current_96.c

Copy it into:
  /home/valued/Arduino/libraries/UI/

along with the revised ui.h and ui_Screen7.c.

Physical test:
  The simulated value is still 187, deliberately giving us a three-digit
  test.  Judge whether 96 px is large enough, too large, or about right.
  The font machinery is now isolated, so a later 112/120 px revision would
  only require replacing this one purpose-built font and adjusting placement.
