SNAPACK UI STEP 4 — READABILITY PASS
====================================

Baseline:
  Physically verified Step 3 five-cell + pack layout.

Purpose:
  Use more of the physical 480 x 480 round display before adding live ADC data.

Changes:
  * Keep the 2-row / 3-column measurement grid.
  * Change headings:
      CELL 1 -> 1
      CELL 2 -> 2
      CELL 3 -> 3
      CELL 4 -> 4
      CELL 5 -> 5
      PACK   -> PACK
  * Increase voltage-value font from Montserrat 22 to Montserrat 24.
  * Replace the top CELL VOLTAGES title with SIMULATED while values are fake.
  * Remove the separate lower SIMULATED label.
  * Enlarge the Return button and Return text.
  * Centralize Screen5 colors in preparation for a future DAY/NIGHT theme.

Future DAY/NIGHT direction:
  NIGHT:
    black background
    cyan values
    white labels

  DAY:
    white background
    black values
    black labels

Theme selection should first be implemented manually in software.
A light sensor can later drive the same selection automatically if desired
and if a suitable input is available.

Measurement architecture is unchanged:
  snapack.ino              = application / measurement data
  ui_Screen5.c             = presentation
  ui_update_snapack_cells  = data-to-UI boundary

No ADS1115 data is present yet.

Install:
  snapack.ino ->
    /home/valued/Arduino/snapack/snapack.ino

  ui.c, ui.h, ui_Screen1.c, ui_Screen5.c ->
    /home/valued/Arduino/libraries/UI/

Only ui_Screen5.c changed from Step 3, but the complete current file set is
included so this revision can be archived as one known-good checkpoint.

Test:
  1. Reopen snapack.ino in Arduino IDE.
  2. Verify/compile once.
  3. Export Compiled Binary.
  4. Flash with the proven esptool --no-stub command.
  5. Check readability and edge clearance of all six values.
  6. Test all four carousel destinations.
  7. Verify Return touch and rotary double-click behavior.
