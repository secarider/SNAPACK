// SNAPACK DIAGNOSTIC SCREEN
#include "ui.h"

static bool snapDiagDay = false;
static lv_obj_t * snapDiagTitle = NULL;
static lv_obj_t * snapDiagRail = NULL;
static lv_obj_t * snapDiagLastPeak = NULL;
static lv_obj_t * snapDiagSessionPeak = NULL;
static lv_obj_t * snapDiagPack = NULL;
static lv_obj_t * snapDiagLowCell = NULL;

static lv_color_t diag_bg(void)   { return snapDiagDay ? lv_color_hex(0xFFFFFF) : lv_color_hex(0x000000); }
static lv_color_t diag_text(void) { return snapDiagDay ? lv_color_hex(0x000000) : lv_color_hex(0xFFFFFF); }
static lv_color_t diag_accent(void){ return snapDiagDay ? lv_color_hex(0x000000) : lv_color_hex(0x33DCFF); }

void ui_set_snapack_diag_theme(bool day_mode)
{
    snapDiagDay = day_mode;
    if (!ui_Screen8) return;
    lv_obj_set_style_bg_color(ui_Screen8, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
    if (snapDiagTitle) lv_obj_set_style_text_color(snapDiagTitle, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_t * labels[] = {snapDiagRail, snapDiagLastPeak, snapDiagSessionPeak, snapDiagPack, snapDiagLowCell};
    for (unsigned i = 0; i < sizeof(labels)/sizeof(labels[0]); i++) {
        if (labels[i]) lv_obj_set_style_text_color(labels[i], diag_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    }
    if (ui_SnapackDiagReturnBt)
        lv_obj_set_style_bg_color(ui_SnapackDiagReturnBt, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);
    if (ui_SnapackDiagReturnLabel)
        lv_obj_set_style_text_color(ui_SnapackDiagReturnLabel, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
}

static void diag_set_line(lv_obj_t * label, const char *name, int value, const char *unit)
{
    if (!label) return;
    char buf[48];
    snprintf(buf, sizeof(buf), "%-12s %d%s", name, value, unit);
    lv_label_set_text(label, buf);
}

void ui_update_snapack_diagnostics(int rail_mV, int last_peak_A, int session_peak_A,
                                   int pack_mV, int low_cell_mV)
{
    diag_set_line(snapDiagRail,        "24V RAIL",    rail_mV / 10, ""); // fixed below with decimal
    if (snapDiagRail) {
        char b[48];
        snprintf(b, sizeof(b), "24V  %d.%02d V", rail_mV/1000, abs((rail_mV%1000)/10));
        lv_label_set_text(snapDiagRail, b);
    }
    diag_set_line(snapDiagLastPeak,    "LAST",   last_peak_A, "A");
    diag_set_line(snapDiagSessionPeak, "MAX", session_peak_A, "A");
    if (snapDiagPack) {
        char b[48];
        snprintf(b, sizeof(b), "PACK  %d.%03d V", pack_mV/1000, abs(pack_mV%1000));
        lv_label_set_text(snapDiagPack, b);
    }
    if (snapDiagLowCell) {
        char b[48];
        snprintf(b, sizeof(b), "LOW   %d.%03d V", low_cell_mV/1000, abs(low_cell_mV%1000));
        lv_label_set_text(snapDiagLowCell, b);
    }
}

void ui_Screen8_screen_init(void)
{
    ui_Screen8 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen8, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(ui_Screen8, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen8, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    snapDiagTitle = lv_label_create(ui_Screen8);
    lv_label_set_text(snapDiagTitle, "DIAGNOSTIC");
    lv_obj_set_align(snapDiagTitle, LV_ALIGN_CENTER);
    lv_obj_set_y(snapDiagTitle, -158);
    lv_obj_set_style_text_font(snapDiagTitle, &lv_font_montserrat_48, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(snapDiagTitle, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_t ** labels[] = {&snapDiagRail,&snapDiagLastPeak,&snapDiagSessionPeak,&snapDiagPack,&snapDiagLowCell};
    const int ys[] = {-98,-52,-6,40,86};
    for (int i=0;i<5;i++) {
        *labels[i] = lv_label_create(ui_Screen8);
        lv_obj_set_align(*labels[i], LV_ALIGN_CENTER);
        lv_obj_set_x(*labels[i], 0);
        lv_obj_set_y(*labels[i], ys[i]);
        lv_obj_set_style_text_font(*labels[i], &lv_font_montserrat_18, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_transform_zoom(*labels[i], 512, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_text_color(*labels[i], diag_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    }

    ui_SnapackDiagReturnBt = lv_btn_create(ui_Screen8);
    lv_obj_set_width(ui_SnapackDiagReturnBt, 168);
    lv_obj_set_height(ui_SnapackDiagReturnBt, 54);
    lv_obj_set_align(ui_SnapackDiagReturnBt, LV_ALIGN_CENTER);
    lv_obj_set_y(ui_SnapackDiagReturnBt, 164);
    lv_obj_set_style_bg_color(ui_SnapackDiagReturnBt, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(ui_SnapackDiagReturnBt, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_ext_click_area(ui_SnapackDiagReturnBt, 36);

    ui_SnapackDiagReturnLabel = lv_label_create(ui_Screen8);
    lv_label_set_text(ui_SnapackDiagReturnLabel, "Return");
    lv_obj_set_align(ui_SnapackDiagReturnLabel, LV_ALIGN_CENTER);
    lv_obj_set_y(ui_SnapackDiagReturnLabel, 164);
    lv_obj_set_style_text_font(ui_SnapackDiagReturnLabel, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui_SnapackDiagReturnLabel, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_add_event_cb(ui_SnapackDiagReturnBt, ui_event_screen8ReturnBt, LV_EVENT_ALL, NULL);
}
