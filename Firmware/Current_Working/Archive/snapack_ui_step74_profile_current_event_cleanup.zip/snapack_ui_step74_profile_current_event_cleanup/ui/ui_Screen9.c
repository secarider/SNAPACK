// SNAPACK STEP74 COLOR PROFILE SELECTOR + DEDICATED EDITOR
#include "ui.h"
#include "snapack_ring_frames.h"
#include "snapack_color_profiles.h"
#include <stdio.h>

static snap_color_target_t editTarget = SNAP_COLOR_TARGET_CAROUSEL;
static snap_color_target_t selectorTarget = SNAP_COLOR_TARGET_CAROUSEL;
static lv_obj_t * titleLabel = NULL;
static lv_obj_t * modeLabel = NULL;
static lv_obj_t * valueLabel = NULL;
static lv_obj_t * previewRing[SNAP_RING_TILE_COUNT] = {0};
static lv_obj_t * choiceBtn[7] = {0};
static lv_obj_t * selectorCenterHit = NULL;
static lv_obj_t * selectorHint = NULL;
static bool selectorConfigured = false;
static uint32_t previewPhaseMilli = 0;
static uint32_t previewSpeed_mrev = 150;
static int previewFrame = -1;

static const char * choiceText[7] = {"-40", "-20", "COMP", "+20", "+40", "RAIN", "FIX"};
static const uint32_t selectorColors[SNAP_COLOR_TARGET_COUNT] = {
    0x33DCFF, // MAIN CAROUSEL
    0x7CFF6B, // CELL VOLTAGE
    0xFFB347, // TEMPERATURE
    0xD66BFF, // DIAGNOSTIC
    0x33DCFF  // CURRENT
};

static void editor_apply_preview(void)
{
    snap_color_profile_t *p = snap_color_profile(editTarget);
    lv_color_t bg = snap_color_background(p);
    lv_obj_set_style_bg_color(ui_Screen9, bg, LV_PART_MAIN | LV_STATE_DEFAULT);

    int active = snap_color_get_ring_choice(p);
    for (int i=0; i<7; ++i) {
        if (!choiceBtn[i]) continue;
        lv_obj_set_style_bg_opa(choiceBtn[i], i == active ? 90 : 25, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_border_opa(choiceBtn[i], i == active ? 220 : 80, LV_PART_MAIN | LV_STATE_DEFAULT);
    }

    int v = (p->ring_mode == SNAP_RING_FIXED) ? p->fixed_ring_pct : p->background_pct;
    lv_arc_set_value(ui_SnapackColorArc, v);
    char buf[24];
    snprintf(buf, sizeof(buf), "%d%%", v);
    lv_label_set_text(valueLabel, buf);
    lv_label_set_text(modeLabel, p->ring_mode == SNAP_RING_FIXED ? "FIXED RING COLOR" : "BACKGROUND COLOR");
    lv_label_set_text(titleLabel, snap_color_target_name(editTarget));

    lv_color_t ring = snap_color_ring(p);
    for (int i=0; i<SNAP_RING_TILE_COUNT; ++i) {
        if (!previewRing[i]) continue;
        lv_obj_set_style_img_recolor(previewRing[i],
            p->ring_mode == SNAP_RING_RAINBOW ? snap_color_rainbow(i) : ring,
            LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_img_recolor_opa(previewRing[i], LV_OPA_COVER, LV_PART_MAIN | LV_STATE_DEFAULT);
    }
}

static void selector_refresh(void)
{
    if (!ui_Screen3 || !ui_TempArc || !ui_TempNum) return;
    lv_label_set_text(ui_TempNum, snap_color_target_name(selectorTarget));
    lv_obj_set_style_text_font(ui_TempNum, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui_TempNum, lv_color_hex(0xFFFFFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_arc_color(ui_TempArc, lv_color_hex(selectorColors[(int)selectorTarget]), LV_PART_INDICATOR | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui_TempArc, lv_color_hex(selectorColors[(int)selectorTarget]), LV_PART_KNOB | LV_STATE_DEFAULT);
}

static void selector_refresh_async(void *unused)
{
    (void)unused;
    selector_refresh();
}

static snap_color_target_t selector_target_from_arc(void)
{
    int v = lv_arc_get_value(ui_TempArc);
    int t = (v * SNAP_COLOR_TARGET_COUNT) / 201;
    if (t < 0) t = 0;
    if (t >= SNAP_COLOR_TARGET_COUNT) t = SNAP_COLOR_TARGET_COUNT - 1;
    return (snap_color_target_t)t;
}

static int selector_center_value(snap_color_target_t target)
{
    int t = (int)target;
    if (t < 0) t = 0;
    if (t >= SNAP_COLOR_TARGET_COUNT) t = SNAP_COLOR_TARGET_COUNT - 1;
    // Five equal sectors across the preserved OEM 0..200 sweep: 20,60,100,140,180.
    return (t * 200 + 100) / SNAP_COLOR_TARGET_COUNT;
}

static void selector_arc_event(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_VALUE_CHANGED) return;
    snap_color_target_t next = selector_target_from_arc();
    if (next != selectorTarget) selectorTarget = next;
    // Refresh now and once after the current LVGL event finishes.  The deferred
    // refresh wins over any stale OEM temperature callback still present in a
    // generated Screen3 build, preventing °C/°F text from replacing the target name.
    selector_refresh();
    lv_async_call(selector_refresh_async, NULL);
}

static void selector_open_editor(void)
{
    editTarget = selectorTarget;
    // Screen9 is pre-created by ui_init(), so refresh its already-existing objects before loading it.
    // If a future helper revision reinitializes Screen9 on load, ui_Screen9_screen_init() uses the same editTarget.
    if (ui_Screen9) editor_apply_preview();
    _ui_screen_change(&ui_Screen9, LV_SCR_LOAD_ANIM_FADE_ON, 180, 0, &ui_Screen9_screen_init);
}

static void selector_center_event(lv_event_t *e)
{
    if (lv_event_get_code(e) == LV_EVENT_CLICKED) selector_open_editor();
}

static void editor_choice_event(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    int choice = (int)(intptr_t)lv_event_get_user_data(e);
    snap_color_set_ring_choice(snap_color_profile(editTarget), choice);
    editor_apply_preview();
    ui_apply_snapack_color_profiles();
    snapack_request_profile_save();
}

static void editor_arc_event(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_VALUE_CHANGED) return;
    int value = lv_arc_get_value(ui_SnapackColorArc);
    snap_color_profile_t *p = snap_color_profile(editTarget);
    if (p->ring_mode == SNAP_RING_FIXED) p->fixed_ring_pct = (uint8_t)value;
    else p->background_pct = (uint8_t)value;
    editor_apply_preview();
    ui_apply_snapack_color_profiles();
    snapack_request_profile_save();
}

static void editor_return_event(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    selectorTarget = editTarget;
    if (ui_TempArc) lv_arc_set_value(ui_TempArc, selector_center_value(selectorTarget));
    selector_refresh();
    _ui_screen_change(&ui_Screen3, LV_SCR_LOAD_ANIM_FADE_ON, 180, 0, &ui_Screen3_screen_init);
}

void ui_service_snapack_color_editor(void)
{
    if (!ui_Screen9 || lv_scr_act() != ui_Screen9) return;
    static unsigned long last = 0;
    unsigned long now = millis();
    unsigned long dt = now - last;
    if (last == 0) { last = now; return; }
    if (dt < 40) return;
    last = now;
    uint64_t deltaMilliFrame = (uint64_t)dt * previewSpeed_mrev * 24ULL;
    deltaMilliFrame /= 1000ULL;
    previewPhaseMilli = (previewPhaseMilli + (uint32_t)deltaMilliFrame) % (SNAP_RING_FRAME_COUNT * 1000UL);
    int frame = (int)(previewPhaseMilli / 1000UL);
    if (frame == previewFrame) return;
    previewFrame = frame;
    snap_color_profile_t *p = snap_color_profile(editTarget);
    for (int i=0; i<SNAP_RING_TILE_COUNT; ++i) {
        if (!previewRing[i]) continue;
        lv_img_set_src(previewRing[i], snap_ring_frames[frame][i]);
        if (p->ring_mode == SNAP_RING_RAINBOW)
            lv_obj_set_style_img_recolor(previewRing[i], snap_color_rainbow(i + frame), LV_PART_MAIN | LV_STATE_DEFAULT);
    }
}

void ui_Screen9_screen_init(void)
{
    snap_color_profiles_init_defaults();
    ui_Screen9 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen9, LV_OBJ_FLAG_SCROLLABLE);

    for (int i=0; i<SNAP_RING_TILE_COUNT; ++i) {
        previewRing[i] = lv_img_create(ui_Screen9);
        lv_img_set_src(previewRing[i], snap_ring_frames[0][i]);
        lv_obj_set_pos(previewRing[i], snap_ring_tile_x[i], snap_ring_tile_y[i]);
        lv_obj_clear_flag(previewRing[i], LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE);
    }

    titleLabel = lv_label_create(ui_Screen9);
    lv_obj_align(titleLabel, LV_ALIGN_TOP_MID, 0, 31);
    lv_obj_set_style_text_font(titleLabel, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(titleLabel, lv_color_hex(0xFFFFFF), 0);

    // Dedicated editor: no target dots and no horizontal target-swipe gesture.
    // Every gesture on this screen belongs to color editing or the explicit buttons.
    ui_SnapackColorArc = lv_arc_create(ui_Screen9);
    lv_obj_set_size(ui_SnapackColorArc, 300, 300);
    lv_obj_align(ui_SnapackColorArc, LV_ALIGN_CENTER, 0, -2);
    lv_arc_set_rotation(ui_SnapackColorArc, 140);
    lv_arc_set_bg_angles(ui_SnapackColorArc, 0, 250);
    lv_arc_set_range(ui_SnapackColorArc, 0, 100);
    lv_obj_set_style_arc_width(ui_SnapackColorArc, 14, LV_PART_MAIN);
    lv_obj_set_style_arc_width(ui_SnapackColorArc, 18, LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(ui_SnapackColorArc, lv_color_hex(0x303030), LV_PART_MAIN);
    lv_obj_set_style_arc_color(ui_SnapackColorArc, lv_color_hex(0xFFFFFF), LV_PART_INDICATOR);
    lv_obj_set_style_bg_color(ui_SnapackColorArc, lv_color_hex(0xFFFFFF), LV_PART_KNOB);
    lv_obj_add_event_cb(ui_SnapackColorArc, editor_arc_event, LV_EVENT_VALUE_CHANGED, NULL);

    valueLabel = lv_label_create(ui_Screen9);
    lv_obj_align(valueLabel, LV_ALIGN_CENTER, 0, -12);
    lv_obj_set_style_text_font(valueLabel, &lv_font_montserrat_40, 0);
    lv_obj_set_style_text_color(valueLabel, lv_color_hex(0xFFFFFF), 0);

    modeLabel = lv_label_create(ui_Screen9);
    lv_obj_align(modeLabel, LV_ALIGN_CENTER, 0, 31);
    lv_obj_set_style_text_font(modeLabel, &lv_font_montserrat_16, 0);
    lv_obj_set_style_text_color(modeLabel, lv_color_hex(0xFFFFFF), 0);

    // Seven explicit touch choices.  The old post-100% gray continuation arc is intentionally gone:
    // target selection now lives on Screen3, so this screen can devote its full circular control to color.
    for (int i=0; i<7; ++i) {
        choiceBtn[i] = lv_btn_create(ui_Screen9);
        // STEP74: substantially larger touch targets while retaining one clean row.
        lv_obj_set_size(choiceBtn[i], 60, 42);
        int x = -192 + i * 64;
        lv_obj_align(choiceBtn[i], LV_ALIGN_BOTTOM_MID, x, -58);
        lv_obj_set_style_radius(choiceBtn[i], 10, 0);
        lv_obj_set_style_bg_color(choiceBtn[i], lv_color_hex(0xFFFFFF), 0);
        lv_obj_set_style_border_color(choiceBtn[i], lv_color_hex(0xFFFFFF), 0);
        lv_obj_set_style_border_width(choiceBtn[i], 1, 0);
        lv_obj_add_event_cb(choiceBtn[i], editor_choice_event, LV_EVENT_CLICKED, (void*)(intptr_t)i);
        lv_obj_t *l = lv_label_create(choiceBtn[i]);
        lv_label_set_text(l, choiceText[i]);
        lv_obj_center(l);
        lv_obj_set_style_text_font(l, &lv_font_montserrat_16, 0);
        lv_obj_set_style_text_color(l, lv_color_hex(0xFFFFFF), 0);
    }

    ui_SnapackColorReturnBt = lv_btn_create(ui_Screen9);
    lv_obj_set_size(ui_SnapackColorReturnBt, 108, 38);
    lv_obj_align(ui_SnapackColorReturnBt, LV_ALIGN_BOTTOM_MID, 0, -8);
    lv_obj_set_style_bg_opa(ui_SnapackColorReturnBt, 40, 0);
    lv_obj_add_event_cb(ui_SnapackColorReturnBt, editor_return_event, LV_EVENT_CLICKED, NULL);
    lv_obj_t *ret = lv_label_create(ui_SnapackColorReturnBt);
    lv_label_set_text(ret, "RETURN");
    lv_obj_center(ret);

    editor_apply_preview();
}

void ui_configure_snapack_color_profile_selector(void)
{
    if (!ui_Screen3 || !ui_TempArc || !ui_TempNum) return;

    // Preserve the OEM arc's exact geometry and 0-200 travel, but replace its old
    // temperature/global-color semantics with five equal profile-selection sectors.
    lv_arc_set_range(ui_TempArc, 0, 200);
    lv_arc_set_value(ui_TempArc, selector_center_value(selectorTarget));
    lv_obj_set_style_arc_color(ui_TempArc, lv_color_hex(0x303030), LV_PART_MAIN | LV_STATE_DEFAULT);

    if (ui_Label1) {
        lv_label_set_text(ui_Label1, "COLOR PROFILES");
        lv_obj_set_style_text_font(ui_Label1, &lv_font_montserrat_18, LV_PART_MAIN | LV_STATE_DEFAULT);
    }

    if (!selectorConfigured) {
        lv_obj_add_event_cb(ui_TempArc, selector_arc_event, LV_EVENT_VALUE_CHANGED, NULL);

        // Large center hit target: choose with the arc, then tap the name to enter.
        selectorCenterHit = lv_btn_create(ui_Screen3);
        lv_obj_set_size(selectorCenterHit, 220, 112);
        lv_obj_align(selectorCenterHit, LV_ALIGN_CENTER, 0, 2);
        lv_obj_set_style_bg_opa(selectorCenterHit, LV_OPA_TRANSP, 0);
        lv_obj_set_style_border_opa(selectorCenterHit, LV_OPA_TRANSP, 0);
        lv_obj_set_style_shadow_opa(selectorCenterHit, LV_OPA_TRANSP, 0);
        lv_obj_add_event_cb(selectorCenterHit, selector_center_event, LV_EVENT_CLICKED, NULL);

        selectorHint = lv_label_create(ui_Screen3);
        lv_label_set_text(selectorHint, "TOUCH ARC  •  TAP CENTER");
        lv_obj_align(selectorHint, LV_ALIGN_CENTER, 0, 61);
        lv_obj_set_style_text_font(selectorHint, &lv_font_montserrat_12, 0);
        lv_obj_set_style_text_color(selectorHint, lv_color_hex(0xB8B8B8), 0);
        lv_obj_clear_flag(selectorHint, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE);

        selectorConfigured = true;
    }

    // Keep the name above the transparent center hit target.
    lv_obj_move_foreground(ui_TempNum);
    if (selectorHint) lv_obj_move_foreground(selectorHint);
    selector_refresh();
}

void ui_snapack_profile_selector_adjust(int direction)
{
    int t = (int)selectorTarget + (direction > 0 ? 1 : -1);
    if (t < 0) t = SNAP_COLOR_TARGET_COUNT - 1;
    if (t >= SNAP_COLOR_TARGET_COUNT) t = 0;
    selectorTarget = (snap_color_target_t)t;
    if (ui_TempArc) lv_arc_set_value(ui_TempArc, selector_center_value(selectorTarget));
    selector_refresh();
}

void ui_snapack_profile_selector_open(void)
{
    selector_open_editor();
}

void ui_snapack_color_editor_adjust(int delta)
{
    if (!ui_SnapackColorArc) return;
    int v = lv_arc_get_value(ui_SnapackColorArc) + delta;
    if (v < 0) v = 0;
    if (v > 100) v = 100;
    lv_arc_set_value(ui_SnapackColorArc, v);
    snap_color_profile_t *p = snap_color_profile(editTarget);
    if (p->ring_mode == SNAP_RING_FIXED) p->fixed_ring_pct = (uint8_t)v;
    else p->background_pct = (uint8_t)v;
    editor_apply_preview();
    ui_apply_snapack_color_profiles();
    snapack_request_profile_save();
}

void ui_snapack_color_editor_next_ring_choice(void)
{
    snap_color_profile_t *p = snap_color_profile(editTarget);
    int next = (snap_color_get_ring_choice(p) + 1) % 7;
    snap_color_set_ring_choice(p, next);
    editor_apply_preview();
    ui_apply_snapack_color_profiles();
    snapack_request_profile_save();
}

void ui_set_snapack_color_editor_ring_speed(int volume_value)
{
    if (volume_value < 0) volume_value = 0;
    if (volume_value > 100) volume_value = 100;
    uint32_t vv = (uint32_t)volume_value * (uint32_t)volume_value;
    previewSpeed_mrev = (uint16_t)(150 + (3850UL * vv) / 10000UL);
}
