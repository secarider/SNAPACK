// SNAPACK CURRENT SCREEN
//
// Deliberately simple first pass: one dominant current value.
// The current font remains the proven built-in Montserrat 48 for now;
// a purpose-built larger numeric font can be introduced later if the final
// cranking screen needs to devote most of the 480x480 face to one number.

#include "ui.h"
#include <stdio.h>

typedef enum {
    SNAP_CURRENT_THEME_NIGHT = 0,
    SNAP_CURRENT_THEME_DAY
} snap_current_theme_t;

static snap_current_theme_t snapCurrentTheme = SNAP_CURRENT_THEME_NIGHT;
static bool snapCurrentThemeLongPressConsumed = false;

static lv_obj_t * snapCurrentTitle;

#define SNAP_CURRENT_SEGMENT_COUNT 18
static lv_obj_t * snapCurrentSegments[SNAP_CURRENT_SEGMENT_COUNT];

static lv_color_t current_bg(void)
{
    return snapCurrentTheme == SNAP_CURRENT_THEME_DAY
        ? lv_color_hex(0xFFFFFF)
        : lv_color_hex(0x000000);
}

static lv_color_t current_text(void)
{
    return snapCurrentTheme == SNAP_CURRENT_THEME_DAY
        ? lv_color_hex(0x000000)
        : lv_color_hex(0xFFFFFF);
}

static lv_color_t current_value(void)
{
    return snapCurrentTheme == SNAP_CURRENT_THEME_DAY
        ? lv_color_hex(0x000000)
        : lv_color_hex(0x33DCFF);
}

static lv_color_t current_button(void)
{
    return snapCurrentTheme == SNAP_CURRENT_THEME_DAY
        ? lv_color_hex(0x000000)
        : lv_color_hex(0x33DCFF);
}

static lv_color_t current_button_text(void)
{
    return snapCurrentTheme == SNAP_CURRENT_THEME_DAY
        ? lv_color_hex(0xFFFFFF)
        : lv_color_hex(0x000000);
}

static lv_color_t current_segment_on_color(void)
{
    return snapCurrentTheme == SNAP_CURRENT_THEME_DAY
        ? lv_color_hex(0x000000)
        : lv_color_hex(0x33DCFF);
}

static lv_color_t current_segment_off_color(void)
{
    return snapCurrentTheme == SNAP_CURRENT_THEME_DAY
        ? lv_color_hex(0xD0D0D0)
        : lv_color_hex(0x303030);
}

static void applySnapCurrentTheme(snap_current_theme_t theme)
{
    snapCurrentTheme = theme;

    if (!ui_Screen7) return;

    lv_obj_set_style_bg_color(ui_Screen7, current_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);

    if (snapCurrentTitle) {
        lv_obj_set_style_text_color(snapCurrentTitle, current_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    }
    if (ui_SnapackCurrentValue) {
        lv_obj_set_style_text_color(ui_SnapackCurrentValue, current_value(), LV_PART_MAIN | LV_STATE_DEFAULT);
    }
    if (ui_SnapackCurrentUnit) {
        lv_obj_set_style_text_color(ui_SnapackCurrentUnit, current_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    }
    if (ui_SnapackCurrentReturnBt) {
        lv_obj_set_style_bg_color(ui_SnapackCurrentReturnBt, current_button(), LV_PART_MAIN | LV_STATE_DEFAULT);
    }
    if (ui_SnapackCurrentReturnLabel) {
        lv_obj_set_style_text_color(ui_SnapackCurrentReturnLabel, current_button_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    }

    for (int i = 0; i < SNAP_CURRENT_SEGMENT_COUNT; i++) {
        if (snapCurrentSegments[i]) {
            lv_obj_set_style_arc_color(
                snapCurrentSegments[i],
                (i < 11) ? current_segment_on_color() : current_segment_off_color(),
                LV_PART_MAIN | LV_STATE_DEFAULT);
        }
    }
}

bool snapack_current_consume_theme_long_press(void)
{
    if (snapCurrentThemeLongPressConsumed) {
        snapCurrentThemeLongPressConsumed = false;
        return true;
    }
    return false;
}

static void snap_current_theme_long_press_event(lv_event_t * e)
{
    if (lv_event_get_code(e) == LV_EVENT_LONG_PRESSED) {
        snapCurrentThemeLongPressConsumed = true;
        applySnapCurrentTheme(snapCurrentTheme == SNAP_CURRENT_THEME_NIGHT
                              ? SNAP_CURRENT_THEME_DAY
                              : SNAP_CURRENT_THEME_NIGHT);
    }
}

void ui_update_snapack_current(int current_A)
{
    if (!ui_SnapackCurrentValue) return;

    char text[16];
    snprintf(text, sizeof(text), "%d", current_A);
    lv_label_set_text(ui_SnapackCurrentValue, text);
}

void ui_Screen7_screen_init(void)
{
    ui_Screen7 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen7,
                      LV_OBJ_FLAG_CLICKABLE |
                      LV_OBJ_FLAG_PRESS_LOCK |
                      LV_OBJ_FLAG_SCROLLABLE |
                      LV_OBJ_FLAG_SCROLL_ELASTIC |
                      LV_OBJ_FLAG_SCROLL_MOMENTUM |
                      LV_OBJ_FLAG_SCROLL_CHAIN);
    lv_obj_set_style_bg_color(ui_Screen7, current_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen7, 255, LV_PART_MAIN | LV_STATE_DEFAULT);


    // Segmented current-status ring.
    // Eighteen short arcs form a 270-degree gauge with visible gaps.
    const int segment_span = 10;
    const int segment_gap = 5;
    const int segment_step = segment_span + segment_gap;

    for (int i = 0; i < SNAP_CURRENT_SEGMENT_COUNT; i++) {
        lv_obj_t * seg = lv_arc_create(ui_Screen7);
        snapCurrentSegments[i] = seg;

        lv_obj_set_width(seg, 430);
        lv_obj_set_height(seg, 430);
        lv_obj_set_align(seg, LV_ALIGN_CENTER);
        lv_arc_set_rotation(seg, 135 + (i * segment_step));
        lv_arc_set_bg_angles(seg, 0, segment_span);
        lv_arc_set_range(seg, 0, 100);
        lv_arc_set_value(seg, 100);

        lv_obj_remove_style(seg, NULL, LV_PART_KNOB);
        lv_obj_clear_flag(seg, LV_OBJ_FLAG_CLICKABLE);

        lv_obj_set_style_arc_opa(seg, 0, LV_PART_INDICATOR | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_width(seg, 12, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_rounded(seg, false, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_arc_color(
            seg,
            (i < 11) ? current_segment_on_color() : current_segment_off_color(),
            LV_PART_MAIN | LV_STATE_DEFAULT);
    }

    snapCurrentTitle = lv_label_create(ui_Screen7);
    lv_obj_set_width(snapCurrentTitle, LV_SIZE_CONTENT);
    lv_obj_set_height(snapCurrentTitle, LV_SIZE_CONTENT);
    lv_obj_set_x(snapCurrentTitle, 0);
    lv_obj_set_y(snapCurrentTitle, -150);
    lv_obj_set_align(snapCurrentTitle, LV_ALIGN_CENTER);
    lv_label_set_text(snapCurrentTitle, "Current");
    lv_obj_set_style_text_color(snapCurrentTitle, current_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(snapCurrentTitle, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackCurrentValue = lv_label_create(ui_Screen7);
    lv_obj_set_width(ui_SnapackCurrentValue, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_SnapackCurrentValue, LV_SIZE_CONTENT);
    lv_obj_set_x(ui_SnapackCurrentValue, -28);
    lv_obj_set_y(ui_SnapackCurrentValue, -4);
    lv_obj_set_align(ui_SnapackCurrentValue, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SnapackCurrentValue, "187");
    lv_obj_set_style_text_color(ui_SnapackCurrentValue, current_value(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_SnapackCurrentValue, &snapack_current_96, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackCurrentUnit = lv_label_create(ui_Screen7);
    lv_obj_set_width(ui_SnapackCurrentUnit, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_SnapackCurrentUnit, LV_SIZE_CONTENT);
    lv_obj_set_x(ui_SnapackCurrentUnit, 104);
    lv_obj_set_y(ui_SnapackCurrentUnit, 10);
    lv_obj_set_align(ui_SnapackCurrentUnit, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SnapackCurrentUnit, "A");
    lv_obj_set_style_text_color(ui_SnapackCurrentUnit, current_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_SnapackCurrentUnit, &lv_font_montserrat_48, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackCurrentReturnBt = lv_btn_create(ui_Screen7);
    lv_obj_set_width(ui_SnapackCurrentReturnBt, 168);
    lv_obj_set_height(ui_SnapackCurrentReturnBt, 54);
    lv_obj_set_x(ui_SnapackCurrentReturnBt, 0);
    lv_obj_set_y(ui_SnapackCurrentReturnBt, 164);
    lv_obj_set_align(ui_SnapackCurrentReturnBt, LV_ALIGN_CENTER);
    lv_obj_set_style_bg_color(ui_SnapackCurrentReturnBt, current_button(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_SnapackCurrentReturnBt, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(ui_SnapackCurrentReturnBt, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackCurrentReturnLabel = lv_label_create(ui_Screen7);
    lv_obj_set_width(ui_SnapackCurrentReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_SnapackCurrentReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_x(ui_SnapackCurrentReturnLabel, 0);
    lv_obj_set_y(ui_SnapackCurrentReturnLabel, 164);
    lv_obj_set_align(ui_SnapackCurrentReturnLabel, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SnapackCurrentReturnLabel, "Return");
    lv_obj_set_style_text_color(ui_SnapackCurrentReturnLabel, current_button_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_SnapackCurrentReturnLabel, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_add_event_cb(ui_SnapackCurrentReturnBt, ui_event_screen7ReturnBt, LV_EVENT_ALL, NULL);
    lv_obj_add_event_cb(ui_SnapackCurrentReturnBt, snap_current_theme_long_press_event, LV_EVENT_LONG_PRESSED, NULL);

    applySnapCurrentTheme(SNAP_CURRENT_THEME_NIGHT);
}
