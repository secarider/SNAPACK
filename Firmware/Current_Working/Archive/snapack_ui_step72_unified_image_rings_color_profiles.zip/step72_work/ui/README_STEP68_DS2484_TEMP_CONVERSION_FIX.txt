SNAPACK UI STEP68 — DS2484 TEMPERATURE CONVERSION FIX

- Continues directly from Step67.
- Corrects DS18B20 raw-temperature conversion to tenths of a degree Fahrenheit.
- Step67 incorrectly divided the Fahrenheit increment by 80 instead of 8,
  causing a valid ~72 F scratchpad to display as ~36 F.
- Retains the proven non-blocking 5-second DS2484 temperature cycle.
- Retains raw 9-byte scratchpad Serial output for verification.
- No CdS threshold changes in this step.
- No hardware-map, divider, OTC, 24-V, carousel, or UI timing changes.
