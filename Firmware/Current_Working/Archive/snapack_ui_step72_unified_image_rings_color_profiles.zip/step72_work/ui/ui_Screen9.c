// SNAPACK STEP72 COLOR PROFILE EDITOR
#include "ui.h"
#include "snapack_ring_frames.h"
#include "snapack_color_profiles.h"
#include <math.h>
#include <stdio.h>

static snap_color_target_t editTarget = SNAP_COLOR_TARGET_CAROUSEL;
static lv_obj_t * titleLabel = NULL;
static lv_obj_t * modeLabel = NULL;
static lv_obj_t * valueLabel = NULL;
static lv_obj_t * previewRing[SNAP_RING_TILE_COUNT] = {0};
static lv_obj_t * choiceBtn[7] = {0};
static lv_obj_t * targetDot[SNAP_COLOR_TARGET_COUNT] = {0};
static uint32_t previewPhaseMilli = 0;
static uint32_t previewSpeed_mrev = 150;
static int previewFrame = -1;

static const char * choiceText[7] = {"-40", "-20", "COMP", "+20", "+40", "RAIN", "FIX"};

static void editor_apply_preview(void)
{
    snap_color_profile_t *p = snap_color_profile(editTarget);
    lv_color_t bg = snap_color_background(p);
    lv_obj_set_style_bg_color(ui_Screen9, bg, LV_PART_MAIN | LV_STATE_DEFAULT);

    int active = snap_color_get_ring_choice(p);
    for (int i=0; i<7; ++i) {
        if (!choiceBtn[i]) continue;
        lv_obj_set_style_bg_opa(choiceBtn[i], i == active ? 90 : 25, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_border_opa(choiceBtn[i], i == active ? 220 : 80, LV_PART_MAIN | LV_STATE_DEFAULT);
    }
    for (int i=0; i<SNAP_COLOR_TARGET_COUNT; ++i) {
        if (!targetDot[i]) continue;
        lv_obj_set_style_bg_opa(targetDot[i], i == (int)editTarget ? 255 : 60, LV_PART_MAIN | LV_STATE_DEFAULT);
    }

    int v = (p->ring_mode == SNAP_RING_FIXED) ? p->fixed_ring_pct : p->background_pct;
    lv_arc_set_value(ui_SnapackColorArc, v);
    char buf[24];
    snprintf(buf, sizeof(buf), "%d%%", v);
    lv_label_set_text(valueLabel, buf);
    lv_label_set_text(modeLabel, p->ring_mode == SNAP_RING_FIXED ? "FIXED RING COLOR" : "BACKGROUND COLOR");
    lv_label_set_text(titleLabel, snap_color_target_name(editTarget));

    lv_color_t ring = snap_color_ring(p);
    for (int i=0; i<SNAP_RING_TILE_COUNT; ++i) {
        if (!previewRing[i]) continue;
        lv_obj_set_style_img_recolor(previewRing[i],
            p->ring_mode == SNAP_RING_RAINBOW ? snap_color_rainbow(i) : ring,
            LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_img_recolor_opa(previewRing[i], LV_OPA_COVER, LV_PART_MAIN | LV_STATE_DEFAULT);
    }
}

static void editor_set_target(int target)
{
    if (target < 0) target = SNAP_COLOR_TARGET_COUNT - 1;
    if (target >= SNAP_COLOR_TARGET_COUNT) target = 0;
    editTarget = (snap_color_target_t)target;
    editor_apply_preview();
}

static void editor_target_event(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    editor_set_target((int)(intptr_t)lv_event_get_user_data(e));
}

static void editor_choice_event(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    int choice = (int)(intptr_t)lv_event_get_user_data(e);
    snap_color_set_ring_choice(snap_color_profile(editTarget), choice);
    editor_apply_preview();
    ui_apply_snapack_color_profiles();
    snapack_request_profile_save();
}

static void editor_arc_event(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_VALUE_CHANGED) return;
    int value = lv_arc_get_value(ui_SnapackColorArc);
    snap_color_profile_t *p = snap_color_profile(editTarget);
    if (p->ring_mode == SNAP_RING_FIXED) p->fixed_ring_pct = (uint8_t)value;
    else p->background_pct = (uint8_t)value;
    editor_apply_preview();
    ui_apply_snapack_color_profiles();
    snapack_request_profile_save();
}

static void editor_gesture_event(lv_event_t *e)
{
    if (lv_event_get_code(e) != LV_EVENT_GESTURE) return;
    lv_dir_t dir = lv_indev_get_gesture_dir(lv_indev_get_act());
    if (dir == LV_DIR_LEFT) editor_set_target((int)editTarget + 1);
    else if (dir == LV_DIR_RIGHT) editor_set_target((int)editTarget - 1);
}

static void editor_return_event(lv_event_t *e)
{
    if (lv_event_get_code(e) == LV_EVENT_CLICKED)
        _ui_screen_change(&ui_Screen3, LV_SCR_LOAD_ANIM_FADE_ON, 180, 0, &ui_Screen3_screen_init);
}

void ui_service_snapack_color_editor(void)
{
    if (!ui_Screen9 || lv_scr_act() != ui_Screen9) return;
    static unsigned long last = 0;
    unsigned long now = millis();
    unsigned long dt = now - last;
    if (last == 0) { last = now; return; }
    if (dt < 40) return;
    last = now;
    uint64_t deltaMilliFrame = (uint64_t)dt * previewSpeed_mrev * 24ULL;
    deltaMilliFrame /= 1000ULL;
    previewPhaseMilli = (previewPhaseMilli + (uint32_t)deltaMilliFrame) % (SNAP_RING_FRAME_COUNT * 1000UL);
    int frame = (int)(previewPhaseMilli / 1000UL);
    if (frame == previewFrame) return;
    previewFrame = frame;
    snap_color_profile_t *p = snap_color_profile(editTarget);
    for (int i=0; i<SNAP_RING_TILE_COUNT; ++i) {
        if (!previewRing[i]) continue;
        lv_img_set_src(previewRing[i], snap_ring_frames[frame][i]);
        if (p->ring_mode == SNAP_RING_RAINBOW)
            lv_obj_set_style_img_recolor(previewRing[i], snap_color_rainbow(i + frame), LV_PART_MAIN | LV_STATE_DEFAULT);
    }
}

void ui_Screen9_screen_init(void)
{
    snap_color_profiles_init_defaults();
    ui_Screen9 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen9, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(ui_Screen9, LV_OBJ_FLAG_GESTURE_BUBBLE);
    lv_obj_add_event_cb(ui_Screen9, editor_gesture_event, LV_EVENT_GESTURE, NULL);

    for (int i=0; i<SNAP_RING_TILE_COUNT; ++i) {
        previewRing[i] = lv_img_create(ui_Screen9);
        lv_img_set_src(previewRing[i], snap_ring_frames[0][i]);
        lv_obj_set_pos(previewRing[i], snap_ring_tile_x[i], snap_ring_tile_y[i]);
        lv_obj_clear_flag(previewRing[i], LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE);
    }

    titleLabel = lv_label_create(ui_Screen9);
    lv_obj_align(titleLabel, LV_ALIGN_TOP_MID, 0, 38);
    lv_obj_set_style_text_font(titleLabel, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(titleLabel, lv_color_hex(0xFFFFFF), 0);

    for (int i=0; i<SNAP_COLOR_TARGET_COUNT; ++i) {
        targetDot[i] = lv_obj_create(ui_Screen9);
        lv_obj_set_size(targetDot[i], 8, 8);
        lv_obj_set_style_radius(targetDot[i], LV_RADIUS_CIRCLE, 0);
        lv_obj_set_style_border_width(targetDot[i], 0, 0);
        lv_obj_set_style_bg_color(targetDot[i], lv_color_hex(0xFFFFFF), 0);
        lv_obj_align(targetDot[i], LV_ALIGN_TOP_MID, (i - 1) * 22 - 11, 73);
        lv_obj_clear_flag(targetDot[i], LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_add_flag(targetDot[i], LV_OBJ_FLAG_CLICKABLE);
        lv_obj_set_ext_click_area(targetDot[i], 9);
        lv_obj_add_event_cb(targetDot[i], editor_target_event, LV_EVENT_CLICKED, (void*)(intptr_t)i);
    }

    ui_SnapackColorArc = lv_arc_create(ui_Screen9);
    lv_obj_set_size(ui_SnapackColorArc, 286, 286);
    lv_obj_align(ui_SnapackColorArc, LV_ALIGN_CENTER, 0, 4);
    lv_arc_set_rotation(ui_SnapackColorArc, 140);
    lv_arc_set_bg_angles(ui_SnapackColorArc, 0, 250);
    lv_arc_set_range(ui_SnapackColorArc, 0, 100);
    lv_obj_set_style_arc_width(ui_SnapackColorArc, 14, LV_PART_MAIN);
    lv_obj_set_style_arc_width(ui_SnapackColorArc, 18, LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(ui_SnapackColorArc, lv_color_hex(0x303030), LV_PART_MAIN);
    lv_obj_set_style_arc_color(ui_SnapackColorArc, lv_color_hex(0xFFFFFF), LV_PART_INDICATOR);
    lv_obj_set_style_bg_color(ui_SnapackColorArc, lv_color_hex(0xFFFFFF), LV_PART_KNOB);
    lv_obj_add_event_cb(ui_SnapackColorArc, editor_arc_event, LV_EVENT_VALUE_CHANGED, NULL);

    valueLabel = lv_label_create(ui_Screen9);
    lv_obj_align(valueLabel, LV_ALIGN_CENTER, 0, -8);
    lv_obj_set_style_text_font(valueLabel, &lv_font_montserrat_40, 0);
    lv_obj_set_style_text_color(valueLabel, lv_color_hex(0xFFFFFF), 0);

    modeLabel = lv_label_create(ui_Screen9);
    lv_obj_align(modeLabel, LV_ALIGN_CENTER, 0, 35);
    lv_obj_set_style_text_font(modeLabel, &lv_font_montserrat_16, 0);
    lv_obj_set_style_text_color(modeLabel, lv_color_hex(0xFFFFFF), 0);

    // Post-100% continuation: visually distinct thin arc plus directly tappable detents.
    lv_obj_t *tail = lv_arc_create(ui_Screen9);
    lv_obj_set_size(tail, 286, 286);
    lv_obj_align(tail, LV_ALIGN_CENTER, 0, 4);
    lv_arc_set_rotation(tail, 140);
    lv_arc_set_bg_angles(tail, 252, 340);
    lv_obj_remove_style(tail, NULL, LV_PART_KNOB);
    lv_obj_set_style_arc_width(tail, 4, LV_PART_MAIN);
    lv_obj_set_style_arc_color(tail, lv_color_hex(0xB0B0B0), LV_PART_MAIN);
    lv_obj_set_style_arc_opa(tail, 0, LV_PART_INDICATOR);
    lv_obj_clear_flag(tail, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE);

    // Seven compact touch targets; labels are intentionally short because the display is 480 px round.
    for (int i=0; i<7; ++i) {
        choiceBtn[i] = lv_btn_create(ui_Screen9);
        lv_obj_set_size(choiceBtn[i], i==2 || i>=5 ? 54 : 46, 28);
        int x = -162 + i * 54;
        lv_obj_align(choiceBtn[i], LV_ALIGN_BOTTOM_MID, x, -48);
        lv_obj_set_style_radius(choiceBtn[i], 10, 0);
        lv_obj_set_style_bg_color(choiceBtn[i], lv_color_hex(0xFFFFFF), 0);
        lv_obj_set_style_border_color(choiceBtn[i], lv_color_hex(0xFFFFFF), 0);
        lv_obj_set_style_border_width(choiceBtn[i], 1, 0);
        lv_obj_add_event_cb(choiceBtn[i], editor_choice_event, LV_EVENT_CLICKED, (void*)(intptr_t)i);
        lv_obj_t *l = lv_label_create(choiceBtn[i]);
        lv_label_set_text(l, choiceText[i]);
        lv_obj_center(l);
        lv_obj_set_style_text_font(l, &lv_font_montserrat_12, 0);
        lv_obj_set_style_text_color(l, lv_color_hex(0xFFFFFF), 0);
    }

    ui_SnapackColorReturnBt = lv_btn_create(ui_Screen9);
    lv_obj_set_size(ui_SnapackColorReturnBt, 108, 38);
    lv_obj_align(ui_SnapackColorReturnBt, LV_ALIGN_BOTTOM_MID, 0, -8);
    lv_obj_set_style_bg_opa(ui_SnapackColorReturnBt, 40, 0);
    lv_obj_add_event_cb(ui_SnapackColorReturnBt, editor_return_event, LV_EVENT_CLICKED, NULL);
    lv_obj_t *ret = lv_label_create(ui_SnapackColorReturnBt);
    lv_label_set_text(ret, "RETURN");
    lv_obj_center(ret);

    editor_apply_preview();
}

static void color_profile_entry_event(lv_event_t *e)
{
    if (lv_event_get_code(e) == LV_EVENT_CLICKED)
        _ui_screen_change(&ui_Screen9, LV_SCR_LOAD_ANIM_FADE_ON, 180, 0, &ui_Screen9_screen_init);
}

void ui_attach_snapack_color_profile_entry(void)
{
    if (!ui_Screen3) return;
    lv_obj_t *btn = lv_btn_create(ui_Screen3);
    lv_obj_set_size(btn, 176, 42);
    lv_obj_align(btn, LV_ALIGN_BOTTOM_MID, 0, -56);
    lv_obj_set_style_radius(btn, 18, 0);
    lv_obj_set_style_bg_color(btn, lv_color_hex(0x202020), 0);
    lv_obj_set_style_bg_opa(btn, 210, 0);
    lv_obj_set_style_border_color(btn, lv_color_hex(0xFFFFFF), 0);
    lv_obj_set_style_border_width(btn, 1, 0);
    lv_obj_add_event_cb(btn, color_profile_entry_event, LV_EVENT_CLICKED, NULL);
    lv_obj_t *label = lv_label_create(btn);
    lv_label_set_text(label, "COLOR PROFILES");
    lv_obj_set_style_text_font(label, &lv_font_montserrat_14, 0);
    lv_obj_center(label);
    editor_apply_preview();
}

void ui_snapack_color_editor_adjust(int delta)
{
    if (!ui_SnapackColorArc) return;
    int v = lv_arc_get_value(ui_SnapackColorArc) + delta;
    if (v < 0) v = 0;
    if (v > 100) v = 100;
    lv_arc_set_value(ui_SnapackColorArc, v);
    snap_color_profile_t *p = snap_color_profile(editTarget);
    if (p->ring_mode == SNAP_RING_FIXED) p->fixed_ring_pct = (uint8_t)v;
    else p->background_pct = (uint8_t)v;
    editor_apply_preview();
    ui_apply_snapack_color_profiles();
    snapack_request_profile_save();
}

void ui_snapack_color_editor_next_ring_choice(void)
{
    snap_color_profile_t *p = snap_color_profile(editTarget);
    int next = (snap_color_get_ring_choice(p) + 1) % 7;
    snap_color_set_ring_choice(p, next);
    editor_apply_preview();
    ui_apply_snapack_color_profiles();
    snapack_request_profile_save();
}

void ui_set_snapack_color_editor_ring_speed(int volume_value)
{
    if (volume_value < 0) volume_value = 0;
    if (volume_value > 100) volume_value = 100;
    uint32_t vv = (uint32_t)volume_value * (uint32_t)volume_value;
    previewSpeed_mrev = (uint16_t)(150 + (3850UL * vv) / 10000UL);
}
