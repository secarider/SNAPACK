SNAPACK UI STEP67 — DS2484 LIVE ONE-SENSOR TEMPERATURE

Built directly from Step66.

- Keeps the proven 3.3-V ADS/I2C rebuild map and scaling.
- Keeps the Step66 one-shot DS2484 presence/short diagnostic at startup.
- Restores live one-sensor DS18B20 acquisition through DS2484.
- Conversion wait remains non-blocking: LVGL/touch/ring service continues during conversion.
- Temperature cycle cadence increased to 5 seconds for this validation pass to keep shared-I2C traffic light.
- Prints the 9-byte scratchpad after each completed read.
- Rejects all-zero or CRC-invalid scratchpads.
- Valid Sensor 1 temperature is sent to the Temperature screen and used as the current one-sensor average.
- Other four temperature positions remain unavailable until multi-sensor ROM discovery/mapping is added.
