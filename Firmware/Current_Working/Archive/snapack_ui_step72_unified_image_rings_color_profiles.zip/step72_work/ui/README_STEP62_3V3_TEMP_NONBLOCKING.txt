SNAPACK STEP62 — 3.3-V REBUILD / NON-BLOCKING DS2484 TEMP DIAGNOSTIC

Changes from snapack_step62_3v3_rebuild_live:
- Keeps the proven 3.3-V ADS map/scaling and native 3.3-V I2C architecture.
- Disables the repeating 2-second eight-channel ADS diagnostic dump.
- Replaces the blocking ~760 ms DS18B20 conversion delay with a non-blocking
  start/wait/read state sequence so LVGL/touch/ring service can continue.
- Prints the 9 raw DS18B20 scratchpad bytes after each completed conversion.
- Rejects an all-zero scratchpad even though an all-zero CRC can appear valid.
- Keeps one-sensor SKIP-ROM operation for this diagnostic pass.

Expected useful serial lines:
  DS2484 TEMP1 scratchpad: XX XX XX XX XX XX XX XX XX
  DS2484 TEMP1 = xx.x F
or an explicit invalid/read-failure message.

Keep only the one currently attached temperature sensor for this test.
