#ifndef SNAPACK_COLOR_PROFILES_H
#define SNAPACK_COLOR_PROFILES_H
#include "lvgl.h"
#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    SNAP_COLOR_TARGET_CAROUSEL = 0,
    SNAP_COLOR_TARGET_CELL,
    SNAP_COLOR_TARGET_TEMPERATURE,
    SNAP_COLOR_TARGET_DIAGNOSTIC,
    SNAP_COLOR_TARGET_COUNT
} snap_color_target_t;

typedef enum {
    SNAP_RING_DERIVED = 0,
    SNAP_RING_RAINBOW,
    SNAP_RING_FIXED
} snap_ring_mode_t;

typedef struct {
    uint8_t background_pct;   // 0..100: blue -> red hue sweep
    int8_t ring_offset_deg;   // -40, -20, 0, +20, +40
    uint8_t fixed_ring_pct;   // 0..100 independent hue when FIXED
    snap_ring_mode_t ring_mode;
} snap_color_profile_t;

void snap_color_profiles_init_defaults(void);
snap_color_profile_t * snap_color_profile(snap_color_target_t target);
const char * snap_color_target_name(snap_color_target_t target);
lv_color_t snap_color_background(const snap_color_profile_t *p);
lv_color_t snap_color_ring(const snap_color_profile_t *p);
lv_color_t snap_color_rainbow(int slot);
void snap_color_set_ring_choice(snap_color_profile_t *p, int choice);
int snap_color_get_ring_choice(const snap_color_profile_t *p);

#ifdef __cplusplus
}
#endif
#endif
