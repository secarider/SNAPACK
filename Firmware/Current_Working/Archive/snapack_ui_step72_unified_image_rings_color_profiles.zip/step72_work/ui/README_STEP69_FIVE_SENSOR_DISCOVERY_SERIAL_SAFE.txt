SNAPACK STEP69 — FIVE-SENSOR DS2484 DISCOVERY / SERIAL-SAFE LIVE TEMPERATURE

Purpose:
- Discover up to five DS18B20 sensors through the DS2484 at startup.
- Print each unique 64-bit ROM address once for physical mapping.
- Start all discovered sensors converting simultaneously with one broadcast command.
- Wait 800 ms non-blockingly, then MATCH ROM and read each sensor individually.
- Update Temperature Sensor 1-5 and AVG using valid readings only.
- Initial group polling cadence: 1 second for responsiveness/UI-load testing.
- Recurring temperature service produces no Serial output.

Important Step68 lesson retained:
Continuous diagnostic Serial output can back-pressure when no host reader is draining USB serial and can stall the UI/control loop. Step69 therefore limits temperature serial output to startup discovery only.

Physical mapping:
After five sensors are discovered, warm one probe at a time and note which Sensor 1-5 display value rises. The startup ROM list gives the corresponding ROM for each temporary discovery slot. Permanent physical names/locations should be assigned only after that test.
