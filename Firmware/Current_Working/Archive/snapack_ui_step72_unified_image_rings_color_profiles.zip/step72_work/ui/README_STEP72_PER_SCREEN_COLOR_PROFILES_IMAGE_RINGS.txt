SNAPACK UI STEP72 — UNIFIED IMAGE RINGS + PER-SCREEN COLOR PROFILES
==================================================================

BASELINE
--------
Step72 is built directly from the physically tested Step71 package.
Step71's Cell Voltage image-mask/frame ring was retained as the proven model.

WHAT STEP72 CHANGES
-------------------
1. Unified image-mask perimeter ring engine
   - Main Carousel: old LVGL multi-arc decorative ring replaced by the 12-tile / 6-frame ALPHA_8BIT ring.
   - Cell Voltage: keeps the Step71 image ring.
   - Temperature: old 36-arc ring replaced by the image ring.
   - Diagnostic: old 36-arc rainbow ring replaced by the image ring.
   - Current remains deliberately outside this decorative system.

2. Global electrical-event workload rule remains authoritative
   - Carousel / Cell / Temperature / Diagnostic / Color Editor decorative ring service all remain inside
     the existing "not in current event" workload gate.
   - Current's essential hot-temperature blink remains outside that decorative gate.

3. New per-screen color profiles
   Independent profiles now exist for:
      MAIN CAROUSEL
      CELL VOLTAGE
      TEMPERATURE
      DIAGNOSTIC

   Each profile contains:
      background percentage/hue
      ring relationship offset
      ring mode
      independent fixed-ring hue

4. Ring relationship choices
      -40 degrees
      -20 degrees
      COMP (normal complement)
      +20 degrees
      +40 degrees
      RAIN (rainbow)
      FIX (fixed independent ring hue)

   Rainbow is no longer Diagnostic-only. It can be assigned to any profile.

5. FIX behavior
   - Selecting FIX freezes the existing background choice.
   - The same 0-100 circular color control then edits only the ring hue.
   - The first time FIX is selected, its ring hue is initialized from the currently visible derived ring
     relationship rather than jumping to an arbitrary unrelated color.
   - Leaving FIX and returning later retains its fixed ring hue in RAM.

6. Touch-first Color Profile editor (Screen9)
   - The OEM Temperature screen remains intact.
   - A COLOR PROFILES touch button is added to it as the doorway into the new editor.
   - The editor is intentionally visually separate from operational screens.
   - Swipe left/right changes target screen.
   - Target dots can also be tapped directly.
   - The main color arc remains directly tappable/drag-adjustable.
   - Ring relationship/mode choices are directly tappable; the user never has to drag through 100% first.
   - A thin post-100% continuation arc visually separates the ring-choice region from the normal percentage arc.

7. Rotary operation retained
   - Turning the encoder on Screen9 changes the active 0-100 color value by 5.
   - A physical single click while on Screen9 cycles to the next ring relationship/mode.
   - Touch remains completely independent; rotary use is not required.
   - Existing universal physical-knob double-click escape remains unchanged.

8. Live preview
   - The editor uses the same real 12-tile image ring assets as the operational screens.
   - Profile background and ring changes are applied live while editing.
   - In FIX mode the central label changes to FIXED RING COLOR.
   - In all other modes it reads BACKGROUND COLOR.

9. Day/night behavior
   - Stored color profiles control the normal/night appearance.
   - Existing DAY mode remains a grayscale override.
   - Switching into DAY does not erase the stored color profile.

10. Master animation speed
   - The Color Profile preview ring now follows the same Volume-controlled animation-speed function as
     Carousel, Cell Voltage, Temperature, and Diagnostic.

FILES ADDED
-----------
ui/snapack_color_profiles.h
ui/snapack_color_profiles.c
ui/snapack_color_apply.c
ui/ui_Screen9.c

FILES MODIFIED
--------------
snapack.ino
ui/ui.c
ui/ui.h
ui/ui_Screen1.c
ui/ui_Screen5.c
ui/ui_Screen6.c
ui/ui_Screen8.c

FIRST PHYSICAL TEST ORDER
-------------------------
1. Confirm normal boot and main Carousel rendering.
2. Confirm Carousel ring is now the image-mask ring and still responds to swipe direction/speed.
3. Open Cell Voltage, Temperature, and Diagnostic and verify the image ring on each.
4. Confirm Diagnostic starts in RAIN mode.
5. Enter OEM Temp, tap COLOR PROFILES.
6. On MAIN CAROUSEL, tap several points on the 0-100 arc and confirm live background changes.
7. Tap COMP, -20, +20, -40, +40 and confirm background does not move while ring hue relationship changes.
8. Tap RAIN and confirm rainbow ring without changing the chosen background.
9. Tap FIX; confirm no arbitrary initial color jump. Then tap the main arc and confirm only ring hue changes.
10. Swipe between the four profile targets; confirm each remembers its own choices independently.
11. Return to the real operational screens and verify that their profile choices match the editor preview.
12. Change Volume and verify all decorative image rings, including editor preview, follow master speed.
13. Exercise a current event and confirm decorative ring servicing is globally shed exactly as in Step71.

PROFILE PERSISTENCE
-------------------
The four profile structures are persisted in the existing snapack-ui Preferences namespace.
A color drag does NOT write flash continuously. Changes only mark profile data dirty; the save occurs after
700 ms of inactivity. The persistence service is inside the existing non-current-event workload gate, so a
pending cosmetic-settings write waits rather than competing with an electrically significant event.
