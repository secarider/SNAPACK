#ifndef SNAPACK_RING_FRAMES_H
#define SNAPACK_RING_FRAMES_H
#include "lvgl.h"
#ifdef __cplusplus
extern "C" {
#endif
#define SNAP_RING_FRAME_COUNT 6
#define SNAP_RING_TILE_COUNT 12
extern const lv_img_dsc_t * const snap_ring_frames[SNAP_RING_FRAME_COUNT][SNAP_RING_TILE_COUNT];
extern const int16_t snap_ring_tile_x[SNAP_RING_TILE_COUNT];
extern const int16_t snap_ring_tile_y[SNAP_RING_TILE_COUNT];
#ifdef __cplusplus
}
#endif
#endif
