SNAPACK STEP66 — DS2484 ONE-SHOT PRESENCE + 24-V DIAGNOSTIC

Changes from Step65:
- Keeps recurring DS2484 temperature traffic disabled.
- Runs one DS2484 / 1-Wire reset diagnostic at startup only.
- Prints DS2484 status, 1-Wire presence-pulse result, and short-detect result.
- Keeps the UI free of the Step64 two-second DS2484 traffic/freeze cycle.
- Reads ADS #2 A3 with the normal cell refresh and feeds the converted
  100k/10k value to the Diagnostic 24-V rail field.
- 24-V read failure does NOT invalidate otherwise-good cell readings.
- All proven 3.3-V rebuild mappings/scaling remain unchanged.

Expected useful serial lines:
  DS2484 0x18: I2C PRESENT
  DS2484 status after 1-Wire reset: 0xXX
  1-Wire presence pulse: YES/NO
  1-Wire short detected: YES/NO

Hardware for this test:
- Leave the single temperature sensor connected exactly as in Step65.
- No wiring changes are requested.
