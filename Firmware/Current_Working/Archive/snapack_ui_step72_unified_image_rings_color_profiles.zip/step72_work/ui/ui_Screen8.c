// SNAPACK DIAGNOSTIC SCREEN
#include "ui.h"
#include "snapack_ring_frames.h"
#include "snapack_color_profiles.h"

static bool snapDiagDay = false;
static bool snapDiagThemeLongPressConsumed = false;
static lv_obj_t * snapDiagTitle = NULL;
static lv_obj_t * snapDiagRingImg[SNAP_RING_TILE_COUNT] = {0};
static uint32_t snapDiagSpeed_mrev = 150;
static uint32_t snapDiagPhaseMilli = 0;
static int snapDiagImageFrame = -1;
static snap_ring_mode_t snapDiagRingMode = SNAP_RING_RAINBOW;
static lv_color_t snapDiagRingColor;
static lv_color_t snapDiagProfileBg;
static bool snapDiagProfileValid = false;

static lv_obj_t * snapDiagNameRail = NULL;
static lv_obj_t * snapDiagNameLastPeak = NULL;
static lv_obj_t * snapDiagNameSessionPeak = NULL;
static lv_obj_t * snapDiagNamePack = NULL;
static lv_obj_t * snapDiagName4SPack = NULL;
static lv_obj_t * snapDiagNameLowCell = NULL;

static lv_obj_t * snapDiagValueRail = NULL;
static lv_obj_t * snapDiagValueLastPeak = NULL;
static lv_obj_t * snapDiagValueSessionPeak = NULL;
static lv_obj_t * snapDiagValuePack = NULL;
static lv_obj_t * snapDiagValue4SPack = NULL;
static lv_obj_t * snapDiagValueLowCell = NULL;

static lv_color_t diag_bg(void)   { return snapDiagDay ? lv_color_hex(0xFFFFFF) : (snapDiagProfileValid ? snapDiagProfileBg : lv_color_hex(0x000000)); }
static lv_color_t diag_text(void) { return snapDiagDay ? lv_color_hex(0x000000) : lv_color_hex(0xFFFFFF); }
static lv_color_t diag_accent(void){ return snapDiagDay ? lv_color_hex(0x000000) : (snapDiagProfileValid ? snapDiagRingColor : lv_color_hex(0x33DCFF)); }

static void diag_apply_text_color(void)
{
    lv_obj_t * all[] = {
        snapDiagNameRail, snapDiagNameLastPeak, snapDiagNameSessionPeak,
        snapDiagNamePack, snapDiagName4SPack, snapDiagNameLowCell,
        snapDiagValueRail, snapDiagValueLastPeak, snapDiagValueSessionPeak,
        snapDiagValuePack, snapDiagValue4SPack, snapDiagValueLowCell
    };

    for (unsigned i = 0; i < sizeof(all)/sizeof(all[0]); i++) {
        if (all[i]) lv_obj_set_style_text_color(all[i], diag_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    }
}

static void diag_recolor_ring(void)
{
    for (int i=0; i<SNAP_RING_TILE_COUNT; ++i) {
        if (!snapDiagRingImg[i]) continue;
        lv_color_t c = snapDiagDay ? lv_color_hex(0x000000)
            : (snapDiagRingMode == SNAP_RING_RAINBOW ? snap_color_rainbow(i + (snapDiagImageFrame < 0 ? 0 : snapDiagImageFrame)) : snapDiagRingColor);
        lv_obj_set_style_img_recolor(snapDiagRingImg[i], c, LV_PART_MAIN | LV_STATE_DEFAULT);
        lv_obj_set_style_img_recolor_opa(snapDiagRingImg[i], LV_OPA_COVER, LV_PART_MAIN | LV_STATE_DEFAULT);
    }
}

void ui_set_snapack_diag_profile(lv_color_t bg, lv_color_t ring, int ring_mode)
{
    snapDiagProfileBg = bg;
    snapDiagRingColor = ring;
    snapDiagRingMode = (snap_ring_mode_t)ring_mode;
    snapDiagProfileValid = true;
    if (ui_Screen8 && !snapDiagDay) lv_obj_set_style_bg_color(ui_Screen8, bg, LV_PART_MAIN | LV_STATE_DEFAULT);
    diag_recolor_ring();
    if (ui_Screen8) ui_set_snapack_diag_theme(snapDiagDay);
}

void ui_set_snapack_diag_ring_speed(int volume_value)
{
    if (volume_value < 0) volume_value = 0;
    if (volume_value > 100) volume_value = 100;
    uint32_t vv = (uint32_t)volume_value * (uint32_t)volume_value;
    snapDiagSpeed_mrev = (uint16_t)(150 + (3850UL * vv) / 10000UL);
}

void ui_service_snapack_diag_animation(void)
{
    if (!ui_Screen8 || lv_scr_act() != ui_Screen8) return;
    static unsigned long lastFrameMs = 0;
    unsigned long now = millis();
    if (lastFrameMs == 0) lastFrameMs = now;
    unsigned long dt = now - lastFrameMs;
    if (dt < 16) return;
    lastFrameMs = now;
    uint64_t deltaMilliFrame = (uint64_t)dt * snapDiagSpeed_mrev * 24ULL;
    deltaMilliFrame /= 1000ULL;
    snapDiagPhaseMilli = (snapDiagPhaseMilli + (uint32_t)deltaMilliFrame) % (SNAP_RING_FRAME_COUNT * 1000UL);
    int frame = (int)(snapDiagPhaseMilli / 1000UL);
    if (frame != snapDiagImageFrame) {
        snapDiagImageFrame = frame;
        for (int i=0; i<SNAP_RING_TILE_COUNT; ++i)
            if (snapDiagRingImg[i]) lv_img_set_src(snapDiagRingImg[i], snap_ring_frames[frame][i]);
        diag_recolor_ring();
    }
}

bool snapack_diag_consume_theme_long_press(void)
{
    if (snapDiagThemeLongPressConsumed) {
        snapDiagThemeLongPressConsumed = false;
        return true;
    }
    return false;
}

static void snap_diag_theme_long_press_event(lv_event_t * e)
{
    if (lv_event_get_code(e) == LV_EVENT_LONG_PRESSED) {
        snapDiagThemeLongPressConsumed = true;
        ui_set_snapack_diag_theme(!snapDiagDay);
    }
}

void ui_set_snapack_diag_theme(bool day_mode)
{
    snapDiagDay = day_mode;
    if (!ui_Screen8) return;

    lv_obj_set_style_bg_color(ui_Screen8, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
    if (snapDiagTitle)
        lv_obj_set_style_text_color(snapDiagTitle, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);

    diag_apply_text_color();

    diag_recolor_ring();

    if (ui_SnapackDiagReturnBt)
        lv_obj_set_style_bg_color(ui_SnapackDiagReturnBt, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);
    if (ui_SnapackDiagReturnLabel)
        lv_obj_set_style_text_color(ui_SnapackDiagReturnLabel, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
}

void ui_update_snapack_diagnostics(int rail_mV, int last_peak_A, int session_peak_A,
                                   int pack_mV, int pack4s_mV, int low_cell_mV)
{
    char b[32];

    if (snapDiagValueRail) {
        snprintf(b, sizeof(b), "%d.%02d V", rail_mV / 1000, abs((rail_mV % 1000) / 10));
        lv_label_set_text(snapDiagValueRail, b);
    }

    if (snapDiagValueLastPeak) {
        snprintf(b, sizeof(b), "%d A", last_peak_A);
        lv_label_set_text(snapDiagValueLastPeak, b);
    }

    if (snapDiagValueSessionPeak) {
        snprintf(b, sizeof(b), "%d A", session_peak_A);
        lv_label_set_text(snapDiagValueSessionPeak, b);
    }

    if (snapDiagValuePack) {
        snprintf(b, sizeof(b), "%d.%03d V", pack_mV / 1000, abs(pack_mV % 1000));
        lv_label_set_text(snapDiagValuePack, b);
    }

    if (snapDiagValue4SPack) {
        snprintf(b, sizeof(b), "%d.%03d V", pack4s_mV / 1000, abs(pack4s_mV % 1000));
        lv_label_set_text(snapDiagValue4SPack, b);
    }

    if (snapDiagValueLowCell) {
        snprintf(b, sizeof(b), "%d.%03d V", low_cell_mV / 1000, abs(low_cell_mV % 1000));
        lv_label_set_text(snapDiagValueLowCell, b);
    }
}

static void diag_make_row(lv_obj_t **name_obj,
                          lv_obj_t **value_obj,
                          const char *name_text,
                          const char *value_text,
                          int y)
{
    // Fixed 380 px row container. Labels and values are independent children,
    // so changing digit width cannot recenter or shove the other column.
    lv_obj_t * row = lv_obj_create(ui_Screen8);
    lv_obj_set_width(row, 350);
    lv_obj_set_height(row, 44);
    lv_obj_set_align(row, LV_ALIGN_CENTER);
    lv_obj_set_y(row, y);
    lv_obj_set_style_bg_opa(row, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_border_opa(row, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_pad_all(row, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_clear_flag(row, LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_CLICKABLE);

    *name_obj = lv_label_create(row);
    lv_obj_set_width(*name_obj, 175);
    lv_obj_set_height(*name_obj, LV_SIZE_CONTENT);
    lv_obj_align(*name_obj, LV_ALIGN_LEFT_MID, 8, 0);
    lv_label_set_text(*name_obj, name_text);
    lv_obj_set_style_text_align(*name_obj, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(*name_obj, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(*name_obj, diag_text(), LV_PART_MAIN | LV_STATE_DEFAULT);

    *value_obj = lv_label_create(row);
    lv_obj_set_width(*value_obj, 155);
    lv_obj_set_height(*value_obj, LV_SIZE_CONTENT);
    lv_obj_align(*value_obj, LV_ALIGN_RIGHT_MID, -8, 0);
    lv_label_set_text(*value_obj, value_text);
    lv_obj_set_style_text_align(*value_obj, LV_TEXT_ALIGN_RIGHT, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(*value_obj, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(*value_obj, diag_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
}

void ui_Screen8_screen_init(void)
{
    ui_Screen8 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen8, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(ui_Screen8, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen8, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // STEP72: Diagnostic now uses the same lightweight image-mask ring engine.
    for (int i=0; i<SNAP_RING_TILE_COUNT; ++i) {
        snapDiagRingImg[i] = lv_img_create(ui_Screen8);
        lv_img_set_src(snapDiagRingImg[i], snap_ring_frames[0][i]);
        lv_obj_set_pos(snapDiagRingImg[i], snap_ring_tile_x[i], snap_ring_tile_y[i]);
        lv_obj_clear_flag(snapDiagRingImg[i], LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE);
    }
    snapDiagImageFrame = 0;
    diag_recolor_ring();

    snapDiagTitle = lv_label_create(ui_Screen8);
    lv_label_set_text(snapDiagTitle, "DIAGNOSTIC");
    lv_obj_set_align(snapDiagTitle, LV_ALIGN_CENTER);
    lv_obj_set_y(snapDiagTitle, -150);
    lv_obj_set_style_text_font(snapDiagTitle, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(snapDiagTitle, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);

    const int ys[] = {-102, -68, -34, 0, 34, 68};

    diag_make_row(&snapDiagNameRail,        &snapDiagValueRail,
                  "24V RAIL",    "0.00 V",  ys[0]);
    diag_make_row(&snapDiagNameLastPeak,    &snapDiagValueLastPeak,
                  "LAST PEAK",   "0 A",     ys[1]);
    diag_make_row(&snapDiagNameSessionPeak, &snapDiagValueSessionPeak,
                  "SESSION MAX", "0 A",     ys[2]);
    diag_make_row(&snapDiagNamePack,        &snapDiagValuePack,
                  "FULL PACK",   "0.000 V", ys[3]);
    diag_make_row(&snapDiagName4SPack,      &snapDiagValue4SPack,
                  "4S PACK",     "0.000 V", ys[4]);
    diag_make_row(&snapDiagNameLowCell,     &snapDiagValueLowCell,
                  "LOWEST CELL", "0.000 V", ys[5]);

    ui_SnapackDiagReturnBt = lv_btn_create(ui_Screen8);
    lv_obj_set_width(ui_SnapackDiagReturnBt, 168);
    lv_obj_set_height(ui_SnapackDiagReturnBt, 54);
    lv_obj_set_align(ui_SnapackDiagReturnBt, LV_ALIGN_CENTER);
    lv_obj_set_y(ui_SnapackDiagReturnBt, 164);
    lv_obj_set_style_bg_color(ui_SnapackDiagReturnBt, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(ui_SnapackDiagReturnBt, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_ext_click_area(ui_SnapackDiagReturnBt, 36);

    ui_SnapackDiagReturnLabel = lv_label_create(ui_Screen8);
    lv_label_set_text(ui_SnapackDiagReturnLabel, "Return");
    lv_obj_set_align(ui_SnapackDiagReturnLabel, LV_ALIGN_CENTER);
    lv_obj_set_y(ui_SnapackDiagReturnLabel, 164);
    lv_obj_set_style_text_font(ui_SnapackDiagReturnLabel, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui_SnapackDiagReturnLabel, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_add_event_cb(ui_SnapackDiagReturnBt, ui_event_screen8ReturnBt, LV_EVENT_ALL, NULL);
    lv_obj_add_event_cb(ui_SnapackDiagReturnBt, snap_diag_theme_long_press_event, LV_EVENT_LONG_PRESSED, NULL);
}
