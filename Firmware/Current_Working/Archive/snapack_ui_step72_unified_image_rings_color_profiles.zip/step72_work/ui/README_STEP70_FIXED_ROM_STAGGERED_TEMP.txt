SNAPACK UI STEP70 — FIXED-ROM / STAGGERED FIVE-SENSOR TEMPERATURE

Purpose
-------
Step69 proved all five DS18B20 probes and established their permanent ROM
identities, but 1-second five-sensor polling produced visible UI hitches.
Step70 changes normal-operation scheduling without inventing final thermal
protection thresholds.

Changes
-------
* Locks physical Sensor 1-5 to the ROM addresses established in Step69.
  Connector order and 1-Wire search order can no longer renumber probes.
* Normal temperature group cadence is relaxed to 5 seconds.
* All five sensors still begin conversion simultaneously with one broadcast
  CONVERT T command.
* The 800 ms sensor conversion period remains non-blocking.
* After conversion, only one sensor scratchpad is read per eligible main-loop
  pass, with a small 25 ms yield gap between probes.  The old five-sensor
  back-to-back read burst is removed.
* Recurring temperature service remains Serial-silent to preserve the Step68
  USB-serial-backpressure lesson.
* No high-current threshold is chosen in this revision.

Future thermal-watch architecture
---------------------------------
Normal operation can remain relatively slow and UI-friendly.  During a true
high-current event, firmware may intentionally enter a faster thermal-watch
cadence and decorative ring smoothness may be sacrificed in favor of current,
temperature, rate-of-rise and contactor-authority processing.  Final current,
temperature, rate-of-rise and cooldown thresholds remain to be established by
installed-system testing.
