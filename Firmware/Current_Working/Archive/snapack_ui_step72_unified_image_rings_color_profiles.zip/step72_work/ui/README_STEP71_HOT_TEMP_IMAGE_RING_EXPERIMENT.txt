SNAPACK STEP71 — HOTTEST TEMPERATURE + IMAGE-RING EXPERIMENT

Purpose
-------
Step71 deliberately contains two testable additions and one priority rule.
It keeps Step70's proven fixed-ROM / staggered five-sensor acquisition intact.

1. CURRENT-SCREEN HOTTEST SENSOR
--------------------------------
The Current screen now shows the hottest valid temperature probe as:

    HOT  3   78.4° F

Sensor number is 1..5 and follows the fixed Step70 ROM identities.
No additional 1-Wire polling is performed.  The indicator is updated only
from the completed normal five-sensor temperature cycle.

Temporary bench UI thresholds:
    80.0 F  = elevated
    85.0 F  = warning

These are intentionally easy-to-reach TEST/UI values only.  They are NOT
thermal-protection or contactor-authorization thresholds.

Night theme:
    normal   = cyan
    elevated = yellow
    warning  = red

Day theme:
    remains monochrome
    warning state blinks the HOT/sensor/value/underline group

2. EXPERIMENTAL IMAGE-FRAME VOLTAGE RING
----------------------------------------
ONLY the Cell Voltage screen ring is replaced in this experiment.
Temperature and Diagnostic retain their Step70 36-arc rings and therefore
remain useful A/B comparison screens.

The Step71 voltage ring uses:
    - 6 pre-rendered animation phases
    - 12 small image tiles per phase
    - LVGL ALPHA_8BIT masks (opacity only; no RGB pixels stored)
    - 16-pixel ring thickness as a deliberate worst-case first test
    - runtime LVGL image recolor for theme/accent color

The six phases span the 90-degree repeat period of four equally spaced moving
highlight trains.  Runtime image recolor receives the same complementary
accent derived from the OEM Temperature color control.  Day mode recolors the
same masks black, so opacity produces the monochrome black/gray ring.

The OEM Volume control still drives ring speed.  The existing speed mapping is
left broad intentionally so it can act as a live performance stress control.

Primary A/B test:
    OEM screens                  = quiet control
    Current screen               = custom screen, no decorative ring
    Cell Voltage                 = NEW image-mask ring
    Temperature / Diagnostic     = OLD multi-arc animated rings

Test rotary double-click escape at several Volume settings.  If Cell Voltage
now behaves like Current/OEM while Temperature/Diagnostic remain difficult,
that strongly supports the image-mask approach.

3. ELECTRICAL-EVENT PRIORITY RULE
---------------------------------
Decorative ring service is globally suspended while a current event is active.
It remains suspended for a provisional 3-second cooldown after event end.
This is keyed from the electrical-event state, NOT from which screen is open.

The 3-second value is only a Step71 bench/proof value.  Future authoritative
thermal/current protection timing remains a separate design decision.

The HOT indicator/blink is considered useful operational information, not
perimeter decoration, so its lightweight service remains available.

Files added for ring experiment
-------------------------------
    snapack_ring_frames.c
    snapack_ring_frames.h

Step70 remains the known-good baseline and should remain archived unchanged.
