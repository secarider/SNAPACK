SNAPACK STEP 62 — UNIVERSAL PHYSICAL DOUBLE-CLICK ESCAPE

Built from Step61.

Observed on hardware:
- Current screen escaped correctly by physical double-click.
- SNAPACK Cell Voltage, SNAPACK Temperature and Diagnostic did not.

Fix:
The old escape routine maintained an explicit list of screen pointers.
Step62 removes that per-screen allow-list.

New rule:
- If current screen IS Carousel: physical single push selects as before.
- If current screen is ANYTHING OTHER THAN Carousel:
  physical double-click returns to Carousel.

This covers present and future sub-screens automatically, including the
planned Machine State screen, without needing to remember to add each one
to an escape list.

All Step61 four-train animation, speed curve, swipe behavior, themes,
sticky settings and rotary debounce behavior are unchanged.
