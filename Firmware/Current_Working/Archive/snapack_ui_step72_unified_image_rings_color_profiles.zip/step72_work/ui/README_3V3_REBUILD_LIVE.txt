SNAPACK STEP62 BASE — 3.3-V REBUILD LIVE HARDWARE TEST

This package preserves the Step62 UI base and updates the live hardware map
for the rebuilt native-3.3-V sensor board.

ADS1115 VDD: 3.3 V
I2C: native 3.3 V; no level shifter
ADS PGA: +/-4.096 V (0.125 mV/count). PGA is ADC input-range/gain, not VDD.

ADS #1 0x48:
 A0 B1 47k/18k
 A1 B2 47k/18k
 A2 B3 47k/18k
 A3 B4 100k/10k

ADS #2 0x49:
 A0 B5 100k/10k
 A1 CdS node
 A2 OTC node, 10k/22k divider
 A3 24-V rail, 100k/10k

OTC:
 Restores the 10k/22k attenuation in software (x16/11 on signal delta).
 Automatic zero capture remains enabled. With no current, expected ADS node is
 approximately 2.49 V if the OTC source is near 3.620 V.

Temperature:
 DS2484 at 0x18 is enabled directly over I2C without adding a library.
 This bring-up intentionally supports ONE attached DS18B20 using SKIP ROM.
 It updates Temperature sensor 1 and AVG. Multi-sensor ROM discovery/mapping
 comes after the one-sensor DS2484 path is proven.

Bring-up Serial:
 A compact live ADS snapshot prints every 2 seconds, including B1-B5, CdS,
 OTC node, 24-V rail, and OTC zero/current state. Cell rejection now prints
 the calculated cumulative taps and individual cells so a wiring/scaling
 problem is visible immediately.
