SNAPACK UI STEP73 — CIRCULAR PROFILE SELECTOR + DEDICATED COLOR EDITOR
=====================================================================

BASELINE
--------
Step73 is built directly from Step72 unified image rings + per-screen color profiles.
All Step72 profile data, ring modes, persistence, and electrically-important workload shedding remain intact.

WHY STEP73 EXISTS
-----------------
Initial physical testing of Step72 showed that horizontal target-swiping at the top of the Color Profile editor
was too close to the large circular color arc.  Target navigation and color editing could compete for the same
touch gesture.  The old OEM Temperature screen also became an unnecessary intermediate global-color page.

STEP73 FLOW
-----------
Main Carousel OEM-Temperature/Color entry
        -> repurposed circular COLOR PROFILES selector (Screen3)
        -> dedicated editor for the selected target (Screen9)
        -> RETURN goes back to the circular selector with the same target still selected
        -> existing Screen3 RETURN goes back to the Main Carousel

CIRCULAR PROFILE SELECTOR — SCREEN3
-----------------------------------
The OEM Temperature screen's existing 0-200 arc is retained in place so its familiar geometry, tapping,
and finger-drag behavior survive.

Its old temperature/global-color authority is retired.
The 0-200 travel is now divided into four 50-unit selection zones:
    0-49    MAIN CAROUSEL
    50-99   CELL VOLTAGE
    100-149 TEMPERATURE
    150-200 DIAGNOSTIC

The numerical temperature display is replaced by the selected target name.
Crossing a threshold changes the name discretely while the finger can still move continuously around the arc.
Each target has a fixed identifying selector color.

Touch behavior:
- tap anywhere on the OEM arc to jump directly to that target zone;
- drag around the arc to move through targets;
- tap the large center name area to enter the selected target's editor.

Rotary behavior:
- rotate while on Screen3 to step directly target-to-target;
- single click while on Screen3 opens the selected editor;
- universal double-click escape remains unchanged.

The old COLOR PROFILES overlay button is removed, so it no longer competes with Screen3's RETURN button.

DEDICATED COLOR EDITOR — SCREEN9
--------------------------------
Screen9 now edits exactly one selected target at a time.
The Step72 target dots and left/right target-swipe gesture are removed completely.
This leaves the large circular 0-100 color control free from target-navigation gesture conflicts.

The editor retains all Step72 profile functions:
    -40
    -20
    COMP
    +20
    +40
    RAIN
    FIX

FIX behavior remains unchanged:
- background stays at its chosen hue;
- the same 0-100 arc edits the independent fixed ring hue;
- first FIX selection initializes from the currently visible derived ring color;
- the fixed ring hue remains stored independently.

The Step72 gray post-100% continuation arc is removed.  Ring-mode choices are explicit touch targets and no
longer need a visual continuation of the color arc.

RETURN from Screen9 returns to Screen3 rather than the Main Carousel, and restores the same target selection.

RETIRED OEM TEMP/GLOBAL COLOR BEHAVIOR
--------------------------------------
The application no longer binds tempArcEventCb() to ui_TempArc.
The selector arc therefore cannot overwrite per-screen profiles by changing the old global temperature color.
The old saved "temp" preference is left readable for backward compatibility but is no longer written from
snapack_save_ui_settings().

UNCHANGED FROM STEP72
---------------------
- Main Carousel / Cell Voltage / Temperature / Diagnostic use the unified 12-tile image-mask ring engine.
- Current remains outside decorative perimeter animation.
- Rainbow is available to every profile.
- Derived offsets and independent fixed ring hue remain supported.
- Profile changes use deferred NVS persistence.
- Decorative work remains suspended during electrically significant current events.
- DAY mode remains a grayscale override without destroying stored profiles.
- Master Volume still controls decorative ring animation speed.

FIRST PHYSICAL TEST
-------------------
1. From the Main Carousel, enter the OEM Temperature/Color destination.
2. Confirm there is no COLOR PROFILES button over the RETURN button.
3. Confirm the center now names MAIN CAROUSEL / CELL VOLTAGE / TEMPERATURE / DIAGNOSTIC instead of temperature.
4. Tap four widely separated points around the OEM arc and confirm the target changes immediately.
5. Drag continuously around the arc and confirm target names change only at the four thresholds.
6. Tap the center name and confirm Screen9 opens for that exact target.
7. Confirm Screen9 has no target dots and does not change targets on left/right swipe.
8. Exercise the large color arc and all seven ring choices.
9. Press RETURN in Screen9 and confirm it returns to the selector with the same target selected.
10. Use Screen3 RETURN and confirm it returns to the Main Carousel.
11. Repeat using the rotary: rotate target-to-target, click to enter, double-click escape as before.
