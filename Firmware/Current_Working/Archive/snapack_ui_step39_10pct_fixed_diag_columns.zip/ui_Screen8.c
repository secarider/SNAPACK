// SNAPACK DIAGNOSTIC SCREEN
#include "ui.h"

static bool snapDiagDay = false;
static lv_obj_t * snapDiagTitle = NULL;

static lv_obj_t * snapDiagNameRail = NULL;
static lv_obj_t * snapDiagNameLastPeak = NULL;
static lv_obj_t * snapDiagNameSessionPeak = NULL;
static lv_obj_t * snapDiagNamePack = NULL;
static lv_obj_t * snapDiagNameLowCell = NULL;

static lv_obj_t * snapDiagValueRail = NULL;
static lv_obj_t * snapDiagValueLastPeak = NULL;
static lv_obj_t * snapDiagValueSessionPeak = NULL;
static lv_obj_t * snapDiagValuePack = NULL;
static lv_obj_t * snapDiagValueLowCell = NULL;

static lv_color_t diag_bg(void)   { return snapDiagDay ? lv_color_hex(0xFFFFFF) : lv_color_hex(0x000000); }
static lv_color_t diag_text(void) { return snapDiagDay ? lv_color_hex(0x000000) : lv_color_hex(0xFFFFFF); }
static lv_color_t diag_accent(void){ return snapDiagDay ? lv_color_hex(0x000000) : lv_color_hex(0x33DCFF); }

static void diag_apply_text_color(void)
{
    lv_obj_t * all[] = {
        snapDiagNameRail, snapDiagNameLastPeak, snapDiagNameSessionPeak,
        snapDiagNamePack, snapDiagNameLowCell,
        snapDiagValueRail, snapDiagValueLastPeak, snapDiagValueSessionPeak,
        snapDiagValuePack, snapDiagValueLowCell
    };

    for (unsigned i = 0; i < sizeof(all)/sizeof(all[0]); i++) {
        if (all[i]) lv_obj_set_style_text_color(all[i], diag_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    }
}

void ui_set_snapack_diag_theme(bool day_mode)
{
    snapDiagDay = day_mode;
    if (!ui_Screen8) return;

    lv_obj_set_style_bg_color(ui_Screen8, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
    if (snapDiagTitle)
        lv_obj_set_style_text_color(snapDiagTitle, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);

    diag_apply_text_color();

    if (ui_SnapackDiagReturnBt)
        lv_obj_set_style_bg_color(ui_SnapackDiagReturnBt, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);
    if (ui_SnapackDiagReturnLabel)
        lv_obj_set_style_text_color(ui_SnapackDiagReturnLabel, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
}

void ui_update_snapack_diagnostics(int rail_mV, int last_peak_A, int session_peak_A,
                                   int pack_mV, int low_cell_mV)
{
    char b[32];

    if (snapDiagValueRail) {
        snprintf(b, sizeof(b), "%d.%02d V", rail_mV / 1000, abs((rail_mV % 1000) / 10));
        lv_label_set_text(snapDiagValueRail, b);
    }

    if (snapDiagValueLastPeak) {
        snprintf(b, sizeof(b), "%d A", last_peak_A);
        lv_label_set_text(snapDiagValueLastPeak, b);
    }

    if (snapDiagValueSessionPeak) {
        snprintf(b, sizeof(b), "%d A", session_peak_A);
        lv_label_set_text(snapDiagValueSessionPeak, b);
    }

    if (snapDiagValuePack) {
        snprintf(b, sizeof(b), "%d.%03d V", pack_mV / 1000, abs(pack_mV % 1000));
        lv_label_set_text(snapDiagValuePack, b);
    }

    if (snapDiagValueLowCell) {
        snprintf(b, sizeof(b), "%d.%03d V", low_cell_mV / 1000, abs(low_cell_mV % 1000));
        lv_label_set_text(snapDiagValueLowCell, b);
    }
}

static void diag_make_name(lv_obj_t **obj, const char *text, int y)
{
    *obj = lv_label_create(ui_Screen8);
    lv_obj_set_width(*obj, 150);
    lv_obj_set_height(*obj, LV_SIZE_CONTENT);
    lv_obj_set_x(*obj, -94);
    lv_obj_set_y(*obj, y);
    lv_obj_set_align(*obj, LV_ALIGN_CENTER);
    lv_label_set_text(*obj, text);
    lv_obj_set_style_text_align(*obj, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(*obj, &lv_font_montserrat_18, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(*obj, diag_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    // 256 = 100%; 282 ~= 110%.
    lv_obj_set_style_transform_zoom(*obj, 282, LV_PART_MAIN | LV_STATE_DEFAULT);
}

static void diag_make_value(lv_obj_t **obj, const char *text, int y)
{
    *obj = lv_label_create(ui_Screen8);
    lv_obj_set_width(*obj, 150);
    lv_obj_set_height(*obj, LV_SIZE_CONTENT);
    lv_obj_set_x(*obj, 94);
    lv_obj_set_y(*obj, y);
    lv_obj_set_align(*obj, LV_ALIGN_CENTER);
    lv_label_set_text(*obj, text);
    lv_obj_set_style_text_align(*obj, LV_TEXT_ALIGN_RIGHT, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(*obj, &lv_font_montserrat_18, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(*obj, diag_text(), LV_PART_MAIN | LV_STATE_DEFAULT);
    // Keep values independent of their labels so changing digit width cannot
    // shove the labels left/right.
    lv_obj_set_style_transform_zoom(*obj, 282, LV_PART_MAIN | LV_STATE_DEFAULT);
}

void ui_Screen8_screen_init(void)
{
    ui_Screen8 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen8, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(ui_Screen8, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen8, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    snapDiagTitle = lv_label_create(ui_Screen8);
    lv_label_set_text(snapDiagTitle, "DIAGNOSTIC");
    lv_obj_set_align(snapDiagTitle, LV_ALIGN_CENTER);
    lv_obj_set_y(snapDiagTitle, -150);
    lv_obj_set_style_text_font(snapDiagTitle, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(snapDiagTitle, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);

    const int ys[] = {-92, -52, -12, 28, 68};

    diag_make_name(&snapDiagNameRail,        "24V RAIL",     ys[0]);
    diag_make_name(&snapDiagNameLastPeak,    "LAST PEAK",    ys[1]);
    diag_make_name(&snapDiagNameSessionPeak, "SESSION MAX",  ys[2]);
    diag_make_name(&snapDiagNamePack,        "PACK",         ys[3]);
    diag_make_name(&snapDiagNameLowCell,     "LOWEST CELL",  ys[4]);

    diag_make_value(&snapDiagValueRail,        "0.00 V",  ys[0]);
    diag_make_value(&snapDiagValueLastPeak,    "0 A",     ys[1]);
    diag_make_value(&snapDiagValueSessionPeak, "0 A",     ys[2]);
    diag_make_value(&snapDiagValuePack,        "0.000 V", ys[3]);
    diag_make_value(&snapDiagValueLowCell,     "0.000 V", ys[4]);

    ui_SnapackDiagReturnBt = lv_btn_create(ui_Screen8);
    lv_obj_set_width(ui_SnapackDiagReturnBt, 168);
    lv_obj_set_height(ui_SnapackDiagReturnBt, 54);
    lv_obj_set_align(ui_SnapackDiagReturnBt, LV_ALIGN_CENTER);
    lv_obj_set_y(ui_SnapackDiagReturnBt, 164);
    lv_obj_set_style_bg_color(ui_SnapackDiagReturnBt, diag_accent(), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(ui_SnapackDiagReturnBt, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_ext_click_area(ui_SnapackDiagReturnBt, 36);

    ui_SnapackDiagReturnLabel = lv_label_create(ui_Screen8);
    lv_label_set_text(ui_SnapackDiagReturnLabel, "Return");
    lv_obj_set_align(ui_SnapackDiagReturnLabel, LV_ALIGN_CENTER);
    lv_obj_set_y(ui_SnapackDiagReturnLabel, 164);
    lv_obj_set_style_text_font(ui_SnapackDiagReturnLabel, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui_SnapackDiagReturnLabel, diag_bg(), LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_add_event_cb(ui_SnapackDiagReturnBt, ui_event_screen8ReturnBt, LV_EVENT_ALL, NULL);
}
