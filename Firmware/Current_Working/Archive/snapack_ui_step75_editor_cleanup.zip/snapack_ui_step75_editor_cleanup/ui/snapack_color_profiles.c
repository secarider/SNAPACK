#include "snapack_color_profiles.h"

static snap_color_profile_t profiles[SNAP_COLOR_TARGET_COUNT];
static bool initialized = false;

static uint16_t pct_to_hue(int pct)
{
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;
    // Preserve the familiar cold-to-hot direction: blue/cyan at 0%, red at 100%.
    return (uint16_t)(220 - (220 * pct) / 100);
}

static uint8_t hue_to_pct(int hue)
{
    while (hue < 0) hue += 360;
    while (hue >= 360) hue -= 360;
    // Use the nearest point on the editor's blue->red sweep.
    if (hue > 220) hue = 220;
    return (uint8_t)(((220 - hue) * 100) / 220);
}

void snap_color_profiles_init_defaults(void)
{
    if (initialized) return;
    initialized = true;
    for (int i=0; i<SNAP_COLOR_TARGET_COUNT; ++i) {
        profiles[i].background_pct = 0; // familiar dark blue starting point
        profiles[i].ring_offset_deg = 0;
        profiles[i].fixed_ring_pct = 50;
        profiles[i].ring_mode = SNAP_RING_DERIVED;
    }
    // Keep Diagnostic's established identity as a default, but no longer special-case it forever.
    profiles[SNAP_COLOR_TARGET_DIAGNOSTIC].ring_mode = SNAP_RING_RAINBOW;
}

snap_color_profile_t * snap_color_profile(snap_color_target_t target)
{
    snap_color_profiles_init_defaults();
    if (target < 0 || target >= SNAP_COLOR_TARGET_COUNT) target = SNAP_COLOR_TARGET_CAROUSEL;
    return &profiles[target];
}

const char * snap_color_target_name(snap_color_target_t target)
{
    static const char * names[SNAP_COLOR_TARGET_COUNT] = {
        "MAIN CAROUSEL", "CELL VOLTAGE", "TEMPERATURE", "DIAGNOSTIC", "CURRENT"
    };
    if (target < 0 || target >= SNAP_COLOR_TARGET_COUNT) return "MAIN CAROUSEL";
    return names[target];
}

lv_color_t snap_color_background(const snap_color_profile_t *p)
{
    // Saturated but deliberately dark enough for white informational text.
    return lv_color_hsv_to_rgb(pct_to_hue(p ? p->background_pct : 0), 92, 48);
}

lv_color_t snap_color_ring(const snap_color_profile_t *p)
{
    if (!p) return lv_color_hex(0x33DCFF);
    int hue;
    if (p->ring_mode == SNAP_RING_FIXED) {
        hue = pct_to_hue(p->fixed_ring_pct);
    } else {
        hue = (int)pct_to_hue(p->background_pct) + 180 + p->ring_offset_deg;
        while (hue < 0) hue += 360;
        while (hue >= 360) hue -= 360;
    }
    return lv_color_hsv_to_rgb((uint16_t)hue, 88, 100);
}

lv_color_t snap_color_rainbow(int slot)
{
    slot %= 12;
    if (slot < 0) slot += 12;
    return lv_color_hsv_to_rgb((uint16_t)(slot * 30), 90, 100);
}

void snap_color_set_ring_choice(snap_color_profile_t *p, int choice)
{
    if (!p) return;
    static const int offsets[5] = {-40, -20, 0, 20, 40};
    if (choice >= 0 && choice <= 4) {
        p->ring_offset_deg = (int8_t)offsets[choice];
        p->ring_mode = SNAP_RING_DERIVED;
        return;
    }
    if (choice == 5) {
        p->ring_mode = SNAP_RING_RAINBOW;
        return;
    }
    if (choice == 6) {
        if (p->ring_mode != SNAP_RING_FIXED) {
            // First FIXED selection starts visually at the current derived ring hue.
            int hue = (int)pct_to_hue(p->background_pct) + 180 + p->ring_offset_deg;
            while (hue < 0) hue += 360;
            while (hue >= 360) hue -= 360;
            p->fixed_ring_pct = hue_to_pct(hue);
        }
        p->ring_mode = SNAP_RING_FIXED;
    }
}

int snap_color_get_ring_choice(const snap_color_profile_t *p)
{
    if (!p) return 2;
    if (p->ring_mode == SNAP_RING_RAINBOW) return 5;
    if (p->ring_mode == SNAP_RING_FIXED) return 6;
    if (p->ring_offset_deg <= -30) return 0;
    if (p->ring_offset_deg < 0) return 1;
    if (p->ring_offset_deg == 0) return 2;
    if (p->ring_offset_deg < 30) return 3;
    return 4;
}
