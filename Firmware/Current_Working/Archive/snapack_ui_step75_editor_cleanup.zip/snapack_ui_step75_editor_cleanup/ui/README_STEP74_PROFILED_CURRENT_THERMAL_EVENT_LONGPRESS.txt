SNAPACK UI STEP74 — PROFILED CURRENT / THERMAL EVENT / 3-SECOND RETURN
=====================================================================

BASELINE
--------
Step73 circular profile selector + dedicated editor.

WHAT STEP74 CHANGES
-------------------
1. Color Profile selector now has five equal targets:
   MAIN CAROUSEL / CELL VOLTAGE / TEMPERATURE / DIAGNOSTIC / CURRENT.
   The preserved OEM 0..200 circular travel uses centers near 20/60/100/140/180.

2. Touch selector label overwrite guard:
   selector name is refreshed immediately and asynchronously after arc value changes.
   This prevents stale OEM temperature callbacks from replacing the selected target
   name after finger movement.

3. Editor ring-choice controls:
   -40 / -20 / COMP / +20 / +40 / RAIN / FIX remain one row.
   Touch targets are now 60x42 with 16-point labels and the row is lifted upward.

4. Current is now a normal customizable screen:
   normal Current uses its own background/profile accent and image-frame perimeter
   animation. Rainbow/derived/fixed profile modes are supported like other screens.
   The functional current gauge remains in front of the decorative ring.

5. Authoritative Current presentation:
   high-current OR thermal-event state forces Current, hides decorative Current ring,
   and restores the established black / white / cyan high-contrast presentation.
   User navigation away from Current is inhibited until the event clears.

6. HOT sensor presentation:
   HOT + sensor number + temperature uses Montserrat 28 (was 20), with a larger
   underline and permanent local black contrast panel. Semantic yellow/red/cyan
   therefore remains legible regardless of the normal Current profile.

7. Thermal event logic uses the existing completed five-sensor frame only.
   No extra 1-Wire transactions are added.

   PROVISIONAL UI/EVENT thresholds (not final battery protection cutoffs):
     absolute enter: 130.0 F
     absolute clear: 120.0 F
     differential enter: hottest-coolest >= 35.0 F for 30 seconds
     differential clear: spread <= 25.0 F AND absolute clear for 30 seconds

   At least three valid sensors are required for differential entry.  This deliberately
   makes differential warning conservative enough to ignore ordinary small asymmetry.

8. Temperature cadence:
   normal = 5 s cycle cadence.
   authoritative event = 1.5 s cycle start cadence (DS18B20 conversion remains
   nonblocking/staggered).  Current/touch/LVGL remain cooperative owners.

9. Physical rotary-switch navigation:
   double-click is no longer the primary escape gesture.
   continuous press >= 3.0 seconds executes exactly ONE parent Return immediately.
   holding for 5, 10, or 30 seconds produces no further returns.
   physical release rearms the gesture.

   Parent mapping:
     Color editor -> Color Profile selector
     selector -> main carousel
     normal operational/settings screen -> its existing carousel parent

   A forced authoritative Current screen ignores this return until event clear.

IMPORTANT
---------
The existing 12 A high-current start threshold is preserved as the current bench-test
threshold in this revision. Step74 does NOT declare that value to be the final field
threshold.

FIRST PHYSICAL CHECKS
---------------------
A. Finger-drag the five-target selector. Center name should remain a target name;
   no Celsius/Fahrenheit text should reappear.
B. Confirm all five targets can be reached by finger and rotary.
C. Enter Current profile and confirm background/ring choices affect manually selected
   Current during normal low-current operation.
D. Confirm enlarged ring-choice buttons are easy to tap.
E. Hold physical knob >3 s: exactly one parent return occurs; keep holding and verify
   no second navigation happens. Release and hold again to move one more parent.
F. Inspect enlarged HOT area and black local contrast panel.
G. Bench high-current event: Current should be forced, decorative ring hidden, fixed
   high-contrast event palette restored, Return/3-second escape inhibited.
H. Thermal thresholds are intentionally provisional; evaluate with controlled test
   temperatures before treating them as field decisions.
