#include "ui.h"
#include "snapack_color_profiles.h"

void ui_apply_snapack_color_profiles(void)
{
    snap_color_profile_t *p;

    p = snap_color_profile(SNAP_COLOR_TARGET_CAROUSEL);
    ui_set_snapack_carousel_profile(snap_color_background(p), snap_color_ring(p), (int)p->ring_mode);

    p = snap_color_profile(SNAP_COLOR_TARGET_CELL);
    ui_set_snapack_cell_profile(snap_color_background(p), snap_color_ring(p), (int)p->ring_mode);

    p = snap_color_profile(SNAP_COLOR_TARGET_TEMPERATURE);
    ui_set_snapack_temperature_profile(snap_color_background(p), snap_color_ring(p), (int)p->ring_mode);

    p = snap_color_profile(SNAP_COLOR_TARGET_DIAGNOSTIC);
    ui_set_snapack_diag_profile(snap_color_background(p), snap_color_ring(p), (int)p->ring_mode);

    p = snap_color_profile(SNAP_COLOR_TARGET_CURRENT);
    ui_set_snapack_current_profile(snap_color_background(p), snap_color_ring(p), (int)p->ring_mode);
}
