SNAPACK UI STEP75 — EDITOR GEOMETRY + SELECTOR LABEL CLEANUP

BASELINE
--------
Step74 profiled Current / thermal authoritative event / 3-second parent Return.
Step75 intentionally leaves those proven behaviors unchanged.

CHANGES
-------
1. Color-profile ring-mode presets remain seven direct touch buttons; they are NOT a
   swipe carousel:
      -40  -20  COMP  +20  +40  RAIN  FIX

2. All seven preset buttons are kept inside the visible chord of the 480x480 round
   panel.  Step74 placed the outer choices too close to the square-canvas corners,
   causing -40/FIX to be partly or completely clipped on the physical round display.

3. Preset touch targets are slightly larger and text is increased to Montserrat 18.
   Spacing is tightened and the row is lifted modestly so every choice is directly
   reachable by finger.

4. RETURN is moved out of the bottom rim and into the clear middle-lower area above
   the preset row.  It is also enlarged slightly.

5. The repurposed OEM profile-selector heading COLOR PROFILES receives an opaque
   backing plate.  This masks the retired OEM TEMPERATURE heading/halo that remained
   faintly visible behind the new title on the physical panel.

UNCHANGED / DELIBERATELY DEFERRED
--------------------------------
- New image-frame perimeter ring engine and artwork dimensions.
- Partial-transparency ring appearance.
- Direction response and activity/swipe animation behavior.
- Five profile targets including Current.
- Fixed / rainbow / complementary-offset profile logic.
- Current high-contrast authoritative event presentation.
- HOT 3 presentation and thermal/current event logic.
- 3-second one-shot physical long-press parent Return.
- Return-button long-hold day/night theme behavior.
- Lazy/deferred screen creation.  That is reserved for Step76 so boot-priority
  restructuring is isolated from this cosmetic cleanup.
- Apparent long-press duration tuning and boot-time measurement.

PHYSICAL TEST
-------------
1. Open Color Profiles and confirm the old TEMPERATURE title no longer ghosts through
   the COLOR PROFILES heading.
2. Enter any profile editor.
3. Confirm all seven choices (-40 through FIX) are fully visible and directly tappable.
4. Confirm none of the seven choices needs horizontal swiping.
5. Confirm RETURN is clearly visible above the preset row and returns one parent level.
6. Verify COMP, +/- offsets, RAIN, and FIX still change the ring exactly as in Step74.
7. Reconfirm touch color-arc adjustment, rotary color adjustment, ring animation,
   3-second physical long-press Return, and Return-button day/night hold.

NEXT
----
Step76: boot-priority / lazy screen creation.  Authoritative measurement/control and
minimum operational UI first; Current/event presentation guaranteed immediately;
noncritical/settings/decorative screens created incrementally only while electrically
quiet, with deferred creation paused during high-current/thermal events.
