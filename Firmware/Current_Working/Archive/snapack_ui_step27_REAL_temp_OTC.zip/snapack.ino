#include <OneWire.h>
#include <DallasTemperature.h>
#include <lvgl.h>
#include <demos/lv_demos.h>
#include <Arduino_GFX_Library.h>
#include "WiFiMulti.h"
#include <WiFi.h>
#include <WiFiUdp.h>

#include <Adafruit_SSD1306.h>
#include <Adafruit_GFX.h>

// #include <CSE_CST328.h>
#include <Adafruit_CST8XX.h>
#include "ui.h"
#include "PCF8574.h" 

#define I2C_SDA_PIN 38
#define I2C_SCL_PIN 39
PCF8574 pcf8574(0x21);

String wifiId = "elecrow888";            //WiFi SSID to coonnect to
String wifiPwd = "elecrow2014";  //PASSWORD of the WiFi SSID to coonnect to

#define ENCODER_A_PIN 42     // Blue: counterclockwise, rises first
#define ENCODER_B_PIN 4      // Yellow: clockwise, rises first   B   A

volatile uint8_t lastA = 0;   
volatile uint8_t currentSW = 0; 

bool pressedFlag = false;      
volatile int pressCount = 0;  

const unsigned long debounceTime = 50;    
const unsigned long doubleClickTime = 300;  

volatile unsigned long singleClickTimeout = 0; 
volatile int8_t position_tmp = 2;      

#define SCREEN_BACKLIGHT_PIN 6
const int pwmFreq = 5000;
const int pwmChannel = 0;
const int pwmResolution = 8;

TaskHandle_t encTaskHandle = NULL;
TaskHandle_t swTaskHandle = NULL;

#define I2C_TOUCH_ADDR 0x15  // often but not always 0x15!
Adafruit_CST8XX tsPanel = Adafruit_CST8XX();
enum Events lastevent = NONE;

static const uint16_t screenWidth = 480;
static const uint16_t screenHeight = 480;

static lv_disp_draw_buf_t draw_buf;
static lv_color_t *buf1 = NULL;
static lv_color_t *buf2 = NULL;
static uint16_t *buf3 = NULL;
static uint16_t *buf4 = NULL;

lv_obj_t *current_screen = NULL;
// Carousel index:
//   0 = SNAPACK Cell Voltage
//   1 = SNAPACK Temperature
//   2 = SNAPACK Current
//   3 = OEM Volume
//   4 = OEM Temp
//   5 = OEM Light
//
// Start on SNAPACK after the Elecrow splash.
int screen1_index = 0;

Arduino_ESP32RGBPanel *bus = new Arduino_ESP32RGBPanel(
  16 /* CS */, 2 /* SCK */, 1 /* SDA */,
  40 /* DE */, 7 /* VSYNC */, 15 /* HSYNC */, 41 /* PCLK */,
  46 /* R0 */, 3 /* R1 */, 8 /* R2 */, 18 /* R3 */, 17 /* R4 */,
  14 /* G0/P22 */, 13 /* G1/P23 */, 12 /* G2/P24 */, 11 /* G3/P25 */, 10 /* G4/P26 */, 9 /* G5 */,
  5 /* B0 */, 45 /* B1 */, 48 /* B2 */, 47 /* B3 */, 21 /* B4 */
);

Arduino_ST7701_RGBPanel *gfx = new Arduino_ST7701_RGBPanel(
  bus, GFX_NOT_DEFINED /* RST */, 0 /* rotation */,
  false /* IPS */, 480 /* width */, 480 /* height */,
  st7701_type5_init_operations, sizeof(st7701_type5_init_operations),
  true /* BGR */,
  10 /* hsync_front_porch(10) */, 4 /* hsync_pulse_width(8) */, 20 /* hsync_back_porch(50) */,
  10 /* vsync_front_porch(10) */, 4 /* vsync_pulse_width(8) */, 20 /* vsync_back_porch(20) */);

/* Display flushing */
void my_disp_flush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p) {
  uint32_t w = (area->x2 - area->x1 + 1);
  uint32_t h = (area->y2 - area->y1 + 1);
#if (LV_COLOR_16_SWAP != 0)
  gfx->draw16bitBeRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#else
  gfx->draw16bitRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#endif
  lv_disp_flush_ready(disp);
}

/*Read CST826 the touchpad*/
const int SWIPE_THRESHOLD = 100;  
const int TIME_THRESHOLD = 300;   
const int VERTICAL_LIMIT = 100;    
int startX = 0;
int startY = 0;
unsigned long startTime = 0;
bool trackingSwipe = false;
bool first_click = false;
void my_touchpad_read(lv_indev_drv_t *indev_driver, lv_indev_data_t *data) {
  if (tsPanel.touched()) {
    CST_TS_Point p = tsPanel.getPoint(0);
    data->point.x = p.x;
    data->point.y = p.y - 20;
    data->state = LV_INDEV_STATE_PR;

    lv_obj_t *current_screen = lv_scr_act();

    // SNAPACK CAROUSEL SWIPE HANDLING
    // Touch and rotary now share updateScreen() as one source of truth.
    // The original code duplicated the complete three-item layout inside
    // both swipe directions; that duplication is removed here before the
    // carousel grows to four items.
    if (current_screen == ui_Screen1) {
      if (first_click == false) {
        startX = p.x;
        startY = p.y;
        startTime = millis();
        trackingSwipe = true;
        first_click = true;
      }

      if (trackingSwipe && p.event == TOUCHING) {
        int deltaX = p.x - startX;
        int deltaY = abs(p.y - startY);
        unsigned long elapsed = millis() - startTime;

        if (elapsed < TIME_THRESHOLD && deltaY < VERTICAL_LIMIT) {
          if (deltaX > SWIPE_THRESHOLD) {
            first_click = false;
            trackingSwipe = false;
            if (screen1_index < 5) screen1_index++;
            updateScreen(screen1_index);
          }
          else if (deltaX < -SWIPE_THRESHOLD) {
            first_click = false;
            trackingSwipe = false;
            if (screen1_index > 0) screen1_index--;
            updateScreen(screen1_index);
          }
        }
      }
    }

    if (p.event != lastevent || p.event == TOUCHING) {
      Serial.printf("Touch ID #%d (%d, %d) Event: %s\n",
                    p.id, p.x, p.y, events_name[p.event]);
      lastevent = p.event;
    }
  }
  else {
    data->state = LV_INDEV_STATE_REL;
    first_click = false;
  }
}

// WiFi connection function
void connectWiFi() {
  Serial.println("Connecting to WiFi...");
  WiFi.begin(wifiId.c_str(), wifiPwd.c_str());
  
  // Wait for connection, up to 10 seconds
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi Connected!");
    Serial.print("SSID: ");
    Serial.println(WiFi.SSID());
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nFailed to connect to WiFi");
  }
}


void initBacklight() {
  ledcSetup(pwmChannel, pwmFreq, pwmResolution);
  ledcAttachPin(SCREEN_BACKLIGHT_PIN, pwmChannel);
  ledcWrite(pwmChannel, 204);
}

// Onboard rotary-display LED (pin 43) used for breathing effect
#define BREATH_LED_PIN 43
// Breathing-LED PWM channel (avoid conflict with backlight channel)
const int breathPwmChannel = 1;

// UDP communication variables
WiFiUDP udp;
const char* ADVANCE_IP = "192.168.50.160";  // Advance device IP address; modify as required
const int ADVANCE_PORT = 8888;             // Advance device UDP port
 
// Remote LED strip (Advance side) configuration (declared here for setup initialization)
const int REMOTE_NUM_LEDS = 15;      // Number of LEDs in the strip on Advance
int lastLedCountSent = -1;           // Record the last LED count sent to Advance

// Forward declarations: LVGL slider event callbacks
void volumeArcEventCb(lv_event_t *e);
// void volumeIconEventCb(lv_event_t *e);

void tempArcEventCb(lv_event_t *e);
// Set brightness directly through PWM only; no animation

// Initial UI values (applied when entering the screen)
int volumeValue = 50;  // 0-100
int tempValue = 0;     // 0-200
int lightValue = 50;   // 0-100

// ---------------------------------------------------------------------
// SNAPACK SIMULATED CELL DATA
// ---------------------------------------------------------------------
//
// These deliberately different values prove that five independent cell
// readings can travel from the application layer into Screen5.
//
// Values are stored as integer millivolts.
// The pack total is calculated here, not in the UI.
//
// When real ADS1115 acquisition is added, this small development function
// can be replaced while ui_update_snapack_cells() and the Screen5 layout
// remain unchanged.
void loadSnapackSimulatedCellData() {
  const int cell1_mV = 4180;
  const int cell2_mV = 4160;
  const int cell3_mV = 4170;
  const int cell4_mV = 4170;
  const int cell5_mV = 4180;

  // SNAPACK is a five-cell monitored pack in this display path.
  // Pack voltage is therefore the sum of these five individual cells.
  const int pack_mV =
      cell1_mV +
      cell2_mV +
      cell3_mV +
      cell4_mV +
      cell5_mV;

  ui_update_snapack_cells(cell1_mV,
                          cell2_mV,
                          cell3_mV,
                          cell4_mV,
                          cell5_mV,
                          pack_mV);
}


// ---------------------------------------------------------------------
// SNAPACK REAL CELL-VOLTAGE ACQUISITION — FIRST HARDWARE DATA PATH
// ---------------------------------------------------------------------
//
// hardware_manifest_revised.txt mapping:
//
//   ADS1115 Board 1 — 0x48
//     A0 = B2 cumulative tap
//     A1 = B3 cumulative tap
//     A2 = B4 cumulative tap
//     A3 = B5 cumulative tap / pack positive
//
//   ADS1115 Board 2 — 0x49
//     A0 = B1 cumulative tap
//
//   B0 = system ground.
//
// Individual cells are differences between cumulative taps:
//
//   Cell 1 = B1
//   Cell 2 = B2 - B1
//   Cell 3 = B3 - B2
//   Cell 4 = B4 - B3
//   Cell 5 = B5 - B4
//   PACK   = B5
//
// Divider on each cumulative input:
//   47k upper / 18k lower
//
// ADS1115 range used here:
//   +/-6.144 V, 0.1875 mV/count
//
// Combined exact scale:
//   tap_mV = raw_counts * 65 / 96
//
// This first step intentionally uses Wire directly so no new Arduino
// library is introduced.
//
// DEVELOPMENT BOUNDARY:
// The single-shot config below leaves the ADS comparator disabled.
// Board-1 ALERT / lockout behavior is NOT implemented by this step.

static const uint8_t SNAPACK_ADS_BOARD1_ADDR = 0x48;
static const uint8_t SNAPACK_ADS_BOARD2_ADDR = 0x49;
static const uint8_t SNAPACK_ADS_BOARD3_ADDR = 0x4A;

static const bool SNAPACK_REAL_CELLS_ENABLED = true;
static const unsigned long SNAPACK_CELL_REFRESH_MS = 250;

static unsigned long snapackLastCellReadMs = 0;
static unsigned long snapackLastCellErrorPrintMs = 0;

static bool snapack_i2c_device_present(uint8_t address)
{
  Wire.beginTransmission(address);
  return Wire.endTransmission() == 0;
}

static bool snapack_ads_write_register(uint8_t address,
                                       uint8_t reg,
                                       uint16_t value)
{
  Wire.beginTransmission(address);
  Wire.write(reg);
  Wire.write((uint8_t)(value >> 8));
  Wire.write((uint8_t)(value & 0xFF));
  return Wire.endTransmission() == 0;
}

static bool snapack_ads_read_register(uint8_t address,
                                      uint8_t reg,
                                      uint16_t *value)
{
  if (!value) return false;

  Wire.beginTransmission(address);
  Wire.write(reg);

  if (Wire.endTransmission(false) != 0) {
    return false;
  }

  if (Wire.requestFrom((int)address, 2) != 2) {
    return false;
  }

  *value = ((uint16_t)Wire.read() << 8) | Wire.read();
  return true;
}

static bool snapack_ads_read_single_ended(uint8_t address,
                                          uint8_t channel,
                                          int16_t *raw)
{
  if (!raw || channel > 3) return false;

  // CONFIG:
  // OS=1, single-ended A0..A3, PGA +/-6.144 V,
  // single-shot, 860 SPS, comparator disabled.
  const uint16_t mux = (uint16_t)(0x04 + channel) << 12;
  const uint16_t config =
      0x8000 |
      mux |
      0x0100 |
      0x00E0 |
      0x0003;

  if (!snapack_ads_write_register(address, 0x01, config)) {
    return false;
  }

  const unsigned long started = millis();

  while (millis() - started < 10) {
    uint16_t status = 0;

    if (!snapack_ads_read_register(address, 0x01, &status)) {
      return false;
    }

    if (status & 0x8000) {
      uint16_t conversion = 0;

      if (!snapack_ads_read_register(address, 0x00, &conversion)) {
        return false;
      }

      *raw = (int16_t)conversion;
      return true;
    }

    delay(1);
  }

  return false;
}

// STEP 26: discard the first completed conversion after selecting a channel.
static bool snapack_ads_read_single_ended_settled(uint8_t address,
                                                  uint8_t channel,
                                                  int16_t *raw)
{
  int16_t throwaway = 0;
  if (!snapack_ads_read_single_ended(address, channel, &throwaway)) return false;
  return snapack_ads_read_single_ended(address, channel, raw);
}


static int snapack_ads_divided_tap_mV(int16_t raw)
{
  // +/-6.144 V ADS1115 LSB = 3/16 mV.
  // Divider correction = 65/18.
  // Combined = 65/96 mV per count.
  return (int)(((int32_t)raw * 65L + 48L) / 96L);
}

static bool snapack_read_real_cells_once()
{
  int16_t rawB5=0, rawB4=0, rawB3=0, rawB2=0, rawB1=0;

  // TEMPORARY DEVELOPMENT-STAND MAP, established from live measurements:
  // Board1 / 0x48: A0=B5, A1=B4, A2=B3, A3=B2
  // Board3 / 0x4A: A2=remaining low cumulative tap B1
  // Dead Board2 / 0x49 is deliberately ignored.
  const bool okB5 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD1_ADDR, 0, &rawB5);
  const bool okB4 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD1_ADDR, 1, &rawB4);
  const bool okB3 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD1_ADDR, 2, &rawB3);
  const bool okB2 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD1_ADDR, 3, &rawB2);
  const bool okB1 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD3_ADDR, 2, &rawB1);

  if (!(okB1 && okB2 && okB3 && okB4 && okB5)) return false;

  const int b1_mV = snapack_ads_divided_tap_mV(rawB1);
  const int b2_mV = snapack_ads_divided_tap_mV(rawB2);
  const int b3_mV = snapack_ads_divided_tap_mV(rawB3);
  const int b4_mV = snapack_ads_divided_tap_mV(rawB4);
  const int b5_mV = snapack_ads_divided_tap_mV(rawB5);

  const int cell1_mV = b1_mV;
  const int cell2_mV = b2_mV - b1_mV;
  const int cell3_mV = b3_mV - b2_mV;
  const int cell4_mV = b4_mV - b3_mV;
  const int cell5_mV = b5_mV - b4_mV;

  const bool monotonic =
      b1_mV >= 0 && b2_mV >= b1_mV && b3_mV >= b2_mV &&
      b4_mV >= b3_mV && b5_mV >= b4_mV;

  const bool cellsPlausible =
      cell1_mV >= 1500 && cell1_mV <= 4500 &&
      cell2_mV >= 1500 && cell2_mV <= 4500 &&
      cell3_mV >= 1500 && cell3_mV <= 4500 &&
      cell4_mV >= 1500 && cell4_mV <= 4500 &&
      cell5_mV >= 1500 && cell5_mV <= 4500;

  if (!monotonic || !cellsPlausible) return false;

  ui_update_snapack_cells(cell1_mV, cell2_mV, cell3_mV,
                          cell4_mV, cell5_mV, b5_mV);
  return true;
}

static void snapack_service_real_cells()
{
  if (!SNAPACK_REAL_CELLS_ENABLED) return;

  const unsigned long now = millis();

  if (now - snapackLastCellReadMs < SNAPACK_CELL_REFRESH_MS) {
    return;
  }

  snapackLastCellReadMs = now;

  if (!snapack_read_real_cells_once()) {
    if (now - snapackLastCellErrorPrintMs >= 2000) {
      snapackLastCellErrorPrintMs = now;
      Serial.println(
          "SNAPACK real-cell read not accepted; "
          "keeping last valid Cell Voltage display");
    }
  }
}


// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// SNAPACK ADS1115 RAW DIAGNOSTICS
// ---------------------------------------------------------------------
//
// Independent diagnostic pass.  A dead/miswired cell channel does NOT stop
// Board 2 or Board 3 from being read.
//
// Current authoritative map:
//
// Board 1 — 0x48
//   A0..A3 = four cumulative taps for the 4-cell / 12 V group
//   Exact post-shuffle A-channel order is intentionally NOT assumed here.
//   Serial prints A0..A3 neutrally so the actual voltage staircase can reveal
//   the present wiring order.
//
// Board 2 — 0x49
//   A0 = B5
//   A1 = Final Output +
//   A2 = OTC Current analog node
//   A3 = Final Output -
//
// Board 3 — 0x4A
//   A0 = 24 V rail monitor
//   A1 = CdS / ambient light
//   A2 = spare
//   A3 = spare
//
// Expected CdS observation from the actual hardware:
//   shade  ~0.5 V
//   light  >2.0 V

static const unsigned long SNAPACK_ADS_DIAG_MS = 2000;
static unsigned long snapackLastAdsDiagMs = 0;

static const unsigned long SNAPACK_I2C_SCAN_MS = 10000;
static unsigned long snapackLastI2cScanMs = 0;

// STEP 27 OTC development calibration.
// First 8 valid zero-current samples establish a temporary baseline.
// Provisional sensitivity under test: 1 mV per amp.
static const uint8_t SNAPACK_OTC_ZERO_SAMPLES = 8;
static int32_t snapackOtcZeroSum_mV = 0;
static uint8_t snapackOtcZeroCount = 0;
static int snapackOtcZero_mV = 0;
static bool snapackOtcZeroReady = false;

static int snapack_ads_node_mV(int16_t raw)
{
  // +/-6.144 V ADS1115 range = 0.1875 mV/count = 3/16 mV/count.
  return (int)(((int32_t)raw * 3L + 8L) / 16L);
}

static int snapack_24v_rail_mV_from_raw(int16_t raw)
{
  // Board 3 A0 divider = 100k upper / 10k lower.
  // Source voltage = ADS node * 11.
  return (int)(((int32_t)raw * 33L + 8L) / 16L);
}

static void snapack_print_diag_channel(const char *label,
                                       bool ok,
                                       int16_t raw,
                                       int converted_mV)
{
  if (ok) {
    Serial.printf("%s raw=%d converted=%dmV", label, raw, converted_mV);
  } else {
    Serial.printf("%s READ_FAIL", label);
  }
}

static void snapack_scan_i2c_bus()
{
  Serial.println();
  Serial.println("------------- I2C ADDRESS SCAN -------------");

  int found = 0;

  for (uint8_t address = 1; address < 127; address++) {
    Wire.beginTransmission(address);
    uint8_t error = Wire.endTransmission();

    if (error == 0) {
      Serial.printf("I2C device found at 0x%02X\n", address);
      found++;
    }
  }

  if (found == 0) {
    Serial.println("No I2C devices found.");
  }

  Serial.println("--------------------------------------------");
}

static void snapack_service_ads_diagnostics()
{
  const unsigned long now = millis();
  if (now - snapackLastAdsDiagMs < SNAPACK_ADS_DIAG_MS) return;
  snapackLastAdsDiagMs = now;

  if (now - snapackLastI2cScanMs >= SNAPACK_I2C_SCAN_MS) {
    snapackLastI2cScanMs = now;
    snapack_scan_i2c_bus();
  }

  int16_t b1a0=0, b1a1=0, b1a2=0, b1a3=0;
  int16_t b3a0=0, b3a1=0, b3a2=0, b3a3=0;

  const bool b1ok0 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD1_ADDR,0,&b1a0);
  const bool b1ok1 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD1_ADDR,1,&b1a1);
  const bool b1ok2 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD1_ADDR,2,&b1a2);
  const bool b1ok3 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD1_ADDR,3,&b1a3);

  const bool b3ok0 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD3_ADDR,0,&b3a0);
  const bool b3ok1 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD3_ADDR,1,&b3a1);
  const bool b3ok2 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD3_ADDR,2,&b3a2);
  const bool b3ok3 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD3_ADDR,3,&b3a3);

  Serial.println();
  Serial.println("========== SNAPACK LIVE HARDWARE ==========");

  Serial.print("BOARD1 0x48 | ");
  snapack_print_diag_channel("A0=B5",b1ok0,b1a0,b1ok0?snapack_ads_divided_tap_mV(b1a0):0);
  Serial.print(" | ");
  snapack_print_diag_channel("A1=B4",b1ok1,b1a1,b1ok1?snapack_ads_divided_tap_mV(b1a1):0);
  Serial.print(" | ");
  snapack_print_diag_channel("A2=B3",b1ok2,b1a2,b1ok2?snapack_ads_divided_tap_mV(b1a2):0);
  Serial.print(" | ");
  snapack_print_diag_channel("A3=B2",b1ok3,b1a3,b1ok3?snapack_ads_divided_tap_mV(b1a3):0);
  Serial.println();

  Serial.print("BOARD3 0x4A | ");
  if (b3ok0) Serial.printf("A0=24V raw=%d node=%dmV rail=%dmV",
      b3a0,snapack_ads_node_mV(b3a0),snapack_24v_rail_mV_from_raw(b3a0));
  else Serial.print("A0=24V READ_FAIL");

  Serial.print(" | ");
  if (b3ok1) Serial.printf("A1=CDS raw=%d node=%dmV",
      b3a1,snapack_ads_node_mV(b3a1));
  else Serial.print("A1=CDS READ_FAIL");

  Serial.print(" | ");
  snapack_print_diag_channel("A2=B1",b3ok2,b3a2,
      b3ok2?snapack_ads_divided_tap_mV(b3a2):0);

  Serial.print(" | ");
  if (b3ok3) {
    const int otcNode_mV = snapack_ads_node_mV(b3a3);

    if (!snapackOtcZeroReady) {
      snapackOtcZeroSum_mV += otcNode_mV;
      snapackOtcZeroCount++;

      Serial.printf("A3=OTC raw=%d node=%dmV ZERO_CAPTURE=%u/%u",
                    b3a3,
                    otcNode_mV,
                    (unsigned)snapackOtcZeroCount,
                    (unsigned)SNAPACK_OTC_ZERO_SAMPLES);

      if (snapackOtcZeroCount >= SNAPACK_OTC_ZERO_SAMPLES) {
        snapackOtcZero_mV =
            (int)(snapackOtcZeroSum_mV / SNAPACK_OTC_ZERO_SAMPLES);
        snapackOtcZeroReady = true;
        Serial.printf(" ZERO=%dmV", snapackOtcZero_mV);
      }
    } else {
      const int delta_mV = otcNode_mV - snapackOtcZero_mV;

      // Development assumption under test: 1 mV/A.
      // Keep the signed delta in Serial.  The present big numeric Current font
      // contains digits only, so the screen shows magnitude for this test.
      const int provisional_A = delta_mV;
      const int display_A = provisional_A < 0 ? -provisional_A : provisional_A;

      Serial.printf("A3=OTC raw=%d node=%dmV zero=%dmV delta=%+dmV provisional=%+dA",
                    b3a3,
                    otcNode_mV,
                    snapackOtcZero_mV,
                    delta_mV,
                    provisional_A);

      ui_update_snapack_current(display_A);
    }
  } else {
    Serial.print("A3=OTC READ_FAIL");
  }

  Serial.println();
  Serial.println("===========================================");
}


// SNAPACK SIMULATED TEMPERATURE DATA
// ---------------------------------------------------------------------
//
// Temperatures are stored in tenths of a degree Fahrenheit.  The average is
// calculated here in the application layer rather than inside the UI.
//
// Later this function can be replaced by the five real sensor readings while
// ui_update_snapack_temperatures() and Screen6 remain unchanged.
void loadSnapackSimulatedTemperatureData() {
  const int temp1_dF = 721;  // 72.1 F
  const int temp2_dF = 744;  // 74.4 F
  const int temp3_dF = 733;  // 73.3 F
  const int temp4_dF = 758;  // 75.8 F
  const int temp5_dF = 726;  // 72.6 F

  const int avg_dF =
      (temp1_dF +
       temp2_dF +
       temp3_dF +
       temp4_dF +
       temp5_dF) / 5;

  ui_update_snapack_temperatures(temp1_dF,
                                 temp2_dF,
                                 temp3_dF,
                                 temp4_dF,
                                 temp5_dF,
                                 avg_dF);
}



// ---------------------------------------------------------------------
// SNAPACK SIMULATED CURRENT DATA
// ---------------------------------------------------------------------
//
// Whole amps are sufficient for the first cranking/current display pass.
// Replace this source later with the real current-clamp acquisition path.
void loadSnapackSimulatedCurrentData() {
  const int current_A = 187;
  ui_update_snapack_current(current_A);
}



// ---------------------------------------------------------------------
// SNAPACK TEMPERATURE BUS — 0 TO 5 SENSOR TOLERANT
// GPIO17 = rear-display TX-designated temperature connection.
// Each DS18B20-class sensor is identified by its factory 64-bit ROM address.
// Missing sensors never stop SNAPACK.
// ---------------------------------------------------------------------
static const uint8_t SNAPACK_TEMP_PIN = 43;
static const uint8_t SNAPACK_MAX_TEMP_SENSORS = 5;
static const unsigned long SNAPACK_TEMP_REFRESH_MS = 2000;

static OneWire snapackOneWire(SNAPACK_TEMP_PIN);
static DallasTemperature snapackTemps(&snapackOneWire);
static DeviceAddress snapackTempAddress[SNAPACK_MAX_TEMP_SENSORS];
static uint8_t snapackTempCount = 0;
static unsigned long snapackLastTempReadMs = 0;

static void snapack_print_rom(const uint8_t *rom)
{
  for (uint8_t i=0; i<8; i++) {
    if (rom[i] < 0x10) Serial.print('0');
    Serial.print(rom[i], HEX);
    if (i < 7) Serial.print('-');
  }
}

static void snapack_discover_temperature_sensors()
{
  snapackTempCount = 0;
  snapackOneWire.reset_search();
  uint8_t rom[8];

  while (snapackTempCount < SNAPACK_MAX_TEMP_SENSORS && snapackOneWire.search(rom)) {
    if (OneWire::crc8(rom,7) != rom[7]) {
      Serial.print("TEMP ROM CRC FAIL: ");
      snapack_print_rom(rom);
      Serial.println();
      continue;
    }

    memcpy(snapackTempAddress[snapackTempCount],rom,8);
    Serial.printf("TEMP SENSOR %u ROM: ",(unsigned)(snapackTempCount+1));
    snapack_print_rom(snapackTempAddress[snapackTempCount]);
    Serial.println();
    snapackTempCount++;
  }

  snapackOneWire.reset_search();
  Serial.printf("TEMP sensors discovered on TX/GPIO43: %u\n",(unsigned)snapackTempCount);
}

static void snapack_service_temperatures()
{
  const unsigned long now = millis();
  if (now - snapackLastTempReadMs < SNAPACK_TEMP_REFRESH_MS) return;
  snapackLastTempReadMs = now;

  // Bring-up behavior: rediscover so 0..5 sensors may appear/disappear freely.
  snapack_discover_temperature_sensors();

  const int TEMP_UNAVAILABLE = -32768;
  int display_dF[SNAPACK_MAX_TEMP_SENSORS] = {
      TEMP_UNAVAILABLE, TEMP_UNAVAILABLE, TEMP_UNAVAILABLE,
      TEMP_UNAVAILABLE, TEMP_UNAVAILABLE
  };

  if (snapackTempCount == 0) {
    Serial.println("TEMP: no sensors present; continuing normally");
    ui_update_snapack_temperatures(
        TEMP_UNAVAILABLE, TEMP_UNAVAILABLE, TEMP_UNAVAILABLE,
        TEMP_UNAVAILABLE, TEMP_UNAVAILABLE, TEMP_UNAVAILABLE);
    return;
  }

  snapackTemps.requestTemperatures();

  float sumC = 0.0f;
  uint8_t validCount = 0;

  for (uint8_t i = 0; i < snapackTempCount; i++) {
    const float c = snapackTemps.getTempC(snapackTempAddress[i]);

    Serial.printf("TEMP %u ROM ", (unsigned)(i + 1));
    snapack_print_rom(snapackTempAddress[i]);

    if (c == DEVICE_DISCONNECTED_C || c < -55.0f || c > 125.0f) {
      Serial.println(" = READ_FAIL");
      continue;
    }

    const float f = c * 9.0f / 5.0f + 32.0f;
    Serial.printf(" = %.2f C / %.2f F\n", c, f);

    // Store tenths of a degree F for the existing Temperature UI.
    display_dF[i] = (int)(f * 10.0f + (f >= 0.0f ? 0.5f : -0.5f));
    sumC += c;
    validCount++;
  }

  int avg_dF = TEMP_UNAVAILABLE;

  if (validCount > 0) {
    const float avgC = sumC / validCount;
    const float avgF = avgC * 9.0f / 5.0f + 32.0f;
    avg_dF = (int)(avgF * 10.0f + (avgF >= 0.0f ? 0.5f : -0.5f));

    Serial.printf("TEMP AVG (%u valid) = %.2f C / %.2f F\n",
                  (unsigned)validCount, avgC, avgF);
  } else {
    Serial.println("TEMP AVG unavailable; no valid readings");
  }

  // Real Temperature screen:
  // Sensor positions without valid hardware show "--".
  // AVG is calculated only from sensors actually present and valid.
  ui_update_snapack_temperatures(
      display_dF[0], display_dF[1], display_dF[2],
      display_dF[3], display_dF[4], avg_dF);
}


void setup() {
  Serial.begin(115200);
  snapackTemps.begin();
  Serial.println("TEMP: OneWire listening on rear TX / GPIO43");
  snapack_discover_temperature_sensors();
 /* prepare for possible serial debug */
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
  pcf8574.pinMode(P0, OUTPUT);        //tp RST
  pcf8574.pinMode(P2, OUTPUT);        //tp INT
  pcf8574.pinMode(P3, OUTPUT);        //lcd power
  pcf8574.pinMode(P4, OUTPUT);        //lcd reset
  pcf8574.pinMode(P5, INPUT_PULLUP);  //encoder SW

  Serial.print("Init pcf8574...\n");
  if (pcf8574.begin()) {
    Serial.println("pcf8574 OK");
  } else {
    Serial.println("pcf8574 KO");
  }

  pcf8574.digitalWrite(P3, HIGH);
  delay(100);

  /*lcd reset*/
  pcf8574.digitalWrite(P4, HIGH);
  delay(100);
  pcf8574.digitalWrite(P4, LOW);
  delay(120);
  pcf8574.digitalWrite(P4, HIGH);
  delay(120);
  /*end*/

  /*tp RST*/
  pcf8574.digitalWrite(P0, HIGH);
  delay(100);
  pcf8574.digitalWrite(P0, LOW);
  delay(120);
  pcf8574.digitalWrite(P0, HIGH);
  delay(120);
  /*tp INT*/
  pcf8574.digitalWrite(P2, HIGH);
  delay(120);

  gfx->begin();
  gfx->fillScreen(BLACK);
  gfx->setTextSize(2);
  gfx->setCursor(80, 100);

  if (!tsPanel.begin(&Wire, I2C_TOUCH_ADDR)) {
    Serial.println("No touchscreen found");
  } else {
    Serial.println("Touchscreen found");
  }

  pinMode(ENCODER_A_PIN, INPUT);
  pinMode(ENCODER_B_PIN, INPUT);
  lastA = digitalRead(ENCODER_A_PIN);

  lv_init();
  size_t buffer_size = sizeof(lv_color_t) * screenWidth * screenHeight;
  buf1 = (lv_color_t *)heap_caps_malloc(buffer_size, MALLOC_CAP_SPIRAM);
  buf2 = (lv_color_t *)heap_caps_malloc(buffer_size, MALLOC_CAP_SPIRAM);
  if (!buf1)
    Serial.println("Failed to allocate for LVGL---1---");
  if (!buf2)
    Serial.println("Failed to allocate for LVGL---2---");
  lv_disp_draw_buf_init(&draw_buf, buf1, buf2, screenWidth * screenHeight);

  /*Initialize the display*/
  static lv_disp_drv_t disp_drv;
  lv_disp_drv_init(&disp_drv);
  /*Change the following line to your display resolution*/
  disp_drv.hor_res = screenWidth;
  disp_drv.ver_res = screenHeight;
  disp_drv.flush_cb = my_disp_flush;
  disp_drv.draw_buf = &draw_buf;
  disp_drv.direct_mode = 0;
  disp_drv.full_refresh = 0; 
  disp_drv.sw_rotate = 0;
  disp_drv.screen_transp = 0;
  lv_disp_drv_register(&disp_drv);

  /*Initialize the (dummy) input device driver*/
  static lv_indev_drv_t indev_drv;
  lv_indev_drv_init(&indev_drv);
  indev_drv.type = LV_INDEV_TYPE_POINTER;
  indev_drv.read_cb = my_touchpad_read;
  lv_indev_drv_register(&indev_drv);

  /*Or try out a demo. Don't forget to enable the demos in lv_conf.h. E.g. LV_USE_DEMOS_WIDGETS*/
  // lv_demo_widgets();
  ui_init();

  // The temporary persistent SNAPACK marker is retired here.
  // The new carousel entry and Screen5 now identify our modified firmware.
  updateScreen(screen1_index);

  // Seed Cell Voltage with known-good development values.
  // A complete sane ADS1115 frame will replace these automatically.
  loadSnapackSimulatedCellData();

  // Bind the volume slider value-change event
  lv_obj_add_event_cb(ui_VolumeArc, volumeArcEventCb, LV_EVENT_VALUE_CHANGED, NULL);
  // Bind the temperature slider value-change event
  lv_obj_add_event_cb(ui_TempArc, tempArcEventCb, LV_EVENT_VALUE_CHANGED, NULL);

  delay(200);
  initBacklight();
  pcf8574.digitalWrite(P3, LOW);

  // Initialize pin 43 as the LED PWM output
  ledcSetup(breathPwmChannel, pwmFreq, pwmResolution);
  ledcAttachPin(BREATH_LED_PIN, breathPwmChannel);
  // At startup, do not breathe; hold brightness corresponding to the current value
  ledcWrite(breathPwmChannel, (volumeValue * 255) / 100);

  xTaskCreatePinnedToCore(encTask, "ENC", 2048, NULL, 1, &encTaskHandle, 0);
  xTaskCreatePinnedToCore(swTask, "SWITCH", 2048, NULL, 1, &swTaskHandle, 0);

  // Initialize remote LED-strip control state
  Serial.println("Initializing remote LED-strip control...");
  lastLedCountSent = -1;
  Serial.println("Remote LED-strip control initialization complete");

  Serial.println("Settings completed, ready to connect to WiFi...");
  connectWiFi();

  // After WiFi connects, obtain the Advance device IP address
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("WiFi connected; preparing UDP communication...");
    Serial.print("Local IP address: ");
    Serial.println(WiFi.localIP());
  }
}

void loop() {
  lv_timer_handler();

  // First live SNAPACK hardware-data service.
  snapack_service_real_cells();

  // Independent diagnostics for the two responsive ADS1115 boards.
  snapack_service_ads_diagnostics();

  snapack_service_temperatures();

  delay(5);
}

// Send the commanded number of illuminated LEDs to the Advance device
void sendLedStripCommand(int ledCount) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi not connected; cannot send LED-strip command");
    return;
  }

  ledCount = constrain(ledCount, 0, REMOTE_NUM_LEDS);
  String command = "LEDCOUNT:" + String(ledCount);
  udp.beginPacket(ADVANCE_IP, ADVANCE_PORT);
  udp.write((uint8_t*)command.c_str(), command.length());
  bool sent = udp.endPacket();
  if (sent) {
    Serial.printf("LED-strip command sent successfully: %s\n", command.c_str());
  } else {
    Serial.println("LED-strip command failed to send");
  }
}

// Map the temperature value and control the WS2812 LED strip on Advance
void updateLedStripByTemperature(int temp) {
  temp = constrain(temp, 0, 200);
  int ledCount = map(temp, 0, 200, 0, REMOTE_NUM_LEDS);
  if (ledCount == lastLedCountSent) return;
  lastLedCountSent = ledCount;
  sendLedStripCommand(ledCount);
  Serial.printf("Temperature: %d -> Illuminated LED count: %d\n", temp, ledCount);
}

// Volume-slider event: update the value and send it to Advance via UDP
void volumeArcEventCb(lv_event_t *e) {
  if (lv_event_get_code(e) != LV_EVENT_VALUE_CHANGED) return;
  lv_obj_t *arc = lv_event_get_target(e);
  int value = lv_arc_get_value(arc); // 0-100

  // Update UI text using the same format as the rotary-control logic
  char volText[8];
  if (value == 100) {
    snprintf(volText, sizeof(volText), "%d%%", value);
    lv_label_set_text(ui_VolNum, volText);
  } else {
    snprintf(volText, sizeof(volText), " %d%%", value);
    lv_label_set_text(ui_VolNum, volText);
  }
  // Set LED brightness directly to the corresponding duty cycle
  volumeValue = value;
  ledcWrite(breathPwmChannel, (volumeValue * 255) / 100);
}


// Temperature-slider event: update temperature text and control the servo
void tempArcEventCb(lv_event_t *e) {
  if (lv_event_get_code(e) != LV_EVENT_VALUE_CHANGED) return;
  lv_obj_t *arc = lv_event_get_target(e);
  int value = lv_arc_get_value(arc); // 0-200

  // Update temperature text (using the existing format)
  char tempText[8];
  if (value >= 100 && value <= 200) {
    snprintf(tempText, sizeof(tempText), " %d%°", value);
    lv_label_set_text(ui_TempNum, tempText);
  } else {
    snprintf(tempText, sizeof(tempText), "  %d%°", value);
    lv_label_set_text(ui_TempNum, tempText);
  }

  // Control the remote LED strip (map 0-200 to 0-15 LEDs)
  updateLedStripByTemperature(value);
}


int last_counter = 0;
int counter = 0;
int currentStateCLK;
int lastStateCLK;
String currentDir = "";
bool one_test = false;

void performClickAction() {
  current_screen = lv_scr_act();

  // Six carousel destinations now exist.  The OEM screens are retained
  // unchanged and shifted one index to make room for SNAPACK at index 0.
  if (current_screen == ui_Screen1) {
    if (screen1_index == 0) {
      _ui_screen_change(&ui_Screen5, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen5_screen_init);
    } else if (screen1_index == 1) {
      _ui_screen_change(&ui_Screen6, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen6_screen_init);
    } else if (screen1_index == 2) {
      _ui_screen_change(&ui_Screen7, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen7_screen_init);
    } else if (screen1_index == 3) {
      _ui_screen_change(&ui_Screen2, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen2_screen_init);
    } else if (screen1_index == 4) {
      _ui_screen_change(&ui_Screen3, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen3_screen_init);
    } else if (screen1_index == 5) {
      _ui_screen_change(&ui_Screen4, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen4_screen_init);
    }
  }
}

void performDoubleClickAction() {
  current_screen = lv_scr_act();

  // Extend the OEM double-click return path to the new SNAPACK screen.
  if (current_screen == ui_Screen5 ||
      current_screen == ui_Screen6 ||
      current_screen == ui_Screen7 ||
      current_screen == ui_Screen2 ||
      current_screen == ui_Screen3 ||
      current_screen == ui_Screen4) {
    _ui_screen_change(&ui_Screen1, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen1_screen_init);
  }
}

void processEncoder() {
  current_screen = lv_scr_act();

  if (current_screen == ui_Screen1) {
    // Six carousel positions now exist: 0 through 5.
    if (position_tmp == 1) {
      if (screen1_index < 5) screen1_index++;
    } else if (position_tmp == 0) {
      if (screen1_index > 0) screen1_index--;
    }

    Serial.printf("cur_index: %d\n", screen1_index);
    updateScreen(screen1_index);
    position_tmp = -1;
  }
}

void encTask(void *pvParameters) {
  while (1) {
    // Read the current state of CLK
    currentStateCLK = digitalRead(ENCODER_A_PIN);
    // If last and current state of CLK are different, then pulse occurred
    // React to only 1 state change to avoid double count
    if (currentStateCLK != lastStateCLK && currentStateCLK == 1) {
      current_screen = lv_scr_act();
      // If the DT state is different than the CLK state then
      // the encoder is rotating CCW so decrement
      if (digitalRead(ENCODER_B_PIN) != currentStateCLK) {
        if (abs(last_counter - counter) > 200) {
          continue;
        }

        if (current_screen == ui_Screen2) {
          int currentVol = lv_arc_get_value(ui_VolumeArc);
          Serial.printf(" -- currentVol = %d\n", currentVol);
          int newVol = (currentVol - 5) < 0 ? 0 : currentVol - 5;
          Serial.printf(" -- END currentVol = %d\n", newVol);
          lv_arc_set_value(ui_VolumeArc, newVol);

          volumeValue = newVol; // Synchronize global volume

          char volText[8];
          if (newVol == 100) {
            snprintf(volText, sizeof(volText), "%d%%", newVol);
            lv_label_set_text(ui_VolNum, volText);
          } else {
            snprintf(volText, sizeof(volText), " %d%%", newVol);
            lv_label_set_text(ui_VolNum, volText);
          }

          // Set LED brightness directly
          ledcWrite(breathPwmChannel, (volumeValue * 255) / 100);

        } else if (current_screen == ui_Screen3) {
          int currentTemp = lv_arc_get_value(ui_TempArc);
          Serial.printf(" -- currentVol = %d\n", currentTemp);
          int newTemp = (currentTemp - 5) < 0 ? 0 : currentTemp - 5;
          Serial.printf(" -- END currentVol = %d\n", newTemp);
          lv_arc_set_value(ui_TempArc, newTemp);
          char TempText[8];
          if (newTemp >= 100 && newTemp <= 200) {
            snprintf(TempText, sizeof(TempText), "%d%°C", newTemp);
            lv_label_set_text(ui_TempNum, TempText);
          } else {
            snprintf(TempText, sizeof(TempText), " %d%°C", newTemp);
            lv_label_set_text(ui_TempNum, TempText);
          }

          // Update the remote LED strip
          updateLedStripByTemperature(newTemp);

        } else if (current_screen == ui_Screen4) {
          int currentLight = lv_arc_get_value(ui_lightArc);
          Serial.printf(" -- currentLight = %d\n", currentLight);
          int newLight = (currentLight - 5) < 0 ? 0 : currentLight - 5;
          Serial.printf(" -- END currentLight = %d\n", newLight);
          lv_arc_set_value(ui_lightArc, newLight);

          lightValue = newLight; // Synchronize global brightness

          char LightText[8];
          if (newLight == 100) {
            snprintf(LightText, sizeof(LightText), "%d%%", newLight);
            lv_label_set_text(ui_LightNum, LightText);
          } else {
            snprintf(LightText, sizeof(LightText), " %d%%", newLight);
            lv_label_set_text(ui_LightNum, LightText);
          }
          int pwm_value = (newLight * 255) / 100;
          ledcSetup(pwmChannel, pwmFreq, pwmResolution);
          ledcAttachPin(SCREEN_BACKLIGHT_PIN, pwmChannel);
          ledcWrite(pwmChannel, pwm_value);
        }
        position_tmp = 0;

        counter++;
        currentDir = "CCW"; // Counterclockwise
      } else {
        if (one_test == false)  
        {
          one_test = true;
          continue;
        }
        if (current_screen == ui_Screen2) {
          int currentVol = lv_arc_get_value(ui_VolumeArc);
          Serial.printf(" ++ currentVol = %d\n", currentVol);
          int newVol = (currentVol + 5) > 100 ? 100 : currentVol + 5;
          Serial.printf(" ++ END currentVol = %d\n", newVol);
          lv_arc_set_value(ui_VolumeArc, newVol);

          volumeValue = newVol; // Synchronize global volume

          char volText[8];
          if (newVol == 100) {
            snprintf(volText, sizeof(volText), "%d%%", newVol);
            lv_label_set_text(ui_VolNum, volText);
          } else {
            snprintf(volText, sizeof(volText), " %d%%", newVol);
            lv_label_set_text(ui_VolNum, volText);
          }

          // Set LED brightness directly
          ledcWrite(breathPwmChannel, (volumeValue * 255) / 100);

        } else if (current_screen == ui_Screen3) {
          int currentTemp = lv_arc_get_value(ui_TempArc);
          Serial.printf(" ++ currentVol = %d\n", currentTemp);
          int newTemp = (currentTemp + 5) > 200 ? 200 : currentTemp + 5;
          Serial.printf(" ++ END currentVol = %d\n", newTemp);
          lv_arc_set_value(ui_TempArc, newTemp);

          char TempText[8];
          if (newTemp >= 100 && newTemp <= 200) {
            snprintf(TempText, sizeof(TempText), "%d%°C", newTemp);
            lv_label_set_text(ui_TempNum, TempText);
          } else {
            snprintf(TempText, sizeof(TempText), " %d%°C", newTemp);
            lv_label_set_text(ui_TempNum, TempText);
          }

          // Update the remote LED strip
          updateLedStripByTemperature(newTemp);

        } else if (current_screen == ui_Screen4) {
          int currentLight = lv_arc_get_value(ui_lightArc);
          Serial.printf(" ++ currentLight = %d\n", currentLight);
          int newLight = (currentLight + 5) > 100 ? 100 : currentLight + 5;
          Serial.printf(" ++ END currentLight = %d\n", newLight);
          lv_arc_set_value(ui_lightArc, newLight);

          lightValue = newLight; // Synchronize global brightness

          char LightText[8];
          if (newLight == 100) {
            snprintf(LightText, sizeof(LightText), "%d%%", newLight);
            lv_label_set_text(ui_LightNum, LightText);
          } else {
            snprintf(LightText, sizeof(LightText), " %d%%", newLight);
            lv_label_set_text(ui_LightNum, LightText);
          }
          
          int pwm_value = (newLight * 255) / 100;
          ledcSetup(pwmChannel, pwmFreq, pwmResolution);
          ledcAttachPin(SCREEN_BACKLIGHT_PIN, pwmChannel);
          ledcWrite(pwmChannel, pwm_value);
        }
        position_tmp = 1;
        counter--;
        currentDir = "CW";
      }

      Serial.print("Direction: ");
      Serial.print(currentDir);
      Serial.print(" | Counter: ");
      Serial.println(counter);
      last_counter = counter;
      processEncoder();
    }

    if (pressedFlag)
    {
      if (pressCount == 1 && millis() >= singleClickTimeout) {
        Serial.println("Single Click Detected");
        performClickAction();
        pressCount = 0;
        pressedFlag = false;

      }
      else if (pressCount >= 2) {
        Serial.println("Double Click Detected");
        performDoubleClickAction();
        pressCount = 0;
        pressedFlag = false;
      }
    }
    // Remember last CLK state
    lastStateCLK = currentStateCLK;
    vTaskDelay(pdMS_TO_TICKS(2));
  }
}

void updateScreen(int index) {
  // SINGLE SOURCE OF TRUTH FOR THE SIX-ITEM CAROUSEL
  //
  // 0 = SNAPACK Cell Voltage
  // 1 = SNAPACK Temperature
  // 2 = SNAPACK Current
  // 3 = OEM Volume
  // 4 = OEM Temp
  // 5 = OEM Light

  if (index < 0) index = 0;
  if (index > 5) index = 5;
  screen1_index = index;

  // Hide all carousel objects first.
  lv_obj_add_flag(ui_snapackBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_snapackTextBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_snapackTextWhite, LV_OBJ_FLAG_HIDDEN);

  lv_obj_add_flag(ui_snapackTempBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_snapackTempTextBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_snapackTempTextWhite, LV_OBJ_FLAG_HIDDEN);

  lv_obj_add_flag(ui_snapackCurrentBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_snapackCurrentTextBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_snapackCurrentTextWhite, LV_OBJ_FLAG_HIDDEN);

  lv_obj_add_flag(ui_volumeBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_volumeWhite, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_volumeTextBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_volumeTextWhite, LV_OBJ_FLAG_HIDDEN);

  lv_obj_add_flag(ui_tempBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_tempWhite, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_tempTextBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_tempTextWhite, LV_OBJ_FLAG_HIDDEN);

  lv_obj_add_flag(ui_lightBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_lightWhite, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_lightTextBlue, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_lightTextWhite, LV_OBJ_FLAG_HIDDEN);

  switch (index) {
    case 0:  // SNAPACK Cell Voltage
      lv_obj_clear_flag(ui_snapackBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_snapackTextBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_snapackBlue, 0);
      lv_obj_set_x(ui_snapackTextBlue, 0);
      lv_obj_set_x(ui_snapackTextWhite, 0);

      lv_obj_clear_flag(ui_snapackTempTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_snapackTempBlue, 140);
      lv_obj_set_x(ui_snapackTempTextBlue, 140);
      lv_obj_set_x(ui_snapackTempTextWhite, 140);
      break;

    case 1:  // SNAPACK Temperature
      lv_obj_clear_flag(ui_snapackTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_snapackBlue, -140);
      lv_obj_set_x(ui_snapackTextBlue, -140);
      lv_obj_set_x(ui_snapackTextWhite, -140);

      lv_obj_clear_flag(ui_snapackTempBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_snapackTempTextBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_snapackTempBlue, 0);
      lv_obj_set_x(ui_snapackTempTextBlue, 0);
      lv_obj_set_x(ui_snapackTempTextWhite, 0);

      lv_obj_clear_flag(ui_snapackCurrentTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_snapackCurrentBlue, 140);
      lv_obj_set_x(ui_snapackCurrentTextBlue, 140);
      lv_obj_set_x(ui_snapackCurrentTextWhite, 140);
      break;

    case 2:  // SNAPACK Current
      lv_obj_clear_flag(ui_snapackTempTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_snapackTempBlue, -140);
      lv_obj_set_x(ui_snapackTempTextBlue, -140);
      lv_obj_set_x(ui_snapackTempTextWhite, -140);

      lv_obj_clear_flag(ui_snapackCurrentBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_snapackCurrentTextBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_snapackCurrentBlue, 0);
      lv_obj_set_x(ui_snapackCurrentTextBlue, 0);
      lv_obj_set_x(ui_snapackCurrentTextWhite, 0);

      lv_obj_clear_flag(ui_volumeWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_volumeTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_volumeBlue, 140);
      lv_obj_set_x(ui_volumeWhite, 140);
      lv_obj_set_x(ui_volumeTextBlue, 140);
      lv_obj_set_x(ui_volumeTextWhite, 140);
      break;

    case 3:  // OEM Volume
      lv_obj_clear_flag(ui_snapackCurrentTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_snapackCurrentBlue, -140);
      lv_obj_set_x(ui_snapackCurrentTextBlue, -140);
      lv_obj_set_x(ui_snapackCurrentTextWhite, -140);

      lv_obj_clear_flag(ui_volumeBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_volumeTextBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_volumeBlue, 0);
      lv_obj_set_x(ui_volumeWhite, 0);
      lv_obj_set_x(ui_volumeTextBlue, 0);
      lv_obj_set_x(ui_volumeTextWhite, 0);

      lv_obj_clear_flag(ui_tempWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_tempTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_tempBlue, 140);
      lv_obj_set_x(ui_tempWhite, 140);
      lv_obj_set_x(ui_tempTextBlue, 140);
      lv_obj_set_x(ui_tempTextWhite, 140);
      break;

    case 4:  // OEM Temp
      lv_obj_clear_flag(ui_volumeWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_volumeTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_volumeBlue, -140);
      lv_obj_set_x(ui_volumeWhite, -140);
      lv_obj_set_x(ui_volumeTextBlue, -140);
      lv_obj_set_x(ui_volumeTextWhite, -140);

      lv_obj_clear_flag(ui_tempBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_tempTextBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_tempBlue, 0);
      lv_obj_set_x(ui_tempWhite, 0);
      lv_obj_set_x(ui_tempTextBlue, 0);
      lv_obj_set_x(ui_tempTextWhite, 0);

      lv_obj_clear_flag(ui_lightWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_lightTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_lightBlue, 140);
      lv_obj_set_x(ui_lightWhite, 140);
      lv_obj_set_x(ui_lightTextBlue, 140);
      lv_obj_set_x(ui_lightTextWhite, 140);
      break;

    case 5:  // OEM Light
      lv_obj_clear_flag(ui_tempWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_tempTextWhite, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_tempBlue, -140);
      lv_obj_set_x(ui_tempWhite, -140);
      lv_obj_set_x(ui_tempTextBlue, -140);
      lv_obj_set_x(ui_tempTextWhite, -140);

      lv_obj_clear_flag(ui_lightBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(ui_lightTextBlue, LV_OBJ_FLAG_HIDDEN);
      lv_obj_set_x(ui_lightBlue, 0);
      lv_obj_set_x(ui_lightWhite, 0);
      lv_obj_set_x(ui_lightTextBlue, 0);
      lv_obj_set_x(ui_lightTextWhite, 0);
      break;
  }
}

void swTask(void *pvParameters) {
  while (1) {
    currentSW = pcf8574.digitalRead(P5, true);
    if (currentSW == LOW) {
      // Serial.printf("currentSW == LOW\n");
      static unsigned long lastInterruptTime = 0;
      unsigned long currentTime = millis();

      if (currentTime - lastInterruptTime > debounceTime) {
        pressCount++;
        pressedFlag = true;
        if (pressCount == 1) {
          singleClickTimeout = currentTime + doubleClickTime;
        }
      }
      lastInterruptTime = currentTime;
    }
    vTaskDelay(pdMS_TO_TICKS(5));
  }
}

