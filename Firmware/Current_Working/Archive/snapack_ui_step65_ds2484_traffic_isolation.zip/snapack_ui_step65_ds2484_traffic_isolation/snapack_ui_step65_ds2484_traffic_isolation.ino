#include <OneWire.h>
#include <DallasTemperature.h>
#include <lvgl.h>
#include <demos/lv_demos.h>
#include <Arduino_GFX_Library.h>
#include "WiFiMulti.h"
#include <WiFi.h>
#include <WiFiUdp.h>
#include <Preferences.h>

#include <Adafruit_SSD1306.h>
#include <Adafruit_GFX.h>

// #include <CSE_CST328.h>
#include <Adafruit_CST8XX.h>
#include "ui.h"
#include "PCF8574.h" 

#define I2C_SDA_PIN 38
#define I2C_SCL_PIN 39
PCF8574 pcf8574(0x21);

String wifiId = "elecrow888";            //WiFi SSID to coonnect to
String wifiPwd = "elecrow2014";  //PASSWORD of the WiFi SSID to coonnect to

#define ENCODER_A_PIN 42     // Blue: counterclockwise, rises first
#define ENCODER_B_PIN 4      // Yellow: clockwise, rises first   B   A

volatile uint8_t lastA = 0;   
volatile uint8_t currentSW = 0; 

bool pressedFlag = false;      
volatile int pressCount = 0;  

const unsigned long debounceTime = 50;    
const unsigned long doubleClickTime = 260;  

volatile unsigned long singleClickTimeout = 0; 
volatile int8_t position_tmp = 2;      

#define SCREEN_BACKLIGHT_PIN 6
const int pwmFreq = 5000;
const int pwmChannel = 0;
const int pwmResolution = 8;

TaskHandle_t encTaskHandle = NULL;
TaskHandle_t swTaskHandle = NULL;

// STEP 55 compile fix: declaration must appear before my_touchpad_read().
void performClickAction();

#define I2C_TOUCH_ADDR 0x15  // often but not always 0x15!
Adafruit_CST8XX tsPanel = Adafruit_CST8XX();
enum Events lastevent = NONE;

static const uint16_t screenWidth = 480;
static const uint16_t screenHeight = 480;

static lv_disp_draw_buf_t draw_buf;
static lv_color_t *buf1 = NULL;
static lv_color_t *buf2 = NULL;
static uint16_t *buf3 = NULL;
static uint16_t *buf4 = NULL;

lv_obj_t *current_screen = NULL;
// Carousel index:
//   0 = SNAPACK Cell Voltage
//   1 = SNAPACK Temperature
//   2 = SNAPACK Current
//   3 = SNAPACK Diagnostic
//   4 = OEM Volume
//   5 = OEM Temp
//   6 = OEM Light
//
// Start on SNAPACK after the Elecrow splash.
int screen1_index = 0;

Preferences snapackPrefs;
static int snapackSavedVolume = 50;
static int snapackSavedTemp = 50;
static int snapackSavedLight = 50;

Arduino_ESP32RGBPanel *bus = new Arduino_ESP32RGBPanel(
  16 /* CS */, 2 /* SCK */, 1 /* SDA */,
  40 /* DE */, 7 /* VSYNC */, 15 /* HSYNC */, 41 /* PCLK */,
  46 /* R0 */, 3 /* R1 */, 8 /* R2 */, 18 /* R3 */, 17 /* R4 */,
  14 /* G0/P22 */, 13 /* G1/P23 */, 12 /* G2/P24 */, 11 /* G3/P25 */, 10 /* G4/P26 */, 9 /* G5 */,
  5 /* B0 */, 45 /* B1 */, 48 /* B2 */, 47 /* B3 */, 21 /* B4 */
);

Arduino_ST7701_RGBPanel *gfx = new Arduino_ST7701_RGBPanel(
  bus, GFX_NOT_DEFINED /* RST */, 0 /* rotation */,
  false /* IPS */, 480 /* width */, 480 /* height */,
  st7701_type5_init_operations, sizeof(st7701_type5_init_operations),
  true /* BGR */,
  10 /* hsync_front_porch(10) */, 4 /* hsync_pulse_width(8) */, 20 /* hsync_back_porch(50) */,
  10 /* vsync_front_porch(10) */, 4 /* vsync_pulse_width(8) */, 20 /* vsync_back_porch(20) */);

/* Display flushing */
void my_disp_flush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p) {
  uint32_t w = (area->x2 - area->x1 + 1);
  uint32_t h = (area->y2 - area->y1 + 1);
#if (LV_COLOR_16_SWAP != 0)
  gfx->draw16bitBeRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#else
  gfx->draw16bitRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#endif
  lv_disp_flush_ready(disp);
}

/*Read CST826 the touchpad*/
const int SWIPE_THRESHOLD = 100;  
const int TIME_THRESHOLD = 300;   
const int VERTICAL_LIMIT = 100;    
int startX = 0;
int startY = 0;
unsigned long startTime = 0;
bool trackingSwipe = false;
bool bottomHalfTapCandidate = false;
static unsigned long carouselSwipeBlockUntilMs = 0;
bool first_click = false;
void my_touchpad_read(lv_indev_drv_t *indev_driver, lv_indev_data_t *data) {
  if (tsPanel.touched()) {
    CST_TS_Point p = tsPanel.getPoint(0);
    data->point.x = p.x;
    data->point.y = p.y - 20;
    data->state = LV_INDEV_STATE_PR;

    lv_obj_t *current_screen = lv_scr_act();

    // SNAPACK CAROUSEL SWIPE HANDLING
    // Touch and rotary now share updateScreen() as one source of truth.
    // The original code duplicated the complete three-item layout inside
    // both swipe directions; that duplication is removed here before the
    // carousel grows to four items.
    if (current_screen == ui_Screen1) {
      if (first_click == false) {
        startX = p.x;
        startY = p.y;
        startTime = millis();
        trackingSwipe = true;
        // Full-width lower half is one giant SELECT zone.
        bottomHalfTapCandidate = ((p.y - 20) >= 240);
        first_click = true;
      }

      if (trackingSwipe && p.event == TOUCHING) {
        int deltaX = p.x - startX;
        int deltaY = abs(p.y - startY);
        unsigned long elapsed = millis() - startTime;

        if (elapsed < TIME_THRESHOLD && deltaY < VERTICAL_LIMIT) {
          // STEP 31: reverse swipe direction so carousel motion follows the finger.
          if (deltaX > SWIPE_THRESHOLD) {
            first_click = false;
            trackingSwipe = false;
            bottomHalfTapCandidate = false;
            carouselSwipeBlockUntilMs = millis() + 250;
            screen1_index = (screen1_index + 6) % 7;
            ui_snapack_carousel_swipe_feedback(1);
            updateScreen(screen1_index);
          }
          else if (deltaX < -SWIPE_THRESHOLD) {
            first_click = false;
            trackingSwipe = false;
            bottomHalfTapCandidate = false;
            carouselSwipeBlockUntilMs = millis() + 250;
            screen1_index = (screen1_index + 1) % 7;
            ui_snapack_carousel_swipe_feedback(-1);
            updateScreen(screen1_index);
          }
        }
      }
    }

    // STEP 45: suppress high-rate touch Serial logging.
    // Printing every TOUCHING sample can swamp the main loop during gestures.
    if (p.event != lastevent) {
      lastevent = p.event;
    }
  }
  else {
    data->state = LV_INDEV_STATE_REL;

    // STEP 38: top half = swipe only; bottom half = select centered item.
    // A recognized swipe has already cleared bottomHalfTapCandidate.
    if (bottomHalfTapCandidate && lv_scr_act() == ui_Screen1) {
      bottomHalfTapCandidate = false;
      first_click = false;
      trackingSwipe = false;
      ui_snapack_carousel_select_pulse();
      lv_refr_now(NULL);
      delay(120);
      performClickAction();
      return;
    }

    bottomHalfTapCandidate = false;
    first_click = false;
    trackingSwipe = false;
  }
}

// WiFi connection function
void connectWiFi() {
  Serial.println("Connecting to WiFi...");
  WiFi.begin(wifiId.c_str(), wifiPwd.c_str());
  
  // Wait for connection, up to 10 seconds
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi Connected!");
    Serial.print("SSID: ");
    Serial.println(WiFi.SSID());
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nFailed to connect to WiFi");
  }
}


void initBacklight() {
  ledcSetup(pwmChannel, pwmFreq, pwmResolution);
  ledcAttachPin(SCREEN_BACKLIGHT_PIN, pwmChannel);
  ledcWrite(pwmChannel, 204);
}

// Onboard rotary-display LED (pin 43) used for breathing effect
#define BREATH_LED_PIN 43
// Breathing-LED PWM channel (avoid conflict with backlight channel)
const int breathPwmChannel = 1;

// UDP communication variables
WiFiUDP udp;
const char* ADVANCE_IP = "192.168.50.160";  // Advance device IP address; modify as required
const int ADVANCE_PORT = 8888;             // Advance device UDP port
 
// Remote LED strip (Advance side) configuration (declared here for setup initialization)
const int REMOTE_NUM_LEDS = 15;      // Number of LEDs in the strip on Advance
int lastLedCountSent = -1;           // Record the last LED count sent to Advance

// Forward declarations: LVGL slider event callbacks
void volumeArcEventCb(lv_event_t *e);
// void volumeIconEventCb(lv_event_t *e);

void tempArcEventCb(lv_event_t *e);
// Set brightness directly through PWM only; no animation

// Initial UI values (applied when entering the screen)
int volumeValue = 50;  // 0-100
int tempValue = 0;     // 0-200
int lightValue = 50;   // 0-100


static void snapack_apply_ring_speed(int value)
{
  ui_set_snapack_ring_speed(value);
  ui_set_snapack_voltage_ring_speed(value);
  ui_set_snapack_temperature_ring_speed(value);
  ui_set_snapack_diag_ring_speed(value);
}

static void snapack_save_ui_settings()
{
  snapackPrefs.putUChar("volume", (uint8_t)constrain(volumeValue, 0, 100));
  snapackPrefs.putUChar("temp",   (uint8_t)constrain(lv_arc_get_value(ui_TempArc), 0, 200));
  snapackPrefs.putUChar("light",  (uint8_t)constrain(lightValue, 0, 100));
}


// ---------------------------------------------------------------------
// SNAPACK SIMULATED CELL DATA
// ---------------------------------------------------------------------
//
// These deliberately different values prove that five independent cell
// readings can travel from the application layer into Screen5.
//
// Values are stored as integer millivolts.
// The pack total is calculated here, not in the UI.
//
// When real ADS1115 acquisition is added, this small development function
// can be replaced while ui_update_snapack_cells() and the Screen5 layout
// remain unchanged.
void loadSnapackSimulatedCellData() {
  const int cell1_mV = 4180;
  const int cell2_mV = 4160;
  const int cell3_mV = 4170;
  const int cell4_mV = 4170;
  const int cell5_mV = 4180;

  // SNAPACK is a five-cell monitored pack in this display path.
  // Pack voltage is therefore the sum of these five individual cells.
  const int pack_mV =
      cell1_mV +
      cell2_mV +
      cell3_mV +
      cell4_mV +
      cell5_mV;

  ui_update_snapack_cells(cell1_mV,
                          cell2_mV,
                          cell3_mV,
                          cell4_mV,
                          cell5_mV,
                          pack_mV);
}


// ---------------------------------------------------------------------
// SNAPACK REAL CELL-VOLTAGE ACQUISITION — FIRST HARDWARE DATA PATH
// ---------------------------------------------------------------------
//
// hardware_manifest_revised.txt mapping:
//
//   ADS1115 Board 1 — 0x48
//     A0 = B2 cumulative tap
//     A1 = B3 cumulative tap
//     A2 = B4 cumulative tap
//     A3 = B5 cumulative tap / pack positive
//
//   ADS1115 Board 2 — 0x49
//     A0 = B1 cumulative tap
//
//   B0 = system ground.
//
// Individual cells are differences between cumulative taps:
//
//   Cell 1 = B1
//   Cell 2 = B2 - B1
//   Cell 3 = B3 - B2
//   Cell 4 = B4 - B3
//   Cell 5 = B5 - B4
//   PACK   = B5
//
// Divider on each cumulative input:
//   47k upper / 18k lower
//
// ADS1115 range used here:
//   +/-4.096 V, 0.125 mV/count
//
// B1-B3 use 47k/18k; B4-B5 use 100k/10k.
// Conversion is selected per channel below.
//
// This first step intentionally uses Wire directly so no new Arduino
// library is introduced.
//
// DEVELOPMENT BOUNDARY:
// The single-shot config below leaves the ADS comparator disabled.
// Board-1 ALERT / lockout behavior is NOT implemented by this step.

static const uint8_t SNAPACK_ADS_BOARD1_ADDR = 0x48;
static const uint8_t SNAPACK_ADS_BOARD2_ADDR = 0x49;
static const uint8_t SNAPACK_ADS_BOARD3_ADDR = 0x4A;

static const bool SNAPACK_REAL_CELLS_ENABLED = true;
static const unsigned long SNAPACK_CELL_REFRESH_MS = 500;

static unsigned long snapackLastCellReadMs = 0;
static unsigned long snapackLastCellErrorPrintMs = 0;

static bool snapack_i2c_device_present(uint8_t address)
{
  Wire.beginTransmission(address);
  return Wire.endTransmission() == 0;
}

static bool snapack_ads_write_register(uint8_t address,
                                       uint8_t reg,
                                       uint16_t value)
{
  Wire.beginTransmission(address);
  Wire.write(reg);
  Wire.write((uint8_t)(value >> 8));
  Wire.write((uint8_t)(value & 0xFF));
  return Wire.endTransmission() == 0;
}

static bool snapack_ads_read_register(uint8_t address,
                                      uint8_t reg,
                                      uint16_t *value)
{
  if (!value) return false;

  Wire.beginTransmission(address);
  Wire.write(reg);

  if (Wire.endTransmission(false) != 0) {
    return false;
  }

  if (Wire.requestFrom((int)address, 2) != 2) {
    return false;
  }

  *value = ((uint16_t)Wire.read() << 8) | Wire.read();
  return true;
}

static bool snapack_ads_read_single_ended(uint8_t address,
                                          uint8_t channel,
                                          int16_t *raw)
{
  if (!raw || channel > 3) return false;

  // CONFIG:
  // OS=1, single-ended A0..A3, PGA +/-4.096 V,
  // single-shot, 860 SPS, comparator disabled.
  // NOTE: PGA is the ADC input-range/gain setting; it is NOT the ADS supply voltage.
  // ADS VDD remains 3.3 V in the rebuilt hardware.
  const uint16_t mux = (uint16_t)(0x04 + channel) << 12;
  const uint16_t config =
      0x8000 |
      mux |
      0x0200 |  // PGA +/-4.096 V
      0x0100 |
      0x00E0 |
      0x0003;

  if (!snapack_ads_write_register(address, 0x01, config)) {
    return false;
  }

  const unsigned long started = millis();

  while (millis() - started < 10) {
    uint16_t status = 0;

    if (!snapack_ads_read_register(address, 0x01, &status)) {
      return false;
    }

    if (status & 0x8000) {
      uint16_t conversion = 0;

      if (!snapack_ads_read_register(address, 0x00, &conversion)) {
        return false;
      }

      *raw = (int16_t)conversion;
      return true;
    }

    delay(1);
  }

  return false;
}

// STEP 26: discard the first completed conversion after selecting a channel.
static bool snapack_ads_read_single_ended_settled(uint8_t address,
                                                  uint8_t channel,
                                                  int16_t *raw)
{
  int16_t throwaway = 0;
  if (!snapack_ads_read_single_ended(address, channel, &throwaway)) return false;
  return snapack_ads_read_single_ended(address, channel, raw);
}


static int snapack_ads_node_mV(int16_t raw)
{
  // +/-4.096 V ADS1115 range = 0.125 mV/count = 1/8 mV/count.
  return (int)(((int32_t)raw + (raw >= 0 ? 4 : -4)) / 8L);
}

static int snapack_ads_47k18k_tap_mV(int16_t raw)
{
  // ADS node = source * 18/(47+18).  Source = node * 65/18.
  // At 0.125 mV/count: source mV/count = 65/144.
  return (int)(((int32_t)raw * 65L + (raw >= 0 ? 72 : -72)) / 144L);
}

static int snapack_ads_100k10k_source_mV(int16_t raw)
{
  // ADS node = source / 11.  Source = node * 11.
  // At 0.125 mV/count: source mV/count = 11/8.
  return (int)(((int32_t)raw * 11L + (raw >= 0 ? 4 : -4)) / 8L);
}

// STEP 35 diagnostic cache values.
// Declared here so the real-cell reader can update them.
static int snapackDiag24Rail_mV = 0;
static int snapackDiagPack_mV = 0;
static int snapackDiag4SPack_mV = 0;
static int snapackDiagLowCell_mV = 0;

static void snapack_push_diag_ui_throttled();

static bool snapack_read_real_cells_once()
{
  int16_t rawB1=0, rawB2=0, rawB3=0, rawB4=0, rawB5=0;

  // 3.3-V REBUILD MAP:
  // ADS #1 / 0x48: A0=B1, A1=B2, A2=B3, A3=B4
  // ADS #2 / 0x49: A0=B5, A1=CdS, A2=OTC, A3=24-V rail
  const bool okB1 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD1_ADDR, 0, &rawB1);
  const bool okB2 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD1_ADDR, 1, &rawB2);
  const bool okB3 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD1_ADDR, 2, &rawB3);
  const bool okB4 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD1_ADDR, 3, &rawB4);
  const bool okB5 = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD2_ADDR, 0, &rawB5);

  if (!(okB1 && okB2 && okB3 && okB4 && okB5)) return false;

  const int b1_mV = snapack_ads_47k18k_tap_mV(rawB1);
  const int b2_mV = snapack_ads_47k18k_tap_mV(rawB2);
  const int b3_mV = snapack_ads_47k18k_tap_mV(rawB3);
  const int b4_mV = snapack_ads_100k10k_source_mV(rawB4);
  const int b5_mV = snapack_ads_100k10k_source_mV(rawB5);

  const int cell1_mV = b1_mV;
  const int cell2_mV = b2_mV - b1_mV;
  const int cell3_mV = b3_mV - b2_mV;
  const int cell4_mV = b4_mV - b3_mV;
  const int cell5_mV = b5_mV - b4_mV;

  const bool monotonic =
      b1_mV >= 0 && b2_mV >= b1_mV && b3_mV >= b2_mV &&
      b4_mV >= b3_mV && b5_mV >= b4_mV;

  const bool cellsPlausible =
      cell1_mV >= 1500 && cell1_mV <= 4500 &&
      cell2_mV >= 1500 && cell2_mV <= 4500 &&
      cell3_mV >= 1500 && cell3_mV <= 4500 &&
      cell4_mV >= 1500 && cell4_mV <= 4500 &&
      cell5_mV >= 1500 && cell5_mV <= 4500;

  if (!monotonic || !cellsPlausible) {
    static unsigned long lastDetail = 0;
    if (millis() - lastDetail >= 2000) {
      lastDetail = millis();
      Serial.printf("CELL REJECT detail B1=%dmV B2=%dmV B3=%dmV B4=%dmV B5=%dmV | C=%d,%d,%d,%d,%dmV\n",
                    b1_mV,b2_mV,b3_mV,b4_mV,b5_mV,
                    cell1_mV,cell2_mV,cell3_mV,cell4_mV,cell5_mV);
    }
    return false;
  }

  ui_update_snapack_cells(cell1_mV, cell2_mV, cell3_mV,
                          cell4_mV, cell5_mV, b5_mV);

  snapackDiagPack_mV = b5_mV;
  snapackDiag4SPack_mV = b4_mV;
  snapackDiagLowCell_mV = cell1_mV;
  if (cell2_mV < snapackDiagLowCell_mV) snapackDiagLowCell_mV = cell2_mV;
  if (cell3_mV < snapackDiagLowCell_mV) snapackDiagLowCell_mV = cell3_mV;
  if (cell4_mV < snapackDiagLowCell_mV) snapackDiagLowCell_mV = cell4_mV;
  if (cell5_mV < snapackDiagLowCell_mV) snapackDiagLowCell_mV = cell5_mV;
  snapack_push_diag_ui_throttled();
  return true;
}

static void snapack_service_real_cells()
{
  if (!SNAPACK_REAL_CELLS_ENABLED) return;

  const unsigned long now = millis();

  if (now - snapackLastCellReadMs < SNAPACK_CELL_REFRESH_MS) {
    return;
  }

  snapackLastCellReadMs = now;

  if (!snapack_read_real_cells_once()) {
    if (now - snapackLastCellErrorPrintMs >= 2000) {
      snapackLastCellErrorPrintMs = now;
      Serial.println(
          "SNAPACK real-cell read not accepted; "
          "keeping last valid Cell Voltage display");
    }
  }
}


// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// SNAPACK ADS1115 RAW DIAGNOSTICS
// ---------------------------------------------------------------------
//
// Independent diagnostic pass.  A dead/miswired cell channel does NOT stop
// Board 2 or Board 3 from being read.
//
// Current authoritative map:
//
// Board 1 — 0x48
//   A0..A3 = four cumulative taps for the 4-cell / 12 V group
//   Exact post-shuffle A-channel order is intentionally NOT assumed here.
//   Serial prints A0..A3 neutrally so the actual voltage staircase can reveal
//   the present wiring order.
//
// Board 2 — 0x49
//   A0 = B5
//   A1 = Final Output +
//   A2 = OTC Current analog node
//   A3 = Final Output -
//
// Board 3 — 0x4A
//   A0 = 24 V rail monitor
//   A1 = CdS / ambient light
//   A2 = spare
//   A3 = spare
//
// Expected CdS observation from the actual hardware:
//   shade  ~0.5 V
//   light  >2.0 V

static const unsigned long SNAPACK_ADS_DIAG_MS = 2000;
static unsigned long snapackLastAdsDiagMs = 0;

static const unsigned long SNAPACK_I2C_SCAN_MS = 10000;
static unsigned long snapackLastI2cScanMs = 0;

// STEP 27 OTC development calibration.
// First 8 valid zero-current samples establish a temporary baseline.
// Provisional sensitivity under test: 1 mV per amp.
static const uint8_t SNAPACK_OTC_ZERO_SAMPLES = 8;
static int32_t snapackOtcZeroSum_mV = 0;
static uint8_t snapackOtcZeroCount = 0;
static int snapackOtcZero_mV = 0;
static bool snapackOtcZeroReady = false;


// STEP 35 current capture / diagnostic state.
// Fast OTC samples remain RAM-only; no flash history is written yet.
static const unsigned long SNAPACK_OTC_FAST_MS = 20;      // ~50 samples/s target
static unsigned long snapackLastOtcFastMs = 0;
static const int SNAPACK_EVENT_START_A = 12;
static const int SNAPACK_EVENT_END_A = 5;
static const unsigned long SNAPACK_EVENT_END_HOLD_MS = 500;

static bool snapackCurrentEventActive = false;
static unsigned long snapackCurrentBelowSinceMs = 0;
static int snapackCurrentEventPeak_A = 0;
static int snapackLastEventPeak_A = 0;
static int snapackSessionPeak_A = 0;
static int snapackLiveCurrent_A = 0;
static int snapackFilteredSignedCurrent_A = 0;
static bool snapackCurrentFilterSeeded = false;
static int snapackLastAcceptedRawSignedA = 0;
static bool snapackLargeStepPending = false;
static int snapackLargeStepCandidateA = 0;
static uint8_t snapackEventStartConfirmCount = 0;
static const uint8_t SNAPACK_EVENT_START_CONFIRM_SAMPLES = 3;
static unsigned long snapackLastCurrentUiMs = 0;
static unsigned long snapackLastDiagUiMs = 0;
static const unsigned long SNAPACK_CURRENT_UI_MS = 100;
static const unsigned long SNAPACK_DIAG_UI_MS = 100;


static void snapack_push_diag_ui_now()
{
  ui_update_snapack_diagnostics(snapackDiag24Rail_mV,
                                snapackLastEventPeak_A,
                                snapackSessionPeak_A,
                                snapackDiagPack_mV,
                                snapackDiag4SPack_mV,
                                snapackDiagLowCell_mV);
}

static void snapack_push_diag_ui_throttled()
{
  const unsigned long now = millis();
  if (now - snapackLastDiagUiMs < SNAPACK_DIAG_UI_MS) return;
  snapackLastDiagUiMs = now;
  snapack_push_diag_ui_now();
}

static void snapack_process_current_sample(int signed_current_A)
{
  // STEP 47 raw-spike guard:
  // A very large jump from near-idle must appear twice before entering the EMA.
  // This prevents one corrupt ADS/I2C sample from charging the filter to
  // hundreds of amps for several subsequent samples.
  const int jump = abs(signed_current_A - snapackLastAcceptedRawSignedA);
  if (abs(snapackLastAcceptedRawSignedA) < 25 && abs(signed_current_A) > 100 && jump > 100) {
    if (!snapackLargeStepPending) {
      snapackLargeStepPending = true;
      snapackLargeStepCandidateA = signed_current_A;
      Serial.printf("OTC transient candidate %dA; awaiting confirmation\\n", signed_current_A);
      return;
    }

    if ((signed_current_A > 0) == (snapackLargeStepCandidateA > 0) &&
        abs(signed_current_A - snapackLargeStepCandidateA) <= 75) {
      // A second similar sample confirms a real large event.
      snapackLargeStepPending = false;
    } else {
      Serial.printf("OTC transient rejected candidate=%dA next=%dA\\n",
                    snapackLargeStepCandidateA, signed_current_A);
      snapackLargeStepPending = false;
      return;
    }
  } else {
    snapackLargeStepPending = false;
  }

  snapackLastAcceptedRawSignedA = signed_current_A;
  // STEP 44: measurement/event logic runs fast; LVGL redraw runs at 10 Hz.
  if (!snapackCurrentFilterSeeded) {
    snapackFilteredSignedCurrent_A = signed_current_A;
    snapackCurrentFilterSeeded = true;
  } else {
    snapackFilteredSignedCurrent_A =
        (snapackFilteredSignedCurrent_A * 3 + signed_current_A) / 4;
  }

  const int filtered_signed_A = snapackFilteredSignedCurrent_A;
  const int current_A = filtered_signed_A < 0 ? -filtered_signed_A : filtered_signed_A;
  const unsigned long now = millis();

  snapackLiveCurrent_A = current_A;
  if (current_A > snapackSessionPeak_A) snapackSessionPeak_A = current_A;

  bool force_ui = false;

  if (!snapackCurrentEventActive) {
    if (current_A >= SNAPACK_EVENT_START_A) {
      if (snapackEventStartConfirmCount < SNAPACK_EVENT_START_CONFIRM_SAMPLES) {
        snapackEventStartConfirmCount++;
      }
    } else {
      snapackEventStartConfirmCount = 0;
    }

    if (snapackEventStartConfirmCount >= SNAPACK_EVENT_START_CONFIRM_SAMPLES) {
      snapackEventStartConfirmCount = 0;
      snapackCurrentEventActive = true;
      snapackCurrentEventPeak_A = current_A;
      snapackCurrentBelowSinceMs = 0;

      if (lv_scr_act() != ui_Screen7) {
        _ui_screen_change(&ui_Screen7, LV_SCR_LOAD_ANIM_FADE_ON, 120, 0, &ui_Screen7_screen_init);
      }

      force_ui = true;
      Serial.printf("CURRENT EVENT START signed=%dA filtered=%dA magnitude=%dA\n",
                    signed_current_A, filtered_signed_A, current_A);
    }
  } else {
    if (current_A > snapackCurrentEventPeak_A) {
      snapackCurrentEventPeak_A = current_A;
    }

    if (current_A <= SNAPACK_EVENT_END_A) {
      if (snapackCurrentBelowSinceMs == 0) snapackCurrentBelowSinceMs = now;
      if (now - snapackCurrentBelowSinceMs >= SNAPACK_EVENT_END_HOLD_MS) {
        snapackCurrentEventActive = false;
        snapackLastEventPeak_A = snapackCurrentEventPeak_A;
        snapackCurrentBelowSinceMs = 0;
        force_ui = true;
        Serial.printf("CURRENT EVENT END peak=%dA\n", snapackLastEventPeak_A);
      }
    } else {
      snapackCurrentBelowSinceMs = 0;
    }
  }

  if (force_ui || now - snapackLastCurrentUiMs >= SNAPACK_CURRENT_UI_MS) {
    snapackLastCurrentUiMs = now;
    ui_update_snapack_current(filtered_signed_A);
    ui_update_snapack_current_peak(
        snapackCurrentEventActive ? snapackCurrentEventPeak_A : snapackLastEventPeak_A);
  }

  snapack_push_diag_ui_throttled();
}

static void snapack_service_otc_fast()
{
  const unsigned long now = millis();
  if (now - snapackLastOtcFastMs < SNAPACK_OTC_FAST_MS) return;
  snapackLastOtcFastMs = now;

  int16_t raw = 0;
  if (!snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD2_ADDR, 2, &raw)) {
    return;
  }

  const int node_mV = snapack_ads_node_mV(raw);

  // STEP 46: fast OTC service now owns its own zero capture.
  // Step45 disabled the recurring ADS diagnostic sweep, which had previously
  // been the only place that accumulated the 8 zero-current baseline samples.
  if (!snapackOtcZeroReady) {
    snapackOtcZeroSum_mV += node_mV;
    snapackOtcZeroCount++;

    if (snapackOtcZeroCount >= SNAPACK_OTC_ZERO_SAMPLES) {
      snapackOtcZero_mV =
          (int)(snapackOtcZeroSum_mV / SNAPACK_OTC_ZERO_SAMPLES);
      snapackOtcZeroReady = true;
      snapackCurrentFilterSeeded = false;
      Serial.printf("OTC ZERO READY %dmV from %u samples\n",
                    snapackOtcZero_mV,
                    (unsigned)SNAPACK_OTC_ZERO_SAMPLES);
    }
    return;
  }

  const int deltaNode_mV = snapackOtcZero_mV - node_mV;
  // OTC divider = 10k upper / 22k lower: node/source = 22/32 = 11/16.
  // OTC itself is 1 mV/A, so restore source delta by multiplying 16/11.
  const int signed_A = (int)(((int32_t)deltaNode_mV * 16L + (deltaNode_mV >= 0 ? 5 : -5)) / 11L);
  snapack_process_current_sample(signed_A);
}


// ---------------------------------------------------------------------
// SNAPACK AMBIENT-LIGHT AUTOMATIC DAY/NIGHT THEME
// ---------------------------------------------------------------------
//
// Bench-mapped CdS range:
//   deep shadow: tens of mV
//   transition: hundreds of mV
//   bright light: ~1.8 V to >3.1 V
//
// Use two thresholds (hysteresis):
//   <= 500 mV  -> NIGHT candidate
//   >= 1500 mV -> DAY candidate
//   between    -> keep current theme
//
// Require three consecutive 500 ms samples (~1.5 s) before changing theme.
// This prevents a passing hand/shadow from flipping the display immediately.

static const int SNAPACK_CDS_NIGHT_MV = 500;
static const int SNAPACK_CDS_DAY_MV = 1500;
static const unsigned long SNAPACK_CDS_THEME_SAMPLE_MS = 500;
static const uint8_t SNAPACK_CDS_CONFIRM_SAMPLES = 3;

static unsigned long snapackLastCdsThemeSampleMs = 0;
static int8_t snapackThemeCandidate = -1;   // 0=night, 1=day, -1=none
static uint8_t snapackThemeCandidateCount = 0;
static bool snapackAutoThemeDay = false;

static void snapack_apply_auto_theme(bool day_mode)
{
  if (snapackAutoThemeDay == day_mode) return;

  snapackAutoThemeDay = day_mode;

  ui_set_snapack_carousel_theme(day_mode);
  ui_set_snapack_cell_theme(day_mode);
  ui_set_snapack_temp_theme(day_mode);
  ui_set_snapack_current_theme(day_mode);
  ui_set_snapack_diag_theme(day_mode);

  Serial.printf("AUTO THEME -> %s\n", day_mode ? "DAY" : "NIGHT");
}

static void snapack_service_ambient_theme()
{
  const unsigned long now = millis();
  if (now - snapackLastCdsThemeSampleMs < SNAPACK_CDS_THEME_SAMPLE_MS) return;
  snapackLastCdsThemeSampleMs = now;

  int16_t raw = 0;
  if (!snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD2_ADDR, 1, &raw)) {
    return;
  }

  const int cds_mV = snapack_ads_node_mV(raw);

  int8_t candidate = -1;
  if (cds_mV <= SNAPACK_CDS_NIGHT_MV) candidate = 0;
  else if (cds_mV >= SNAPACK_CDS_DAY_MV) candidate = 1;
  else {
    // Inside hysteresis band: hold current theme and cancel pending change.
    snapackThemeCandidate = -1;
    snapackThemeCandidateCount = 0;
    return;
  }

  if (candidate != snapackThemeCandidate) {
    snapackThemeCandidate = candidate;
    snapackThemeCandidateCount = 1;
    return;
  }

  if (snapackThemeCandidateCount < SNAPACK_CDS_CONFIRM_SAMPLES) {
    snapackThemeCandidateCount++;
  }

  if (snapackThemeCandidateCount >= SNAPACK_CDS_CONFIRM_SAMPLES) {
    snapack_apply_auto_theme(candidate == 1);
    snapackThemeCandidateCount = 0;
    snapackThemeCandidate = -1;
  }
}

static int snapack_24v_rail_mV_from_raw(int16_t raw)
{
  return snapack_ads_100k10k_source_mV(raw);
}

static void snapack_print_diag_channel(const char *label,
                                       bool ok,
                                       int16_t raw,
                                       int converted_mV)
{
  if (ok) {
    Serial.printf("%s raw=%d converted=%dmV", label, raw, converted_mV);
  } else {
    Serial.printf("%s READ_FAIL", label);
  }
}

static void snapack_scan_i2c_bus()
{
  Serial.println();
  Serial.println("------------- I2C ADDRESS SCAN -------------");

  int found = 0;

  for (uint8_t address = 1; address < 127; address++) {
    Wire.beginTransmission(address);
    uint8_t error = Wire.endTransmission();

    if (error == 0) {
      Serial.printf("I2C device found at 0x%02X\n", address);
      found++;
    }
  }

  if (found == 0) {
    Serial.println("No I2C devices found.");
  }

  Serial.println("--------------------------------------------");
}

static void snapack_service_ads_diagnostics()
{
  const unsigned long now = millis();
  if (now - snapackLastAdsDiagMs < SNAPACK_ADS_DIAG_MS) return;
  snapackLastAdsDiagMs = now;

  int16_t a[8] = {0}; bool ok[8] = {0};
  for (uint8_t ch=0; ch<4; ch++) ok[ch] = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD1_ADDR,ch,&a[ch]);
  for (uint8_t ch=0; ch<4; ch++) ok[4+ch] = snapack_ads_read_single_ended_settled(SNAPACK_ADS_BOARD2_ADDR,ch,&a[4+ch]);

  Serial.println();
  Serial.println("========== SNAPACK 3.3V REBUILD LIVE ==========");
  Serial.printf("ADS1 0x48 | B1=%dmV | B2=%dmV | B3=%dmV | B4=%dmV\n",
      ok[0]?snapack_ads_47k18k_tap_mV(a[0]):-1, ok[1]?snapack_ads_47k18k_tap_mV(a[1]):-1,
      ok[2]?snapack_ads_47k18k_tap_mV(a[2]):-1, ok[3]?snapack_ads_100k10k_source_mV(a[3]):-1);

  const int b5 = ok[4]?snapack_ads_100k10k_source_mV(a[4]):-1;
  const int cds = ok[5]?snapack_ads_node_mV(a[5]):-1;
  const int otcNode = ok[6]?snapack_ads_node_mV(a[6]):-1;
  const int rail24 = ok[7]?snapack_24v_rail_mV_from_raw(a[7]):-1;
  if (rail24 >= 0) snapackDiag24Rail_mV = rail24;
  Serial.printf("ADS2 0x49 | B5=%dmV | CDS=%dmV | OTC_NODE=%dmV | 24V=%dmV\n", b5,cds,otcNode,rail24);
  if (snapackOtcZeroReady) Serial.printf("OTC auto-zero node=%dmV | live current=%+dA\n", snapackOtcZero_mV, snapackLiveCurrent_A);
  else Serial.printf("OTC auto-zero capture %u/%u\n", (unsigned)snapackOtcZeroCount, (unsigned)SNAPACK_OTC_ZERO_SAMPLES);
  Serial.println("================================================");
}


// SNAPACK SIMULATED TEMPERATURE DATA
// ---------------------------------------------------------------------
//
// Temperatures are stored in tenths of a degree Fahrenheit.  The average is
// calculated here in the application layer rather than inside the UI.
//
// Later this function can be replaced by the five real sensor readings while
// ui_update_snapack_temperatures() and Screen6 remain unchanged.
void loadSnapackSimulatedTemperatureData() {
  const int temp1_dF = 721;  // 72.1 F
  const int temp2_dF = 744;  // 74.4 F
  const int temp3_dF = 733;  // 73.3 F
  const int temp4_dF = 758;  // 75.8 F
  const int temp5_dF = 726;  // 72.6 F

  const int avg_dF =
      (temp1_dF +
       temp2_dF +
       temp3_dF +
       temp4_dF +
       temp5_dF) / 5;

  ui_update_snapack_temperatures(temp1_dF,
                                 temp2_dF,
                                 temp3_dF,
                                 temp4_dF,
                                 temp5_dF,
                                 avg_dF);
}



// ---------------------------------------------------------------------
// SNAPACK SIMULATED CURRENT DATA
// ---------------------------------------------------------------------
//
// Whole amps are sufficient for the first cranking/current display pass.
// Replace this source later with the real current-clamp acquisition path.
void loadSnapackSimulatedCurrentData() {
  const int current_A = 187;
  ui_update_snapack_current(current_A);
}



// ---------------------------------------------------------------------
// SNAPACK TEMPERATURE — DS2484 I2C-TO-1-WIRE BRING-UP
// One-sensor diagnostic pass. Conversion is deliberately NON-BLOCKING so the
// LVGL/ring/touch loop never sits through the DS18B20 conversion interval.
// After each completed conversion, print the 9 scratchpad bytes.  An all-zero
// scratchpad is rejected even though its CRC would otherwise appear valid.
static const uint8_t SNAPACK_DS2484_ADDR = 0x18;
static const unsigned long SNAPACK_TEMP_REFRESH_MS = 2000;
static const unsigned long SNAPACK_TEMP_CONVERT_MS = 800;
static unsigned long snapackLastTempCycleMs = 0;
static unsigned long snapackTempConvertStartedMs = 0;
static bool snapackDs2484Ready = false;
static bool snapackTempConversionPending = false;

static bool snapack_ds2484_write2(uint8_t cmd, uint8_t data)
{
  Wire.beginTransmission(SNAPACK_DS2484_ADDR);
  Wire.write(cmd); Wire.write(data);
  return Wire.endTransmission() == 0;
}
static bool snapack_ds2484_command(uint8_t cmd)
{
  Wire.beginTransmission(SNAPACK_DS2484_ADDR); Wire.write(cmd);
  return Wire.endTransmission() == 0;
}
static bool snapack_ds2484_read_reg(uint8_t ptr, uint8_t *value)
{
  if (!value) return false;
  Wire.beginTransmission(SNAPACK_DS2484_ADDR); Wire.write(0xE1); Wire.write(ptr);
  if (Wire.endTransmission() != 0) return false;
  if (Wire.requestFrom((int)SNAPACK_DS2484_ADDR,1) != 1) return false;
  *value = Wire.read(); return true;
}
static bool snapack_ds2484_wait(uint8_t *statusOut=nullptr)
{
  const unsigned long started=millis();
  while (millis()-started < 20) {
    uint8_t st=0;
    if (!snapack_ds2484_read_reg(0xF0,&st)) return false;
    if (!(st & 0x01)) { if(statusOut)*statusOut=st; return true; }
    delay(1);
  }
  return false;
}
static bool snapack_ds2484_1w_reset()
{
  if (!snapack_ds2484_command(0xB4)) return false;
  uint8_t st=0; if(!snapack_ds2484_wait(&st)) return false;
  return (st & 0x02) != 0;
}
static bool snapack_ds2484_1w_write(uint8_t b)
{
  if (!snapack_ds2484_write2(0xA5,b)) return false;
  return snapack_ds2484_wait();
}
static bool snapack_ds2484_1w_read(uint8_t *b)
{
  if (!b || !snapack_ds2484_command(0x96) || !snapack_ds2484_wait()) return false;
  return snapack_ds2484_read_reg(0xE1,b);
}
static bool snapack_ds2484_begin()
{
  if (!snapack_i2c_device_present(SNAPACK_DS2484_ADDR)) return false;
  if (!snapack_ds2484_command(0xF0)) return false;
  delay(2);
  if (!snapack_ds2484_write2(0xD2,0xE1)) return false;
  delay(2);
  return snapack_ds2484_1w_reset();
}
static uint8_t snapack_crc8(const uint8_t *data, uint8_t len)
{
  uint8_t crc=0;
  while(len--) { uint8_t in=*data++; for(uint8_t i=8;i;i--){ uint8_t mix=(crc^in)&1; crc>>=1; if(mix)crc^=0x8C; in>>=1; } }
  return crc;
}
static bool snapack_ds2484_start_single_conversion()
{
  if (!snapack_ds2484_1w_reset()) return false;
  return snapack_ds2484_1w_write(0xCC) && snapack_ds2484_1w_write(0x44);
}
static bool snapack_ds2484_read_single_scratchpad(uint8_t sp[9])
{
  if (!sp || !snapack_ds2484_1w_reset()) return false;
  if (!snapack_ds2484_1w_write(0xCC) || !snapack_ds2484_1w_write(0xBE)) return false;
  for(uint8_t i=0;i<9;i++) if(!snapack_ds2484_1w_read(&sp[i])) return false;
  return true;
}
static bool snapack_ds18b20_scratchpad_to_dF(const uint8_t sp[9], int *out_dF)
{
  if (!sp || !out_dF) return false;
  bool allZero=true;
  for(uint8_t i=0;i<9;i++) if(sp[i]!=0) { allZero=false; break; }
  if(allZero) return false;
  if(snapack_crc8(sp,8) != sp[8]) return false;
  int16_t raw=(int16_t)(((uint16_t)sp[1]<<8)|sp[0]);
  *out_dF=(int)(((int32_t)raw*9L + (raw>=0?40:-40))/80L + 320L);
  return true;
}
static void snapack_print_temp_scratchpad(const uint8_t sp[9])
{
  Serial.print("DS2484 TEMP1 scratchpad:");
  for(uint8_t i=0;i<9;i++) Serial.printf(" %02X",sp[i]);
  Serial.println();
}
static void snapack_service_temperatures()
{
  const unsigned long now=millis();
  const int NA=-32768;

  if(!snapackDs2484Ready) {
    if(now-snapackLastTempCycleMs < SNAPACK_TEMP_REFRESH_MS) return;
    snapackLastTempCycleMs=now;
    snapackDs2484Ready=snapack_ds2484_begin();
    if(!snapackDs2484Ready) {
      Serial.println("DS2484 TEMP: bridge/1-Wire presence not ready");
      ui_update_snapack_temperatures(NA,NA,NA,NA,NA,NA);
      return;
    }
  }

  if(!snapackTempConversionPending) {
    if(now-snapackLastTempCycleMs < SNAPACK_TEMP_REFRESH_MS) return;
    snapackLastTempCycleMs=now;
    if(!snapack_ds2484_start_single_conversion()) {
      Serial.println("DS2484 TEMP: conversion start failed");
      snapackDs2484Ready=false;
      ui_update_snapack_temperatures(NA,NA,NA,NA,NA,NA);
      return;
    }
    snapackTempConvertStartedMs=now;
    snapackTempConversionPending=true;
    return; // critical: return to LVGL immediately; do not wait here
  }

  if(now-snapackTempConvertStartedMs < SNAPACK_TEMP_CONVERT_MS) return;
  snapackTempConversionPending=false;

  uint8_t sp[9]={0};
  if(!snapack_ds2484_read_single_scratchpad(sp)) {
    Serial.println("DS2484 TEMP: scratchpad read failed");
    snapackDs2484Ready=false;
    ui_update_snapack_temperatures(NA,NA,NA,NA,NA,NA);
    return;
  }

  snapack_print_temp_scratchpad(sp);
  int t=NA;
  if(snapack_ds18b20_scratchpad_to_dF(sp,&t)) {
    Serial.printf("DS2484 TEMP1 = %.1f F\n",t/10.0f);
    ui_update_snapack_temperatures(t,NA,NA,NA,NA,t);
  } else {
    Serial.println("DS2484 TEMP: INVALID scratchpad (all-zero or CRC failure)");
    ui_update_snapack_temperatures(NA,NA,NA,NA,NA,NA);
  }
}


bool snapack_carousel_swipe_consumed(void)
{
  return millis() < carouselSwipeBlockUntilMs;
}

void setup() {
  Serial.begin(115200);
  // STEP 44: native OneWire fully dormant pending DS2484.
  Serial.println("TEMP: DS2484 present; periodic 1-Wire traffic DISABLED for Step65 isolation test");
 /* prepare for possible serial debug */
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
  // STEP 45: one boot-time I2C inventory only; no recurring scans.
  snapack_scan_i2c_bus();
  pcf8574.pinMode(P0, OUTPUT);        //tp RST
  pcf8574.pinMode(P2, OUTPUT);        //tp INT
  pcf8574.pinMode(P3, OUTPUT);        //lcd power
  pcf8574.pinMode(P4, OUTPUT);        //lcd reset
  pcf8574.pinMode(P5, INPUT_PULLUP);  //encoder SW

  Serial.print("Init pcf8574...\n");
  if (pcf8574.begin()) {
    Serial.println("pcf8574 OK");
  } else {
    Serial.println("pcf8574 KO");
  }

  pcf8574.digitalWrite(P3, HIGH);
  delay(100);

  /*lcd reset*/
  pcf8574.digitalWrite(P4, HIGH);
  delay(100);
  pcf8574.digitalWrite(P4, LOW);
  delay(120);
  pcf8574.digitalWrite(P4, HIGH);
  delay(120);
  /*end*/

  /*tp RST*/
  pcf8574.digitalWrite(P0, HIGH);
  delay(100);
  pcf8574.digitalWrite(P0, LOW);
  delay(120);
  pcf8574.digitalWrite(P0, HIGH);
  delay(120);
  /*tp INT*/
  pcf8574.digitalWrite(P2, HIGH);
  delay(120);

  gfx->begin();
  gfx->fillScreen(BLACK);
  gfx->setTextSize(2);
  gfx->setCursor(80, 100);

  if (!tsPanel.begin(&Wire, I2C_TOUCH_ADDR)) {
    Serial.println("No touchscreen found");
  } else {
    Serial.println("Touchscreen found");
  }

  pinMode(ENCODER_A_PIN, INPUT);
  pinMode(ENCODER_B_PIN, INPUT);
  lastA = digitalRead(ENCODER_A_PIN);

  lv_init();
  size_t buffer_size = sizeof(lv_color_t) * screenWidth * screenHeight;
  buf1 = (lv_color_t *)heap_caps_malloc(buffer_size, MALLOC_CAP_SPIRAM);
  buf2 = (lv_color_t *)heap_caps_malloc(buffer_size, MALLOC_CAP_SPIRAM);
  if (!buf1)
    Serial.println("Failed to allocate for LVGL---1---");
  if (!buf2)
    Serial.println("Failed to allocate for LVGL---2---");
  lv_disp_draw_buf_init(&draw_buf, buf1, buf2, screenWidth * screenHeight);

  /*Initialize the display*/
  static lv_disp_drv_t disp_drv;
  lv_disp_drv_init(&disp_drv);
  /*Change the following line to your display resolution*/
  disp_drv.hor_res = screenWidth;
  disp_drv.ver_res = screenHeight;
  disp_drv.flush_cb = my_disp_flush;
  disp_drv.draw_buf = &draw_buf;
  disp_drv.direct_mode = 0;
  disp_drv.full_refresh = 0; 
  disp_drv.sw_rotate = 0;
  disp_drv.screen_transp = 0;
  lv_disp_drv_register(&disp_drv);

  /*Initialize the (dummy) input device driver*/
  static lv_indev_drv_t indev_drv;
  lv_indev_drv_init(&indev_drv);
  indev_drv.type = LV_INDEV_TYPE_POINTER;
  indev_drv.read_cb = my_touchpad_read;
  lv_indev_drv_register(&indev_drv);

  /*Or try out a demo. Don't forget to enable the demos in lv_conf.h. E.g. LV_USE_DEMOS_WIDGETS*/
  // lv_demo_widgets();
  snapackPrefs.begin("snapack-ui", false);
  snapackSavedVolume = snapackPrefs.getUChar("volume", 50);
  snapackSavedTemp   = snapackPrefs.getUChar("temp", 50);
  snapackSavedLight  = snapackPrefs.getUChar("light", 50);

  ui_init();

  lv_arc_set_value(ui_VolumeArc, snapackSavedVolume);
  volumeValue = snapackSavedVolume;
  lv_arc_set_value(ui_TempArc, snapackSavedTemp);
  {
    char tempText[8];
    snprintf(tempText, sizeof(tempText), "%d° F", snapackSavedTemp);
    lv_label_set_text(ui_TempNum, tempText);
  }
  lv_arc_set_value(ui_lightArc, snapackSavedLight);
  lightValue = snapackSavedLight;
  ui_set_snapack_carousel_temp_color(snapackSavedTemp);
  snapack_apply_ring_speed(snapackSavedVolume);

  // The temporary persistent SNAPACK marker is retired here.
  // The new carousel entry and Screen5 now identify our modified firmware.
  updateScreen(screen1_index);

  // Seed Cell Voltage with known-good development values.
  // A complete sane ADS1115 frame will replace these automatically.
  loadSnapackSimulatedCellData();

  // Bind the volume slider value-change event
  lv_obj_add_event_cb(ui_VolumeArc, volumeArcEventCb, LV_EVENT_VALUE_CHANGED, NULL);
  // Bind the temperature slider value-change event
  lv_obj_add_event_cb(ui_TempArc, tempArcEventCb, LV_EVENT_VALUE_CHANGED, NULL);

  delay(200);
  initBacklight();
  pcf8574.digitalWrite(P3, LOW);

  // Initialize pin 43 as the LED PWM output
  ledcSetup(breathPwmChannel, pwmFreq, pwmResolution);
  ledcAttachPin(BREATH_LED_PIN, breathPwmChannel);
  // At startup, do not breathe; hold brightness corresponding to the current value
  ledcWrite(breathPwmChannel, (volumeValue * 255) / 100);

  xTaskCreatePinnedToCore(encTask, "ENC", 2048, NULL, 1, &encTaskHandle, 0);
  // STEP 47: do NOT run PCF8574 switch polling on another core.
  // PCF8574, touch controller and ADS1115s share the same Wire/I2C bus.
  // Switch polling is serviced cooperatively from loop() instead.

  // Initialize remote LED-strip control state
  Serial.println("Initializing remote LED-strip control...");
  lastLedCountSent = -1;
  Serial.println("Remote LED-strip control initialization complete");

  Serial.println("Settings completed, ready to connect to WiFi...");
  connectWiFi();

  // After WiFi connects, obtain the Advance device IP address
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("WiFi connected; preparing UDP communication...");
    Serial.print("Local IP address: ");
    Serial.println(WiFi.localIP());
  }
}

static void snapack_service_rotary_switch()
{
  // STEP 61: debounce and interpret physical presses here in the main loop.
  // This avoids losing the first press while waiting for encTask to observe
  // a second queued press.
  static uint8_t stableState = HIGH;
  static uint8_t lastRaw = HIGH;
  static unsigned long rawChangedMs = 0;
  static unsigned long firstPressMs = 0;
  static bool waitingSecond = false;
  const unsigned long now = millis();

  uint8_t raw = pcf8574.digitalRead(P5, true);
  if (raw != lastRaw) {
    lastRaw = raw;
    rawChangedMs = now;
  }

  if (raw != stableState && now - rawChangedMs >= 20) {
    stableState = raw;
    if (stableState == LOW) {
      lv_obj_t *screen = lv_scr_act();

      if (screen == ui_Screen1) {
        // Carousel remains immediate: one push selects.
        performClickAction();
        waitingSecond = false;
      } else if (waitingSecond && (now - firstPressMs <= 420)) {
        // Any sub-screen: second push is escape.
        performDoubleClickAction();
        waitingSecond = false;
      } else {
        firstPressMs = now;
        waitingSecond = true;
      }
    }
  }

  if (waitingSecond && now - firstPressMs > 420) {
    waitingSecond = false; // lone sub-screen press intentionally does nothing
  }
}

void loop() {
  lv_timer_handler();

  // STEP 47: serialized PCF8574 switch polling on the main loop/I2C owner.
  snapack_service_rotary_switch();

  // Fast, lightweight ambient-light theme service.
  snapack_service_ambient_theme();

  // Fast OTC sampling for live display and event peak capture.
  snapack_service_otc_fast();

  // STEP 53: synchronized non-blocking perimeter animations.
  ui_service_snapack_carousel_ring();
  ui_service_snapack_voltage_ring();
  ui_service_snapack_temperature_ring();
  ui_service_snapack_diag_animation();

  // First live SNAPACK hardware-data service.
  snapack_service_real_cells();

  // Heavy repeating ADS diagnostic dump disabled after successful 3.3-V bring-up.
  // snapack_service_ads_diagnostics();

  // DS2484 one-sensor temperature bring-up.
  // STEP65 isolation test: periodic DS2484/1-Wire transactions intentionally disabled.
  // snapack_service_temperatures();

  delay(5);
}

// Send the commanded number of illuminated LEDs to the Advance device
void sendLedStripCommand(int ledCount) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi not connected; cannot send LED-strip command");
    return;
  }

  ledCount = constrain(ledCount, 0, REMOTE_NUM_LEDS);
  String command = "LEDCOUNT:" + String(ledCount);
  udp.beginPacket(ADVANCE_IP, ADVANCE_PORT);
  udp.write((uint8_t*)command.c_str(), command.length());
  bool sent = udp.endPacket();
  if (sent) {
    Serial.printf("LED-strip command sent successfully: %s\n", command.c_str());
  } else {
    Serial.println("LED-strip command failed to send");
  }
}

// Map the temperature value and control the WS2812 LED strip on Advance
void updateLedStripByTemperature(int temp) {
  temp = constrain(temp, 0, 200);
  int ledCount = map(temp, 0, 200, 0, REMOTE_NUM_LEDS);
  if (ledCount == lastLedCountSent) return;
  lastLedCountSent = ledCount;
  sendLedStripCommand(ledCount);
  Serial.printf("Temperature: %d -> Illuminated LED count: %d\n", temp, ledCount);
}

// Volume-slider event: update the value and send it to Advance via UDP
void volumeArcEventCb(lv_event_t *e) {
  if (lv_event_get_code(e) != LV_EVENT_VALUE_CHANGED) return;
  lv_obj_t *arc = lv_event_get_target(e);
  int value = lv_arc_get_value(arc); // 0-100

  // Update UI text using the same format as the rotary-control logic
  char volText[8];
  if (value == 100) {
    snprintf(volText, sizeof(volText), "%d%%", value);
    lv_label_set_text(ui_VolNum, volText);
  } else {
    snprintf(volText, sizeof(volText), " %d%%", value);
    lv_label_set_text(ui_VolNum, volText);
  }
  // Set LED brightness directly to the corresponding duty cycle
  volumeValue = value;
  ledcWrite(breathPwmChannel, (volumeValue * 255) / 100);
  snapack_apply_ring_speed(volumeValue);
  Serial.printf("RING SPEED volume=%d%%\n", volumeValue);
  snapack_save_ui_settings();
}


// Temperature-slider event: update temperature text and control the servo
void tempArcEventCb(lv_event_t *e) {
  if (lv_event_get_code(e) != LV_EVENT_VALUE_CHANGED) return;
  lv_obj_t *arc = lv_event_get_target(e);
  int value = lv_arc_get_value(arc); // 0-200

  // Update temperature text (using the existing format)
  char tempText[8];
  snprintf(tempText, sizeof(tempText), "%d° F", value);
  lv_label_set_text(ui_TempNum, tempText);

  // Control the remote LED strip (map 0-200 to 0-15 LEDs)
  updateLedStripByTemperature(value);

  // STEP 50: factory Temp control previews solid SNAPACK carousel color.
  ui_set_snapack_carousel_temp_color(value);
  snapack_save_ui_settings();
}


int last_counter = 0;
int counter = 0;
int currentStateCLK;
int lastStateCLK;
String currentDir = "";
bool one_test = false;

void performClickAction() {
  current_screen = lv_scr_act();

  // Seven carousel destinations now exist.  The OEM screens are retained
  // unchanged and shifted one index to make room for SNAPACK at index 0.
  if (current_screen == ui_Screen1) {
    if (screen1_index == 0) {
      _ui_screen_change(&ui_Screen5, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen5_screen_init);
    } else if (screen1_index == 1) {
      _ui_screen_change(&ui_Screen6, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen6_screen_init);
    } else if (screen1_index == 2) {
      _ui_screen_change(&ui_Screen7, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen7_screen_init);
    } else if (screen1_index == 3) {
      _ui_screen_change(&ui_Screen8, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen8_screen_init);
    } else if (screen1_index == 4) {
      _ui_screen_change(&ui_Screen2, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen2_screen_init);
      // STEP 58: Screen2's OEM initializer restores its 50% placeholder.
      // Re-apply the actual sticky SNAPACK value after entering the screen.
      lv_arc_set_value(ui_VolumeArc, volumeValue);
      char volText[8];
      snprintf(volText, sizeof(volText), "%d%%", volumeValue);
      lv_label_set_text(ui_VolNum, volText);
    } else if (screen1_index == 5) {
      _ui_screen_change(&ui_Screen3, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen3_screen_init);
    } else if (screen1_index == 6) {
      _ui_screen_change(&ui_Screen4, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen4_screen_init);
    }
  }
}

void performDoubleClickAction() {
  current_screen = lv_scr_act();

  // STEP 62: universal physical-knob double-click escape.
  // If we are anywhere except the Carousel itself, return to Carousel.
  // This avoids maintaining a fragile per-screen allow-list.
  if (current_screen != ui_Screen1) {
    _ui_screen_change(&ui_Screen1, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_Screen1_screen_init);
  }
}

void processEncoder() {
  current_screen = lv_scr_act();

  if (current_screen == ui_Screen1) {
    // Seven carousel positions now exist: 0 through 6.
    if (position_tmp == 1) {
      screen1_index = (screen1_index + 1) % 7;
    } else if (position_tmp == 0) {
      screen1_index = (screen1_index + 5) % 7;
    }

    Serial.printf("cur_index: %d\n", screen1_index);
    updateScreen(screen1_index);
    position_tmp = -1;
  }
}

void encTask(void *pvParameters) {
  while (1) {
    // Read the current state of CLK
    currentStateCLK = digitalRead(ENCODER_A_PIN);
    // If last and current state of CLK are different, then pulse occurred
    // React to only 1 state change to avoid double count
    if (currentStateCLK != lastStateCLK && currentStateCLK == 1) {
      current_screen = lv_scr_act();
      // If the DT state is different than the CLK state then
      // the encoder is rotating CCW so decrement
      if (digitalRead(ENCODER_B_PIN) != currentStateCLK) {
        if (abs(last_counter - counter) > 200) {
          continue;
        }

        if (current_screen == ui_Screen2) {
          int currentVol = lv_arc_get_value(ui_VolumeArc);
          Serial.printf(" -- currentVol = %d\n", currentVol);
          int newVol = (currentVol - 5) < 0 ? 0 : currentVol - 5;
          Serial.printf(" -- END currentVol = %d\n", newVol);
          lv_arc_set_value(ui_VolumeArc, newVol);

          volumeValue = newVol; // Synchronize global volume

          char volText[8];
          if (newVol == 100) {
            snprintf(volText, sizeof(volText), "%d%%", newVol);
            lv_label_set_text(ui_VolNum, volText);
          } else {
            snprintf(volText, sizeof(volText), " %d%%", newVol);
            lv_label_set_text(ui_VolNum, volText);
          }

          // Set LED brightness directly
          ledcWrite(breathPwmChannel, (volumeValue * 255) / 100);
          snapack_apply_ring_speed(volumeValue);
          snapack_save_ui_settings();

        } else if (current_screen == ui_Screen3) {
          int currentTemp = lv_arc_get_value(ui_TempArc);
          Serial.printf(" -- currentVol = %d\n", currentTemp);
          int newTemp = (currentTemp - 5) < 0 ? 0 : currentTemp - 5;
          Serial.printf(" -- END currentVol = %d\n", newTemp);
          lv_arc_set_value(ui_TempArc, newTemp);
          ui_set_snapack_carousel_temp_color(newTemp);
          char TempText[8];
          if (newTemp >= 100 && newTemp <= 200) {
            snprintf(TempText, sizeof(TempText), "%d° F", newTemp);
            lv_label_set_text(ui_TempNum, TempText);
          } else {
            snprintf(TempText, sizeof(TempText), "%d° F", newTemp);
            lv_label_set_text(ui_TempNum, TempText);
          }

          // Update the remote LED strip
          updateLedStripByTemperature(newTemp);
          snapack_save_ui_settings();

        } else if (current_screen == ui_Screen4) {
          int currentLight = lv_arc_get_value(ui_lightArc);
          Serial.printf(" -- currentLight = %d\n", currentLight);
          int newLight = (currentLight - 5) < 0 ? 0 : currentLight - 5;
          Serial.printf(" -- END currentLight = %d\n", newLight);
          lv_arc_set_value(ui_lightArc, newLight);

          lightValue = newLight; // Synchronize global brightness

          char LightText[8];
          if (newLight == 100) {
            snprintf(LightText, sizeof(LightText), "%d%%", newLight);
            lv_label_set_text(ui_LightNum, LightText);
          } else {
            snprintf(LightText, sizeof(LightText), " %d%%", newLight);
            lv_label_set_text(ui_LightNum, LightText);
          }
          int pwm_value = (newLight * 255) / 100;
          ledcSetup(pwmChannel, pwmFreq, pwmResolution);
          ledcAttachPin(SCREEN_BACKLIGHT_PIN, pwmChannel);
          ledcWrite(pwmChannel, pwm_value);
          snapack_save_ui_settings();
        }
        position_tmp = 0;

        counter++;
        currentDir = "CCW"; // Counterclockwise
      } else {
        if (one_test == false)  
        {
          one_test = true;
          continue;
        }
        if (current_screen == ui_Screen2) {
          int currentVol = lv_arc_get_value(ui_VolumeArc);
          Serial.printf(" ++ currentVol = %d\n", currentVol);
          int newVol = (currentVol + 5) > 100 ? 100 : currentVol + 5;
          Serial.printf(" ++ END currentVol = %d\n", newVol);
          lv_arc_set_value(ui_VolumeArc, newVol);

          volumeValue = newVol; // Synchronize global volume

          char volText[8];
          if (newVol == 100) {
            snprintf(volText, sizeof(volText), "%d%%", newVol);
            lv_label_set_text(ui_VolNum, volText);
          } else {
            snprintf(volText, sizeof(volText), " %d%%", newVol);
            lv_label_set_text(ui_VolNum, volText);
          }

          // Set LED brightness directly
          ledcWrite(breathPwmChannel, (volumeValue * 255) / 100);
          snapack_apply_ring_speed(volumeValue);
          snapack_save_ui_settings();

        } else if (current_screen == ui_Screen3) {
          int currentTemp = lv_arc_get_value(ui_TempArc);
          Serial.printf(" ++ currentVol = %d\n", currentTemp);
          int newTemp = (currentTemp + 5) > 200 ? 200 : currentTemp + 5;
          Serial.printf(" ++ END currentVol = %d\n", newTemp);
          lv_arc_set_value(ui_TempArc, newTemp);
          ui_set_snapack_carousel_temp_color(newTemp);

          char TempText[8];
          if (newTemp >= 100 && newTemp <= 200) {
            snprintf(TempText, sizeof(TempText), "%d° F", newTemp);
            lv_label_set_text(ui_TempNum, TempText);
          } else {
            snprintf(TempText, sizeof(TempText), "%d° F", newTemp);
            lv_label_set_text(ui_TempNum, TempText);
          }

          // Update the remote LED strip
          updateLedStripByTemperature(newTemp);
          snapack_save_ui_settings();

        } else if (current_screen == ui_Screen4) {
          int currentLight = lv_arc_get_value(ui_lightArc);
          Serial.printf(" ++ currentLight = %d\n", currentLight);
          int newLight = (currentLight + 5) > 100 ? 100 : currentLight + 5;
          Serial.printf(" ++ END currentLight = %d\n", newLight);
          lv_arc_set_value(ui_lightArc, newLight);

          lightValue = newLight; // Synchronize global brightness

          char LightText[8];
          if (newLight == 100) {
            snprintf(LightText, sizeof(LightText), "%d%%", newLight);
            lv_label_set_text(ui_LightNum, LightText);
          } else {
            snprintf(LightText, sizeof(LightText), " %d%%", newLight);
            lv_label_set_text(ui_LightNum, LightText);
          }
          
          int pwm_value = (newLight * 255) / 100;
          ledcSetup(pwmChannel, pwmFreq, pwmResolution);
          ledcAttachPin(SCREEN_BACKLIGHT_PIN, pwmChannel);
          ledcWrite(pwmChannel, pwm_value);
          snapack_save_ui_settings();
        }
        position_tmp = 1;
        counter--;
        currentDir = "CW";
      }

      last_counter = counter;
      processEncoder();
    }

    // STEP 61: physical push is handled synchronously by
    // snapack_service_rotary_switch() in the main loop.
    // Remember last CLK state
    lastStateCLK = currentStateCLK;
    vTaskDelay(pdMS_TO_TICKS(2));
  }
}

void updateScreen(int index) {
  // STEP 35: seven-position circular carousel.
  // 0 Cell Voltage, 1 Temperature, 2 Current, 3 Diagnostic,
  // 4 OEM Volume, 5 OEM Temp, 6 OEM Light.
  if (index < 0) index = 0;
  if (index > 6) index = 6;
  screen1_index = index;

  // Hide all states first.
  lv_obj_t * all[] = {
    ui_snapackBlue, ui_snapackTextBlue, ui_snapackTextWhite,
    ui_snapackTempBlue, ui_snapackTempTextBlue, ui_snapackTempTextWhite,
    ui_snapackCurrentBlue, ui_snapackCurrentTextBlue, ui_snapackCurrentTextWhite,
    ui_snapackDiagBlue, ui_snapackDiagTextBlue, ui_snapackDiagTextWhite,
    ui_volumeBlue, ui_volumeWhite, ui_volumeTextBlue, ui_volumeTextWhite,
    ui_tempBlue, ui_tempWhite, ui_tempTextBlue, ui_tempTextWhite,
    ui_lightBlue, ui_lightWhite, ui_lightTextBlue, ui_lightTextWhite
  };
  for (unsigned i=0; i<sizeof(all)/sizeof(all[0]); i++) {
    if (all[i]) lv_obj_add_flag(all[i], LV_OBJ_FLAG_HIDDEN);
  }

  const int left  = (index + 6) % 7;
  const int right = (index + 1) % 7;

  // Helper macro: position selected/neighbor object families.
  #define POS3(B,TBLUE,TWHITE,X,SELECTED) do { \
      lv_obj_set_x((B),(X)); lv_obj_set_x((TBLUE),(X)); lv_obj_set_x((TWHITE),(X)); \
      /* Transparent custom button carries the placeholder icon as a child. */ \
      lv_obj_clear_flag((B),LV_OBJ_FLAG_HIDDEN); \
      if (SELECTED) { lv_obj_clear_flag((TBLUE),LV_OBJ_FLAG_HIDDEN); } \
      else { lv_obj_clear_flag((TWHITE),LV_OBJ_FLAG_HIDDEN); } \
    } while(0)

  #define POS4(B,W,TBLUE,TWHITE,X,SELECTED) do { \
      lv_obj_set_x((B),(X)); lv_obj_set_x((W),(X)); lv_obj_set_x((TBLUE),(X)); lv_obj_set_x((TWHITE),(X)); \
      if (SELECTED) { lv_obj_clear_flag((B),LV_OBJ_FLAG_HIDDEN); lv_obj_clear_flag((TBLUE),LV_OBJ_FLAG_HIDDEN); } \
      else { lv_obj_clear_flag((W),LV_OBJ_FLAG_HIDDEN); lv_obj_clear_flag((TWHITE),LV_OBJ_FLAG_HIDDEN); } \
    } while(0)

  for (int slot=0; slot<3; slot++) {
    const int item = (slot==0) ? left : ((slot==1) ? index : right);
    const int x = (slot==0) ? -140 : ((slot==1) ? 0 : 140);
    const bool selected = (slot==1);
    switch(item) {
      case 0: POS3(ui_snapackBlue,ui_snapackTextBlue,ui_snapackTextWhite,x,selected); break;
      case 1: POS3(ui_snapackTempBlue,ui_snapackTempTextBlue,ui_snapackTempTextWhite,x,selected); break;
      case 2: POS3(ui_snapackCurrentBlue,ui_snapackCurrentTextBlue,ui_snapackCurrentTextWhite,x,selected); break;
      case 3: POS3(ui_snapackDiagBlue,ui_snapackDiagTextBlue,ui_snapackDiagTextWhite,x,selected); break;
      case 4: POS4(ui_volumeBlue,ui_volumeWhite,ui_volumeTextBlue,ui_volumeTextWhite,x,selected); break;
      case 5: POS4(ui_tempBlue,ui_tempWhite,ui_tempTextBlue,ui_tempTextWhite,x,selected); break;
      case 6: POS4(ui_lightBlue,ui_lightWhite,ui_lightTextBlue,ui_lightTextWhite,x,selected); break;
    }
  }

  #undef POS3
  #undef POS4

  // STEP 51: selected item gets the current opposing accent;
  // off-center custom V/T/A/i icons remain white.
  ui_refresh_snapack_carousel_accent();
}

// Legacy OEM switch task retained for reference only; not created in setup.
void swTask(void *pvParameters) {
  while (1) {
    currentSW = pcf8574.digitalRead(P5, true);
    if (currentSW == LOW) {
      // Serial.printf("currentSW == LOW\n");
      static unsigned long lastInterruptTime = 0;
      unsigned long currentTime = millis();

      if (currentTime - lastInterruptTime > debounceTime) {
        pressCount++;
        pressedFlag = true;
        if (pressCount == 1) {
          singleClickTimeout = currentTime + doubleClickTime;
        }
      }
      lastInterruptTime = currentTime;
    }
    vTaskDelay(pdMS_TO_TICKS(5));
  }
}

