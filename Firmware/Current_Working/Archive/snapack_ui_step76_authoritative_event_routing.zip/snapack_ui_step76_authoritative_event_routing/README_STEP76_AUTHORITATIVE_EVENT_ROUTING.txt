SNAPACK UI STEP 76 - AUTHORITATIVE EVENT ROUTING
=================================================

STEP76 COMPILE-FIX NOTE
-----------------------
The authoritative-event owner enum now lives in snapack_event_types.h and is
included at the top of snapack.ino.  This avoids the Arduino sketch
preprocessor generating function prototypes that reference
snapack_event_owner_t before the type declaration is visible.
No event thresholds, ownership behavior, screen routing, or UI presentation
were changed by this compile-order fix.


PURPOSE
-------
Step 76 inserts a centralized authoritative-event arbiter before the planned
lazy/deferred screen-creation work. Step 75 editor geometry cleanup is retained.

The display is now routed by event class instead of forcing every abnormal
condition onto Current.

EVENT OWNERSHIP
---------------
The first active authoritative condition owns the most relevant screen while
that owning condition remains active:

  High-current event     -> Current screen
  Standalone thermal     -> Temperature screen
  Cell-voltage abnormal  -> Cell Voltage screen

A later event is recorded but does not steal the display from an owner that is
still active. If the owning event clears while another authoritative event is
still active, ownership transfers directly to a remaining event rather than
briefly returning to normal UI.

All authoritative states globally suspend decorative ring animation and normal
profile persistence work. User navigation away from an authoritative owner
screen is inhibited until authority clears.

CELL-VOLTAGE EVENT - PROVISIONAL NOTICE THRESHOLDS
--------------------------------------------------
These are early-warning/display thresholds, NOT final LiFePO4/BMS protection
cutoffs:

  ENTER LOW:   <= 2.700 V
  CLEAR LOW:   >= 2.850 V

  ENTER HIGH:  >= 3.600 V
  CLEAR HIGH:  <= 3.500 V

Three consecutive valid 500-ms cell frames are required to enter (~1.5 s).
Three consecutive clear frames are required to clear (~1.5 s).

All currently offending cells are highlighted, not only the first cell that
caused entry.

CELL AUTHORITATIVE PRESENTATION
-------------------------------
When Cell Voltage owns authority:

  - Cell Voltage screen is forced.
  - User-selected profile/day-night appearance is temporarily overridden.
  - Background is black.
  - Unaffected values remain white.
  - Offending cell values pulse red <-> white.
  - Perimeter image ring stops moving and is recolored solid semantic red.
  - Title changes to CELL ALERT.
  - Return/3-second parent navigation cannot dismiss the screen while active.

Normal user profile/theme is preserved underneath and restored after clear.

THERMAL AUTHORITATIVE PRESENTATION
----------------------------------
Existing Step 74 thermal thresholds remain provisional:

  Absolute enter: 130.0 F
  Absolute clear: 120.0 F
  Differential enter: 35.0 F spread sustained 30 s
  Differential clear: 25.0 F spread sustained 30 s

Standalone thermal abnormality now owns Temperature instead of Current.

  - Temperature screen is forced.
  - Background is black.
  - Affected probe(s) pulse red <-> white.
  - Differential-only event highlights the hottest probe.
  - Ring is frozen and recolored semantic red.
  - Title changes to THERMAL ALERT.

If Current already owns authority because a high-current event happened first,
a later thermal abnormality does NOT steal the screen. HOT temperature data
continues to be presented on Current as previously designed.

CURRENT EVENT
-------------
Current keeps the fixed high-contrast authoritative event presentation from
Step 74 when Current owns authority. Current remains fully profile-customizable
and animated during ordinary manually selected operation.

SEMANTIC RING
-------------
No new ring art was added. The proven image-mask ring is simply frozen on its
current frame and recolored red when Cell or Temperature owns authority. This
preserves the low-resource ring architecture.

RETURN/THEME INTERACTION
------------------------
The existing >=3 s physical press still performs one parent Return per physical
press/release cycle during normal operation.

While any authoritative event is active:
  - physical long-press escape is inhibited;
  - Cell/Temperature/Current Return controls cannot navigate away;
  - Return-button day/night long-hold does not silently alter the hidden normal
    theme underneath the fixed event presentation.

PHYSICAL TEST SUGGESTIONS
-------------------------
1. Flash with all cells inside the clear band and confirm normal behavior.
2. If a test cell is already >3.600 V, expect Cell Voltage to force after about
   three valid frames (~1.5 s).
3. Confirm every offending cell pulses and the ring stops/recolors red.
4. Confirm Return and >=3 s physical press cannot dismiss an active event.
5. Remove the abnormality and confirm clear only after hysteresis threshold and
   three clear frames, then confirm the previous normal profile is restored.
6. Thermal-event behavior may be bench-tested later with controlled sensor
   heating; do not change thresholds merely to make a quick test convenient.
7. Confirm a Current-first event remains on Current if thermal abnormality later
   appears.

NEXT PLANNED ARCHITECTURAL STEP
-------------------------------
Step 77: boot-priority restructuring / lazy screen creation.
Authoritative measurement/control paths plus Main and Current/event capability
must become available first; noncritical screens should be created afterward
only while electrically quiet.
