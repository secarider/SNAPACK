// SNAPACK SCREEN 5
//
// This is the first SNAPACK-owned measurement screen.
//
// STEP 2 PURPOSE:
//   Display six individual cell voltages first.
//   Display cumulative pack voltage after the six cells.
//   Prove that application data can be passed into the UI through one
//   clearly defined update function.
//
// IMPORTANT:
//   The values shown in this revision are SIMULATED TEST VALUES.
//   No ADS1115 data is being read yet.
//
// ARCHITECTURE:
//   snapack.ino owns measurement/application data.
//   This file owns presentation only.
//   ui_update_snapack_cells() is the boundary between those two jobs.
//
// Voltage values cross that boundary as integer millivolts rather than
// floating-point volts. Example:
//
//   4180 mV -> "4.180 V"
//
// This avoids unnecessary floating-point formatting in the UI layer and
// gives us a convenient representation for later ADC-derived values.

#include "ui.h"
#include <stdio.h>

// Format integer millivolts as X.XXX V.
static void snapack_set_voltage_label(lv_obj_t * label, int millivolts)
{
    char text[16];

    int volts = millivolts / 1000;
    int remainder_mV = millivolts % 1000;

    if (remainder_mV < 0) {
        remainder_mV = -remainder_mV;
    }

    snprintf(text, sizeof(text), "%d.%03d V", volts, remainder_mV);
    lv_label_set_text(label, text);
}

// Create one cell identifier and its independently updateable value label.
static lv_obj_t * snapack_create_cell_value(lv_obj_t * parent,
                                             const char * cell_name,
                                             int x,
                                             int y)
{
    lv_obj_t * name = lv_label_create(parent);
    lv_obj_set_width(name, LV_SIZE_CONTENT);
    lv_obj_set_height(name, LV_SIZE_CONTENT);
    lv_obj_set_x(name, x);
    lv_obj_set_y(name, y - 18);
    lv_obj_set_align(name, LV_ALIGN_CENTER);
    lv_label_set_text(name, cell_name);
    lv_obj_set_style_text_color(name, lv_color_hex(0xFFFFFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(name, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(name, &lv_font_montserrat_14, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_t * value = lv_label_create(parent);
    lv_obj_set_width(value, LV_SIZE_CONTENT);
    lv_obj_set_height(value, LV_SIZE_CONTENT);
    lv_obj_set_x(value, x);
    lv_obj_set_y(value, y + 8);
    lv_obj_set_align(value, LV_ALIGN_CENTER);
    lv_label_set_text(value, "0.000 V");
    lv_obj_set_style_text_color(value, lv_color_hex(0x33DCFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(value, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(value, &lv_font_montserrat_20, LV_PART_MAIN | LV_STATE_DEFAULT);

    return value;
}

// ---------------------------------------------------------------------
// PUBLIC DATA-TO-UI BOUNDARY
// ---------------------------------------------------------------------
//
// Application code calls this whenever fresh measurements are available.
// It does not need to know coordinates, fonts, colors, or layout.
//
// In this revision snapack.ino calls it once with simulated values.
// Later the exact same interface can receive real ADS1115-derived values.
void ui_update_snapack_cells(int cell1_mV,
                             int cell2_mV,
                             int cell3_mV,
                             int cell4_mV,
                             int cell5_mV,
                             int cell6_mV,
                             int pack_mV)
{
    if (ui_SnapackCell1Value) snapack_set_voltage_label(ui_SnapackCell1Value, cell1_mV);
    if (ui_SnapackCell2Value) snapack_set_voltage_label(ui_SnapackCell2Value, cell2_mV);
    if (ui_SnapackCell3Value) snapack_set_voltage_label(ui_SnapackCell3Value, cell3_mV);
    if (ui_SnapackCell4Value) snapack_set_voltage_label(ui_SnapackCell4Value, cell4_mV);
    if (ui_SnapackCell5Value) snapack_set_voltage_label(ui_SnapackCell5Value, cell5_mV);
    if (ui_SnapackCell6Value) snapack_set_voltage_label(ui_SnapackCell6Value, cell6_mV);
    if (ui_SnapackPackValue)  snapack_set_voltage_label(ui_SnapackPackValue, pack_mV);
}

void ui_Screen5_screen_init(void)
{
    ui_Screen5 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen5, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_PRESS_LOCK | LV_OBJ_FLAG_SCROLLABLE |
                      LV_OBJ_FLAG_SCROLL_ELASTIC | LV_OBJ_FLAG_SCROLL_MOMENTUM);

    // Keep the first measurement screen deliberately simple.
    lv_obj_set_style_bg_color(ui_Screen5, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen5, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Screen title.
    lv_obj_t * title = lv_label_create(ui_Screen5);
    lv_obj_set_width(title, LV_SIZE_CONTENT);
    lv_obj_set_height(title, LV_SIZE_CONTENT);
    lv_obj_set_x(title, 0);
    lv_obj_set_y(title, -166);
    lv_obj_set_align(title, LV_ALIGN_CENTER);
    lv_label_set_text(title, "CELL VOLTAGES");
    lv_obj_set_style_text_color(title, lv_color_hex(0xFFFFFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(title, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(title, &lv_font_montserrat_22, LV_PART_MAIN | LV_STATE_DEFAULT);

    // -----------------------------------------------------------------
    // SIX CELL VALUES
    // -----------------------------------------------------------------
    // Two columns keep all six values readable inside the round display.
    // Cell order remains obvious and stable for later diagnostic use.
    ui_SnapackCell1Value = snapack_create_cell_value(ui_Screen5, "CELL 1", -100, -98);
    ui_SnapackCell2Value = snapack_create_cell_value(ui_Screen5, "CELL 2", -100, -34);
    ui_SnapackCell3Value = snapack_create_cell_value(ui_Screen5, "CELL 3", -100,  30);

    ui_SnapackCell4Value = snapack_create_cell_value(ui_Screen5, "CELL 4",  100, -98);
    ui_SnapackCell5Value = snapack_create_cell_value(ui_Screen5, "CELL 5",  100, -34);
    ui_SnapackCell6Value = snapack_create_cell_value(ui_Screen5, "CELL 6",  100,  30);

    // -----------------------------------------------------------------
    // CUMULATIVE PACK VOLTAGE
    // -----------------------------------------------------------------
    // Pack voltage is deliberately secondary to the individual cells.
    lv_obj_t * packLabel = lv_label_create(ui_Screen5);
    lv_obj_set_width(packLabel, LV_SIZE_CONTENT);
    lv_obj_set_height(packLabel, LV_SIZE_CONTENT);
    lv_obj_set_x(packLabel, 0);
    lv_obj_set_y(packLabel, 90);
    lv_obj_set_align(packLabel, LV_ALIGN_CENTER);
    lv_label_set_text(packLabel, "PACK");
    lv_obj_set_style_text_color(packLabel, lv_color_hex(0xFFFFFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(packLabel, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(packLabel, &lv_font_montserrat_16, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackPackValue = lv_label_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackPackValue, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_SnapackPackValue, LV_SIZE_CONTENT);
    lv_obj_set_x(ui_SnapackPackValue, 0);
    lv_obj_set_y(ui_SnapackPackValue, 120);
    lv_obj_set_align(ui_SnapackPackValue, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SnapackPackValue, "0.000 V");
    lv_obj_set_style_text_color(ui_SnapackPackValue, lv_color_hex(0x33DCFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_SnapackPackValue, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_SnapackPackValue, &lv_font_montserrat_28, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Prevent temporary development values from being mistaken for live data.
    lv_obj_t * simulatedLabel = lv_label_create(ui_Screen5);
    lv_obj_set_width(simulatedLabel, LV_SIZE_CONTENT);
    lv_obj_set_height(simulatedLabel, LV_SIZE_CONTENT);
    lv_obj_set_x(simulatedLabel, 0);
    lv_obj_set_y(simulatedLabel, 149);
    lv_obj_set_align(simulatedLabel, LV_ALIGN_CENTER);
    lv_label_set_text(simulatedLabel, "SIMULATED");
    lv_obj_set_style_text_color(simulatedLabel, lv_color_hex(0xAAAAAA), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(simulatedLabel, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(simulatedLabel, &lv_font_montserrat_12, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Keep the already-proven touch Return path.
    ui_SnapackReturnBt = lv_btn_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackReturnBt, 108);
    lv_obj_set_height(ui_SnapackReturnBt, 36);
    lv_obj_set_x(ui_SnapackReturnBt, 0);
    lv_obj_set_y(ui_SnapackReturnBt, 183);
    lv_obj_set_align(ui_SnapackReturnBt, LV_ALIGN_CENTER);
    lv_obj_set_style_bg_color(ui_SnapackReturnBt, lv_color_hex(0x33DCFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_SnapackReturnBt, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(ui_SnapackReturnBt, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackReturnLabel = lv_label_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_SnapackReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_x(ui_SnapackReturnLabel, 0);
    lv_obj_set_y(ui_SnapackReturnLabel, 183);
    lv_obj_set_align(ui_SnapackReturnLabel, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SnapackReturnLabel, "Return");
    lv_obj_set_style_text_font(ui_SnapackReturnLabel, &lv_font_montserrat_18, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_add_event_cb(ui_SnapackReturnBt, ui_event_screen5ReturnBt, LV_EVENT_ALL, NULL);
}
