SNAPACK UI STEP 2 — SIX CELL VOLTAGES
=====================================

Baseline:
  Physically verified Step 1 four-item carousel.

Changed:
  snapack.ino
  ui.c
  ui.h
  ui_Screen5.c

Included unchanged for archive completeness:
  ui_Screen1.c

Expected physical result:
  * Elecrow splash still operates.
  * Carousel remains SNAPACK -> Volume -> Temp -> Light.
  * OEM Volume, Temp, and Light screens remain functional.
  * SNAPACK Screen5 displays six independent simulated cell voltages:
      CELL 1  4.180 V
      CELL 2  4.160 V
      CELL 3  4.170 V
      CELL 4  4.170 V
      CELL 5  4.180 V
      CELL 6  4.160 V
  * PACK displays 25.020 V.
  * SIMULATED is visibly shown.
  * Touch Return and rotary double-click Return continue to work.

No ADS1115 code is present yet.

Architecture established:
  snapack.ino              = measurement/application values
  ui_Screen5.c             = presentation
  ui_update_snapack_cells  = data-to-UI boundary

Voltage values cross that boundary as integer millivolts.

Install:
  snapack.ino ->
    /home/valued/Arduino/snapack/snapack.ino

  ui.c, ui.h, ui_Screen1.c, ui_Screen5.c ->
    /home/valued/Arduino/libraries/UI/

Test:
  1. Reopen snapack.ino in Arduino IDE.
  2. Verify/compile once.
  3. If successful, Export Compiled Binary.
  4. Flash with the proven esptool --no-stub command.
  5. Test all four destinations and return behavior.
