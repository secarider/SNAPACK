SNAPACK UI STEP 3 — FIVE CELLS + PACK GRID
==========================================

Baseline:
  Physically verified Step 2 six-value prototype.

Purpose:
  Refine the SNAPACK measurement screen before introducing real ADC data.

Changes:
  * Remove simulated CELL 6.
  * Use five monitored cell voltages.
  * Calculate PACK as the sum of those five cells.
  * Move PACK into the sixth equal grid position.
  * Change Screen5 to two rows of three:
        CELL 1   CELL 2   CELL 3
        CELL 4   CELL 5   PACK
  * Increase all six numeric readouts from Montserrat 20 to Montserrat 22.
  * Keep CELL VOLTAGES title essentially unchanged.
  * Keep SIMULATED marker until real measurements are connected.
  * Preserve all four carousel destinations and existing navigation.

Expected simulated values:
  CELL 1 = 4.180 V
  CELL 2 = 4.160 V
  CELL 3 = 4.170 V
  CELL 4 = 4.170 V
  CELL 5 = 4.180 V
  PACK   = 20.860 V

Changed:
  snapack.ino
  ui.c
  ui.h
  ui_Screen5.c

Included unchanged for archive completeness:
  ui_Screen1.c

Install:
  snapack.ino ->
    /home/valued/Arduino/snapack/snapack.ino

  ui.c, ui.h, ui_Screen1.c, ui_Screen5.c ->
    /home/valued/Arduino/libraries/UI/

Test:
  1. Reopen snapack.ino in Arduino IDE.
  2. Verify/compile once.
  3. Export Compiled Binary.
  4. Flash with the proven esptool --no-stub command.
  5. Check visual spacing/readability.
  6. Verify Volume, Temp, and Light OEM screens still operate.
  7. Verify touch Return and rotary double-click Return.
