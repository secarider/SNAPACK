// SNAPACK SCREEN 5
//
// This is the first SNAPACK-owned measurement screen.
//
// STEP 3 PURPOSE:
//   Refine the physically verified six-value prototype into the actual
//   five-cell SNAPACK layout.
//
// Final information grid for this revision:
//
//      CELL 1      CELL 2      CELL 3
//      4.180 V     4.160 V     4.170 V
//
//      CELL 4      CELL 5       PACK
//      4.170 V     4.180 V     20.860 V
//
// The five individual cell voltages remain the primary information.
// Cumulative pack voltage occupies the sixth equal grid position rather
// than receiving a separate smaller summary area.
//
// IMPORTANT:
//   The values shown in this revision are SIMULATED TEST VALUES.
//   No ADS1115 data is being read yet.
//
// ARCHITECTURE:
//   snapack.ino owns measurement/application data.
//   This file owns presentation only.
//   ui_update_snapack_cells() remains the boundary between those jobs.
//
// Voltage values cross that boundary as integer millivolts.
//
//   4180 mV -> "4.180 V"
//
// The numeric font has been increased one step, from Montserrat 20 to 22,
// following physical-display testing of the previous revision.

#include "ui.h"
#include <stdio.h>

// Format integer millivolts as X.XXX V.
static void snapack_set_voltage_label(lv_obj_t * label, int millivolts)
{
    char text[16];

    int volts = millivolts / 1000;
    int remainder_mV = millivolts % 1000;

    if (remainder_mV < 0) {
        remainder_mV = -remainder_mV;
    }

    snprintf(text, sizeof(text), "%d.%03d V", volts, remainder_mV);
    lv_label_set_text(label, text);
}

// Create one cell identifier and its independently updateable value.
//
// Three columns are used in this revision, so each item is intentionally
// compact.  The voltage remains larger than the identifier.
static lv_obj_t * snapack_create_measurement(lv_obj_t * parent,
                                              const char * name_text,
                                              int x,
                                              int y,
                                              bool is_pack)
{
    lv_obj_t * name = lv_label_create(parent);
    lv_obj_set_width(name, LV_SIZE_CONTENT);
    lv_obj_set_height(name, LV_SIZE_CONTENT);
    lv_obj_set_x(name, x);
    lv_obj_set_y(name, y - 17);
    lv_obj_set_align(name, LV_ALIGN_CENTER);
    lv_label_set_text(name, name_text);
    lv_obj_set_style_text_color(name, lv_color_hex(0xFFFFFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(name, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(name, &lv_font_montserrat_14, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_t * value = lv_label_create(parent);
    lv_obj_set_width(value, LV_SIZE_CONTENT);
    lv_obj_set_height(value, LV_SIZE_CONTENT);
    lv_obj_set_x(value, x);
    lv_obj_set_y(value, y + 8);
    lv_obj_set_align(value, LV_ALIGN_CENTER);
    lv_label_set_text(value, "0.000 V");

    // Individual cells and PACK deliberately use the same numeric size so
    // the six grid positions read as one coherent measurement panel.
    lv_obj_set_style_text_font(value, &lv_font_montserrat_22, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Keep the existing cyan measurement color.  PACK is differentiated
    // by its label and position rather than by introducing another color.
    lv_obj_set_style_text_color(value, lv_color_hex(0x33DCFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(value, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    return value;
}

// ---------------------------------------------------------------------
// PUBLIC DATA-TO-UI BOUNDARY
// ---------------------------------------------------------------------
//
// Application code supplies five cell voltages plus cumulative pack
// voltage.  Screen coordinates, fonts, colors, and formatting stay here.
void ui_update_snapack_cells(int cell1_mV,
                             int cell2_mV,
                             int cell3_mV,
                             int cell4_mV,
                             int cell5_mV,
                             int pack_mV)
{
    if (ui_SnapackCell1Value) snapack_set_voltage_label(ui_SnapackCell1Value, cell1_mV);
    if (ui_SnapackCell2Value) snapack_set_voltage_label(ui_SnapackCell2Value, cell2_mV);
    if (ui_SnapackCell3Value) snapack_set_voltage_label(ui_SnapackCell3Value, cell3_mV);
    if (ui_SnapackCell4Value) snapack_set_voltage_label(ui_SnapackCell4Value, cell4_mV);
    if (ui_SnapackCell5Value) snapack_set_voltage_label(ui_SnapackCell5Value, cell5_mV);
    if (ui_SnapackPackValue)  snapack_set_voltage_label(ui_SnapackPackValue, pack_mV);
}

void ui_Screen5_screen_init(void)
{
    ui_Screen5 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen5, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_PRESS_LOCK | LV_OBJ_FLAG_SCROLLABLE |
                      LV_OBJ_FLAG_SCROLL_ELASTIC | LV_OBJ_FLAG_SCROLL_MOMENTUM);

    lv_obj_set_style_bg_color(ui_Screen5, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen5, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // -----------------------------------------------------------------
    // SCREEN TITLE
    // -----------------------------------------------------------------
    // The physical test of Step 2 found this title acceptable, so its
    // wording, font, and general placement are deliberately retained.
    lv_obj_t * title = lv_label_create(ui_Screen5);
    lv_obj_set_width(title, LV_SIZE_CONTENT);
    lv_obj_set_height(title, LV_SIZE_CONTENT);
    lv_obj_set_x(title, 0);
    lv_obj_set_y(title, -166);
    lv_obj_set_align(title, LV_ALIGN_CENTER);
    lv_label_set_text(title, "CELL VOLTAGES");
    lv_obj_set_style_text_color(title, lv_color_hex(0xFFFFFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(title, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(title, &lv_font_montserrat_22, LV_PART_MAIN | LV_STATE_DEFAULT);

    // -----------------------------------------------------------------
    // TWO ROWS OF THREE MEASUREMENTS
    // -----------------------------------------------------------------
    //
    // The x positions are deliberately conservative for the 480-pixel
    // round panel.  The outer columns sit at +/-130 rather than crowding
    // the display edge.
    //
    // Top row: CELL 1 / CELL 2 / CELL 3
    ui_SnapackCell1Value = snapack_create_measurement(ui_Screen5, "CELL 1", -130, -78, false);
    ui_SnapackCell2Value = snapack_create_measurement(ui_Screen5, "CELL 2",    0, -78, false);
    ui_SnapackCell3Value = snapack_create_measurement(ui_Screen5, "CELL 3",  130, -78, false);

    // Bottom row: CELL 4 / CELL 5 / PACK
    ui_SnapackCell4Value = snapack_create_measurement(ui_Screen5, "CELL 4", -130,  18, false);
    ui_SnapackCell5Value = snapack_create_measurement(ui_Screen5, "CELL 5",    0,  18, false);
    ui_SnapackPackValue  = snapack_create_measurement(ui_Screen5, "PACK",    130,  18, true);

    // -----------------------------------------------------------------
    // SIMULATION MARKER
    // -----------------------------------------------------------------
    // Keep the development marker while values are not live.
    lv_obj_t * simulatedLabel = lv_label_create(ui_Screen5);
    lv_obj_set_width(simulatedLabel, LV_SIZE_CONTENT);
    lv_obj_set_height(simulatedLabel, LV_SIZE_CONTENT);
    lv_obj_set_x(simulatedLabel, 0);
    lv_obj_set_y(simulatedLabel, 108);
    lv_obj_set_align(simulatedLabel, LV_ALIGN_CENTER);
    lv_label_set_text(simulatedLabel, "SIMULATED");
    lv_obj_set_style_text_color(simulatedLabel, lv_color_hex(0xAAAAAA), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(simulatedLabel, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(simulatedLabel, &lv_font_montserrat_12, LV_PART_MAIN | LV_STATE_DEFAULT);

    // -----------------------------------------------------------------
    // RETURN CONTROL
    // -----------------------------------------------------------------
    // Preserve the already-proven touch Return path.
    ui_SnapackReturnBt = lv_btn_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackReturnBt, 108);
    lv_obj_set_height(ui_SnapackReturnBt, 36);
    lv_obj_set_x(ui_SnapackReturnBt, 0);
    lv_obj_set_y(ui_SnapackReturnBt, 166);
    lv_obj_set_align(ui_SnapackReturnBt, LV_ALIGN_CENTER);
    lv_obj_set_style_bg_color(ui_SnapackReturnBt, lv_color_hex(0x33DCFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_SnapackReturnBt, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_opa(ui_SnapackReturnBt, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_SnapackReturnLabel = lv_label_create(ui_Screen5);
    lv_obj_set_width(ui_SnapackReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_SnapackReturnLabel, LV_SIZE_CONTENT);
    lv_obj_set_x(ui_SnapackReturnLabel, 0);
    lv_obj_set_y(ui_SnapackReturnLabel, 166);
    lv_obj_set_align(ui_SnapackReturnLabel, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SnapackReturnLabel, "Return");
    lv_obj_set_style_text_font(ui_SnapackReturnLabel, &lv_font_montserrat_18, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_add_event_cb(ui_SnapackReturnBt, ui_event_screen5ReturnBt, LV_EVENT_ALL, NULL);
}
